# 🔋 电池气体异常监测 — 模型训练任务交接报告

> **本报告用途**：Jetson Orin Nano 不承担训练任务。LSTM 自编码器模型在 **RTX 4070 Super 主机**上训练，产出物拷回 Jetson 只做推理。
> **交接包**：本报告 + `data/time/*.csv`（5 个数据文件）+ `battery_gas/train_lstm_ae.py`（训练脚本）→ 4070 主机
> **回传包**：`lstm_ae.pt` + `model_config.json` + `scaler.npz` + `thresholds.json`（+ `training_report.json`）→ Jetson 的 `data/gas_model/`

---

## 1. 项目背景

锂电池充电过程会析出气体（H₂ 氢气 / CO 一氧化碳），浓度和温度异常升高预示热失控风险。项目对真实实验数据（5 组不同充电电流 16A~48A 的析气数据，1Hz 采样）进行**时间序列异常检测**：

```
CSV 回放 → 滑窗60s → LSTM 自编码器 → Anomaly Score → Normal/Warning/Critical → Dashboard + LED 告警
```

| 角色 | 机器 | 职责 |
|------|------|------|
| **训练** | RTX 4070 Super 主机 (x86_64) | 跑 `train_lstm_ae.py`，产出模型/缩放器/阈值 |
| **推理** | Jetson Orin Nano (aarch64) | 容器内 CPU 加载模型，回放 CSV 逐行打分，状态分级，上报 |

---

## 2. 数据说明

### 2.1 文件清单（`data/time/` 下 5 个 CSV，UTF-8 带 BOM，需 `encoding='utf-8-sig'` 读取）

| 文件 | 行数 | 采样 | 正常段（行号） | 事件段（行号） | 特有情况 |
|------|------|------|---------------|---------------|----------|
| `16A.csv` | 3059 | 1Hz（带秒） | 1 – 1641 | 1642 – 3059 | 列名小写 `cod(ppm)`；多出 `yqs/yqz/yqx` 三列（未知传感器，忽略）；温度有 **两列温差体**：上部/中部 |
| `24A.csv` | 2126 | **分钟级**（无秒） | 1 – 590 | 591 – 2126 | 列名 `温度平均值`；**数据质量差，仅作参考，不参与训练** |
| `32A.csv` | 2017 | 1Hz | 1 – 836 | 837 – 2017 | 含 `CH4(%)`（忽略） |
| `40A.csv` | 2308 | 1Hz | 1 – 693 | 694 – 2308 | 尾部 **447 行温度 NaN** → `ffill()` 前向填充 |
| `48A.csv` | 1083 | 1Hz | 1 – 375 | 376 – 1083 | 含 `CH4(%)`（忽略） |

### 2.2 列名统一规则（训练与推理必须一致）

| 统一后的特征列 | 各文件的原始列名 |
|---------------|-----------------|
| `h2_ppm` | `H2(PPM)`（全部一致） |
| `co_ppm` | 16A: `cod(ppm)`；24A/32A/40A/48A: `COD(PPM)` |
| `temp_upper_c` | `电池上部温度(℃)`（全部一致） |
| `temp_middle_c` | `电池中部温度(℃)`（全部一致） |
| `dt` | 计算列：相邻行时间差（秒） |

- `平均温度`/`温度平均值`/`CH4(%)`/`V(V)`/`HF(PPM)`/`yqs/yqz/yqx`/`索引` 一律**忽略**（与 5 特征无直接增益，且各文件不一致）
- 数值列统一 `to_numeric(errors='coerce')`；40A 温度 NaN → `ffill()`
- 24A 时间格式 `2025/4/10 10:18`（无秒、单数字月/日），解析后 dt≈60s，这也是不参与训练的原因之一

### 2.3 事件规律（供人工核验模型效果）

- H₂ 基线 26–29 ppm，事件段尖峰到 **1104–2506** ppm（上升速率 37–112 ppm/s）
- CO 基线 13–28 ppm，事件段峰值到 **5183–7522** ppm
- 时序链：**CO 先起（事件开头 0–154s）→ H₂ 尖峰 → CO 峰（H₂ 峰后 +18~54s）→ 温度峰（H₂ 峰后 +22~105s）**

---

## 3. 模型设计（LSTM 自编码器）

异常检测思路：只用**正常段**训练自编码器，模型学会"正常波形长什么样"；事件段的波形无法被低维重建，重建误差（MSE）显著升高，即为 Anomaly Score。

| 项目 | 规格 |
|------|------|
| 模型 | `LSTMAutoencoder`（Encoder LSTM → 潜在向量 → Decoder LSTM → 重建） |
| 输入 | 滑窗 `[h2_ppm, co_ppm, temp_upper_c, temp_middle_c, dt]` 5 特征 × 60 行 |
| 隐藏层 | hidden_dim = **32**，num_layers = **2** |
| 潜在维度 | latent_dim = **8**（瓶颈，强迫压缩） |
| 损失 | MSELoss（输入与重建逐点均方误差） |
| 优化器 | Adam，lr = **1e-3** |
| 训练轮数 | epochs = **200**，early stopping patience = **20** |
| Batch | 64 |
| 归一化 | StandardScaler（**均值/方差必须由训练集拟合**，推理沿用同一组参数） |

**模型类结构约定**（Jetson 侧推理脚本需用完全相同的类名/参数名重建，才能 `load_state_dict`）：

```python
class LSTMAutoencoder(nn.Module):
    def __init__(self, input_dim=5, hidden_dim=32, latent_dim=8, num_layers=2):
        # encoder: nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        #           → 取最后时刻输出 → nn.Linear(hidden_dim, latent_dim)
        # decoder: nn.Linear(latent_dim, hidden_dim) → 重复 window 次
        #           → nn.LSTM(hidden_dim, hidden_dim, num_layers, batch_first=True)
        #           → nn.Linear(hidden_dim, input_dim) 输出 (B, window, input_dim)
    def forward(self, x):  # x: (B, window, input_dim) → (B, window, input_dim)
        ...
```

---

## 4. 训练 / 验证策略

| 用途 | 数据 |
|------|------|
| **训练集** | 16A 正常段 + 40A 正常段 + 48A 正常段（共 1641+693+375=2709 行） |
| **训练窗口** | `window=60, stride=15` → **~171 个窗口**（106+43+22） |
| **验证集** | **32A 全段**（2017 行）——模型从未见过 32A |
| **排除** | 所有事件段、24A 全部、32A 全部（仅验证用） |

验证指标（打印进 `training_report.json`）：

- 32A **正常段**（1–836）平均重建误差 vs **事件段**（837–2017）平均重建误差
- **验收标准：事件段分数 ≥ 5 × 正常段分数**（有清晰分离才说明模型学到了正常模式）

---

## 5. 4070 Super 主机环境

| 项目 | 要求 |
|------|------|
| 系统 | Windows 10/11 或 Linux (x86_64) 均可 |
| Python | 3.10+（建议独立 venv） |
| 依赖 | `torch`（CUDA 版）、`pandas`、`numpy`（`scikit-learn` 可选，仅用于 StandardScaler，脚本会导出 mean/scale 为 npz，**不依赖 sklearn 传递**） |

```bash
# Windows (PowerShell)
python -m venv venv
venv\Scripts\activate
pip install torch --index-url https://download.pytorch.org/whl/cu124
pip install pandas numpy scikit-learn

# Linux
python3 -m venv venv && source venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cu124
pip install pandas numpy scikit-learn
```

> 模型很小（~171 个窗口），4070 Super 上几十秒即可训完，CUDA 不是必须但机器既然有就用上。

## 6. 运行训练

```bash
# 把 5 个 CSV 和 train_lstm_ae.py 放到同一目录（如 D:\gas_project\）
# 结构：D:\gas_project\{time\*.csv, train_lstm_ae.py}

python train_lstm_ae.py \
  --data-dir time \
  --output-dir gas_model \
  --window 60 --stride 15 \
  --epochs 200 --lr 0.001
```

脚本固定随机种子（`torch.manual_seed(42)` 等），**可复现**。训练结束打印：

```
[VALID] 32A normal   avg score = 0.0231
[VALID] 32A event    avg score = 0.1874   (8.1x normal ✓)
[SAVE]  lstm_ae.pt / model_config.json / scaler.npz / thresholds.json / training_report.json
```

## 7. 输出物与回传（跨机器兼容，禁止 pickle）

| 文件 | 格式 | 说明 |
|------|------|------|
| `lstm_ae.pt` | torch `state_dict` | `torch.save(model.state_dict(), ...)`，**不保存整个模型对象** |
| `model_config.json` | JSON | `{input_dim:5, hidden_dim:32, latent_dim:8, num_layers:2, window:60}`，Jetson 侧据此重建模型 |
| `scaler.npz` | NumPy npz | `mean_`/`scale_` 两个 5 维数组（训练拟合的均值/标准差） |
| `thresholds.json` | JSON | `{"warning": <p99>, "critical": <p99*2>}`（见第 8 节） |
| `training_report.json` | JSON | loss 摘要、32A 正常/事件段分数、分离倍数、阈值、模型配置 |

**回传命令**（在 4070 主机上执行，Jetson 侧先建目录）：

```bash
# 4070 主机
scp gas_model/lstm_ae.pt gas_model/model_config.json \
    gas_model/scaler.npz gas_model/thresholds.json \
    gas_model/training_report.json \
    neo@<Jetson-IP>:~/yolo-workspace/tiring_detection/data/gas_model/
```

> **兼容性要点**：Jetson 容器内 torch 2.10.0 加载 4070 侧 torch 2.x 的 state_dict 完全兼容（版本只影响权重格式不互通是 torch 1.x 时代的事，2.x 之间无问题）。npz 与 JSON 无版本问题。

## 8. 阈值校准（自动，无需人工调）

1. 用训练好的模型对**训练文件（16A/40A/48A）正常段**逐窗打分
2. `warning = np.percentile(全部正常分数, 99)`（p99）
3. `critical = warning * 2`
4. 写入 `thresholds.json`；同时写入 `training_report.json` 供人工核验

> 若部署后发现误报偏多（正常段分数虚高），回看 `training_report.json` 的正常段分数分布，或改用 p99.5/p99.9 重新校准。

## 9. Jetson 侧推理要点（部署方参考）

- 目录：`~/yolo-workspace/tiring_detection/data/gas_model/`（4 个文件 + 报告）
- 推理在 `yolo11-jupyter` 容器内（**已具备** torch 2.10.0 / numpy / pandas，**无需新装任何包**），CPU 推理足够（60×5 输入微秒级）
- 用 `model_config.json` 重建架构 → `load_state_dict` → 逐窗打分
- 打分前的**列统一与缩放顺序必须与训练完全一致**（特征顺序：h2, co, temp_upper, temp_middle, dt）
- 回放速度默认 **10 倍速**（可调），状态切换有 3s 进入 / 5s 退出滞回防抖

## 10. 常见问题

| 问题 | 排查 |
|------|------|
| `size mismatch` 加载失败 | `model_config.json` 与实际网络参数不一致（改过超参未同步） |
| 事件段分数分不开（< 2×） | 检查训练集是否误含事件段；window 太小（试 90）；latent 太大（试 4） |
| 阈值过敏感 / 不敏感 | 按第 8 节重新校准 p99 分位 |
| CSV 读取乱码 | 必须 `encoding='utf-8-sig'`；若在 Excel 编辑过可能变 GBK，用记事本另存为 UTF-8 |
| 回传后 Jetson 验证 | 复跑推理看 32A 行 ~900 后进 WARNING、H₂ 峰值段（~行1500）进 CRITICAL |
