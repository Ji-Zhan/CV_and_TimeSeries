# 🚗 驾驶员疲劳监测系统 — 新手指南

## 项目简介

基于 Jetson Orin Nano + YOLOv11n-pose 的**实时驾驶员疲劳检测系统**。USB 摄像头采集画面 → AI 检测人脸和关键点 → 分析眼部/嘴部/头部姿态 → 发现疲劳立即告警。

## 硬件

| 设备 | 型号 |
|------|------|
| 边缘计算 | NVIDIA Jetson Orin Nano (8GB) |
| 摄像头 | Logitech Brio 100 (USB) |
| 分辨率 | 640×480 @ 30fps |

## 如何访问

| 服务 | 地址 | 用途 |
|------|------|------|
| **Dashboard** | `http://<Jetson-IP>:8000/api/dashboard` | 实时画面 + 事件记录 |
| **JupyterLab** | `http://<Jetson-IP>:8888/lab` | 代码调试 (token: `yolo11`) |
| **原始视频流** | `http://<Jetson-IP>:8080/stream` | 纯 MJPEG 流 |
| **API 文档** | `http://<Jetson-IP>:8000/docs` | Swagger UI |

## 架构一览

```
USB 摄像头 → YOLOv11n-pose (PyTorch GPU) → 17 个 COCO 关键点
                                              │
              ┌───────────────────────────────┼───────────────────────────────┐
              ▼                               ▼                               ▼
        眼部检测 (亮度方差)              头部姿态 PnP                   嘴部纵横比 MAR
        std>32=睁眼 std<22=闭眼         pitch 偏离冻结基线              (耳朵近似嘴角)
              │                               │                               │
              └───────────────────────────────┼───────────────────────────────┘
                                              ▼
                                   三选二投票 (任一信号不单独触发)
                                              │
                                              ▼
                                   疲劳状态机 (累计 2s → DROWSY)
                                              │
                              ┌───────────────┴───────────────┐
                              ▼                               ▼
                         画面标注 + 告警              事件 → PostgreSQL
                              │                               │
                              ▼                               ▼
                         MJPEG 推流                   Dashboard 查看
```

## 疲劳判定逻辑

### 三个信号

| 信号 | 方法 | 阈值 |
|------|------|------|
| **Eyes Closed** | 眼部 ROI 灰度标准差（主）+ 瞳孔圆形搜索（辅） | std<22=闭眼, std>32=睁眼 |
| **Head Tilt** | 5 点 PnP 解 pitch，与冻结基线比较 | 偏离 > 20° |
| **Yawning** | 耳朵间距当嘴宽，鼻子 Y 当嘴高 → MAR | MAR > 0.55 |

### 关键设计：三选二投票

**单个信号不单独触发疲劳帧**。必须至少两个信号同时触发。这是为了防止瞳孔检测受光照/眼镜反光影响产生误报。

| Eyes Closed | Head Tilt | Yawning | 结果 |
|-------------|-----------|---------|------|
| ✓ | ✓ | - | 疲劳帧 |
| ✓ | - | ✓ | 疲劳帧 |
| - | ✓ | ✓ | 疲劳帧 |
| ✓ | - | - | 忽略 |
| - | ✓ | - | 忽略 |
| - | - | ✓ | 忽略 |

### 状态机

```
AWAKE ──疲劳帧累计 ≥ 60 帧 (2秒)──▶ DROWSY
DROWSY ──正常帧累计 ≥ 30 帧 (1秒)──▶ AWAKE
```

### Pitch 基线

前 2 秒采集 60 帧 pitch 取平均 → 冻结为正常头姿基线。冻结后永不更新，防止疲劳时头慢慢低下导致基线漂移。

## 容器说明

| 容器 | 镜像 | 端口 | 职责 |
|------|------|------|------|
| `fatigue-detector` | yolo11-jupyter | 8080 | YOLO 推理 + MJPEG 推流 |
| `fatigue-api` | tiring_detection-fastapi | 8000 | API + Dashboard |
| `fatigue-db` | postgres:16-alpine | 5432 | 事件存储 (按日分表) |
| `yolo11-jupyter` | yolo11-jupyter | 8888 | JupyterLab |

## 常用命令

```bash
# 查看全部容器状态
docker compose -f ~/yolo-workspace/tiring_detection/docker-compose.yml ps

# 查看检测器实时诊断日志
docker logs -f fatigue-detector 2>&1 | grep "^  \["

# 查看 PostgreSQL 中的事件
docker exec fatigue-db psql -U fatigue -d fatigue_monitor -c \
  "SELECT timestamp, new_state, cause FROM fatigue_events_$(date +%Y%m%d) ORDER BY timestamp DESC LIMIT 10;"

# 重启检测器（修改代码后）
docker compose -f ~/yolo-workspace/tiring_detection/docker-compose.yml restart detector

# 全部重启
cd ~/yolo-workspace/tiring_detection && docker compose down && docker compose up -d
```

## 数据存储

| 类型 | 位置 | 保留策略 |
|------|------|---------|
| 事件 (JSONL) | `data/events/` | 30 天 |
| 告警截图 | `data/screenshots/` | 7 天 |
| 告警录像 | `data/clips/` | 7 天 |
| PostgreSQL | `fatigue_events_YYYYMMDD` | 永久（需手动清理） |

## 关键文件

```
tiring_detection/
├── jetson_deploy/
│   ├── detector_service.py            ← 主检测 + MJPEG 推流
│   └── detector_service.py.pose_backup ← 备份
├── src/
│   ├── fatigue_state_machine.py       ← 疲劳状态机
│   ├── alert_handler.py               ← 截图/录像
│   └── event_logger.py                ← JSON事件 + HTTP上报
├── backend/
│   ├── main.py                        ← FastAPI 服务
│   ├── database.py                    ← PostgreSQL 按日分表
│   └── templates/dashboard.html       ← Dashboard 前端
├── docker-compose.yml                 ← 容器编排
├── outputs/
│   ├── onnx/yolo11n-pose-fp32.onnx    ← 导出 ONNX
│   └── engines/yolo11n-pose-fp16.engine← TensorRT 引擎 (备用)
└── data/
    ├── BEGINNER_GUIDE.md              ← 本指南
    ├── fatigue-monitor.md             ← Claude Code Skill
    ├── events/                        ← JSONL 事件备份
    ├── screenshots/                   ← 告警截图

```

## 可调参数 (detector_service.py)

| 参数 | 默认 | 含义 |
|------|------|------|
| `t_enter` | 60 (2s) | 疲劳帧累计多久进入 DROWSY |
| `t_exit` | 30 (1s) | 正常帧累计多久退回 AWAKE |
| `HEAD_NOD_DEVIATION` | 20° | pitch 偏离基线阈值 |
| `eye_r` | `max(face_w*0.13//2, 18)` | 眼部 ROI 半径 |
| `std > 32` | — | 灰度标准差高于此=睁眼 |
| `std < 22` | — | 灰度标准差低于此=闭眼 |
| `CONF_THRES` | 0.4 | YOLO 人脸检测置信度 |

## 开机自启

Jetson 通电后自动启动全部服务，由 systemd 管理：

```bash
sudo systemctl status fatigue-monitor  # 查看状态
sudo systemctl restart fatigue-monitor # 重启全部
```

## 常见问题

**Q: Dashboard 显示 "检测器离线"？**
```bash
docker logs fatigue-detector
docker compose -f ~/yolo-workspace/tiring_detection/docker-compose.yml restart detector
```

**Q: 摄像头不工作？**
```bash
docker exec fatigue-detector ls /dev/video0
v4l2-ctl -d /dev/video0 --list-formats-ext
```

**Q: 正常状态被判疲劳（误报）？**
- 查看诊断日志：`docker logs fatigue-detector 2>&1 | grep "^  \["`
- 眼部 `CLS` 频繁出现说明光照/角度导致眼部检测不稳 → 三选二投票应已解决
- Head Tilt 频繁 `N` 说明 pitch 偏离 > 20° → 检查基线是否合理
- 注意：COCO 模型缺少嘴角关键点，嘴部用耳朵近似，Yawning 判定精度有限

**Q: 模型不检测人脸？**
- 检查摄像头画面：`http://<Jetson-IP>:8080/stream`
- conf 阈值降到 0.3 试试（`CONF_THRES = 0.3`）

**Q: 切换回 best.pt（检测模型）？**
- best.pt 是 NTHU-DDD 上微调的 awake/drowsy 分类模型，泛化差已废弃
- 如需测试：改 compose 中 `--model /workspace/models/best.pt`，重启 detector
