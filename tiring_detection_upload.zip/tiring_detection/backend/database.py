"""
PostgreSQL 按日分表管理。

表命名: fatigue_events_YYYYMMDD
每天首次写入自动创建，字段与 EventLogger JSON 对齐。
"""

import logging
from datetime import datetime

import asyncpg

logger = logging.getLogger(__name__)

DB_CONFIG = {
    "host": "postgres",
    "port": 5432,
    "database": "fatigue_monitor",
    "user": "fatigue",
    "password": "fatigue123",
}

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS {table} (
    id          SERIAL PRIMARY KEY,
    timestamp   TIMESTAMPTZ NOT NULL,
    device_id   VARCHAR(64) NOT NULL,
    model_version VARCHAR(32),
    old_state   VARCHAR(16),
    new_state   VARCHAR(16) NOT NULL,
    duration_sec DOUBLE PRECISION,
    eye_closed_ratio DOUBLE PRECISION,
    head_pitch_deg DOUBLE PRECISION,
    mar DOUBLE PRECISION,
    nod_count   INTEGER,
    confidence  DOUBLE PRECISION,
    fps         DOUBLE PRECISION,
    cause       VARCHAR(64),
    screenshot_path TEXT,
    clip_path   TEXT
);

CREATE INDEX IF NOT EXISTS idx_{table}_ts ON {table} (timestamp);
CREATE INDEX IF NOT EXISTS idx_{table}_state ON {table} (new_state);
CREATE INDEX IF NOT EXISTS idx_{table}_device ON {table} (device_id, timestamp);
"""


def _table_name(date: datetime = None) -> str:
    """返回当天表名: fatigue_events_20260721"""
    d = date or datetime.utcnow()
    return f"fatigue_events_{d.strftime('%Y%m%d')}"


class Database:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    @staticmethod
    async def create_pool() -> asyncpg.Pool:
        return await asyncpg.create_pool(**DB_CONFIG, min_size=2, max_size=10)

    async def ensure_table(self, date: datetime = None):
        """确保当天表存在"""
        table = _table_name(date)
        async with self.pool.acquire() as conn:
            sql = CREATE_TABLE_SQL.format(table=table)
            await conn.execute(sql)
            logger.info(f"表就绪: {table}")

    async def insert_event(self, event: dict):
        """插入一条事件记录"""
        table = _table_name()
        await self.ensure_table()

        async with self.pool.acquire() as conn:
            await conn.execute(f"""
                INSERT INTO {table}
                    (timestamp, device_id, model_version,
                     old_state, new_state, duration_sec,
                     eye_closed_ratio, head_pitch_deg, mar,
                     nod_count, confidence, fps, cause,
                     screenshot_path, clip_path)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
            """,
                datetime.fromisoformat(
                    event["timestamp"].replace("Z", "+00:00")),
                event["device_id"],
                event.get("model_version", ""),
                event.get("old_state", ""),
                event["new_state"],
                event.get("duration_sec", 0),
                event.get("eye_closed_ratio", 0),
                event.get("head_pitch_deg", 0),
                event.get("mar", 0),
                event.get("nod_count", 0),
                event.get("confidence", 0),
                event.get("fps", 0),
                event.get("cause", ""),
                event.get("screenshot_path", ""),
                event.get("clip_path", ""),
            )

    async def query_events(self, date_str: str,
                           limit: int = 100, offset: int = 0):
        """查询指定日期的所有事件"""
        table = f"fatigue_events_{date_str}"
        async with self.pool.acquire() as conn:
            # 检查表是否存在
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables "
                "WHERE table_name=$1)", table)
            if not exists:
                return [], 0

            rows = await conn.fetch(
                f"SELECT * FROM {table} ORDER BY timestamp DESC "
                f"LIMIT $1 OFFSET $2", limit, offset)
            total = await conn.fetchval(
                f"SELECT COUNT(*) FROM {table}")

            events = []
            for r in rows:
                events.append({
                    "id": r["id"],
                    "timestamp": r["timestamp"].isoformat(),
                    "device_id": r["device_id"],
                    "model_version": r["model_version"],
                    "old_state": r["old_state"],
                    "new_state": r["new_state"],
                    "duration_sec": r["duration_sec"],
                    "eye_closed_ratio": r["eye_closed_ratio"],
                    "head_pitch_deg": r["head_pitch_deg"],
                    "mar": r["mar"],
                    "nod_count": r["nod_count"],
                    "confidence": r["confidence"],
                    "fps": r["fps"],
                    "cause": r.get("cause", ""),
                    "screenshot_path": r["screenshot_path"],
                    "clip_path": r["clip_path"],
                })
            return events, total

    async def get_latest(self):
        """获取最新一条事件"""
        today = datetime.utcnow().strftime("%Y%m%d")
        return await self._latest_in_table(f"fatigue_events_{today}")

    async def _latest_in_table(self, table: str):
        async with self.pool.acquire() as conn:
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables "
                "WHERE table_name=$1)", table)
            if not exists:
                return None
            row = await conn.fetchrow(
                f"SELECT * FROM {table} ORDER BY timestamp DESC LIMIT 1")
            if row:
                return {
                    "timestamp": row["timestamp"].isoformat(),
                    "device_id": row["device_id"],
                    "new_state": row["new_state"],
                    "duration_sec": row["duration_sec"],
                    "eye_closed_ratio": row["eye_closed_ratio"],
                    "head_pitch_deg": row["head_pitch_deg"],
                    "confidence": row["confidence"],
                    "fps": row["fps"],
                }
            return None

    async def get_stats(self, date_str: str = None):
        """获取统计摘要"""
        d = date_str or datetime.utcnow().strftime("%Y%m%d")
        table = f"fatigue_events_{d}"

        async with self.pool.acquire() as conn:
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables "
                "WHERE table_name=$1)", table)
            if not exists:
                return {"total": 0, "fatigue_count": 0, "total_duration": 0}

            total = await conn.fetchval(f"SELECT COUNT(*) FROM {table}")
            fatigue = await conn.fetchval(
                f"SELECT COUNT(*) FROM {table} WHERE new_state='FATIGUE'")
            duration = await conn.fetchval(
                f"SELECT COALESCE(SUM(duration_sec),0) FROM {table} "
                f"WHERE new_state='FATIGUE'")

            return {
                "total": total,
                "fatigue_count": fatigue,
                "normal_count": total - fatigue,
                "total_fatigue_duration_sec": float(duration) if duration else 0,
            }

    # ========== 电池气体事件 ==========

    async def ensure_gas_table(self, date: datetime = None):
        d = date or datetime.utcnow()
        table = f"battery_gas_events_{d.strftime('%Y%m%d')}"
        async with self.pool.acquire() as conn:
            await conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {table} (
                    id              SERIAL PRIMARY KEY,
                    timestamp       TIMESTAMPTZ NOT NULL,
                    device_id       VARCHAR(64) NOT NULL,
                    state           VARCHAR(16) NOT NULL,
                    anomaly_score   DOUBLE PRECISION,
                    h2_ppm          DOUBLE PRECISION,
                    co_ppm          DOUBLE PRECISION,
                    delta_t         DOUBLE PRECISION,
                    row_index       INTEGER,
                    total_rows      INTEGER,
                    csv_file        VARCHAR(128)
                );
                CREATE INDEX IF NOT EXISTS idx_{table}_ts ON {table} (timestamp);
                CREATE INDEX IF NOT EXISTS idx_{table}_state ON {table} (state);
            """)
            logger.info(f"Gas 表就绪: {table}")

    async def insert_gas_event(self, event: dict):
        d = datetime.utcnow()
        table = f"battery_gas_events_{d.strftime('%Y%m%d')}"
        await self.ensure_gas_table()
        async with self.pool.acquire() as conn:
            await conn.execute(f"""
                INSERT INTO {table}
                    (timestamp, device_id, state, anomaly_score,
                     h2_ppm, co_ppm, delta_t, row_index, total_rows, csv_file)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
            """,
                datetime.fromisoformat(event["timestamp"].replace("Z", "+00:00")),
                event.get("device_id", ""),
                event.get("state", ""),
                event.get("anomaly_score", 0),
                event.get("h2_ppm", 0),
                event.get("co_ppm", 0),
                event.get("delta_t", 0),
                event.get("row", 0),
                event.get("total_rows", 0),
                event.get("csv_file", ""),
            )

    async def query_gas_events(self, date_str: str, limit: int = 100, offset: int = 0):
        table = f"battery_gas_events_{date_str}"
        async with self.pool.acquire() as conn:
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name=$1)", table)
            if not exists:
                return [], 0
            rows = await conn.fetch(
                f"SELECT * FROM {table} ORDER BY timestamp DESC LIMIT $1 OFFSET $2", limit, offset)
            total = await conn.fetchval(f"SELECT COUNT(*) FROM {table}")
            events = [{
                "id": r["id"], "timestamp": r["timestamp"].isoformat(),
                "device_id": r["device_id"], "state": r["state"],
                "anomaly_score": r["anomaly_score"], "h2_ppm": r["h2_ppm"],
                "co_ppm": r["co_ppm"], "delta_t": r["delta_t"],
                "row": r["row_index"], "total_rows": r["total_rows"],
                "csv_file": r["csv_file"],
            } for r in rows]
            return events, total

    async def get_gas_stats(self, date_str: str = None):
        d = date_str or datetime.utcnow().strftime("%Y%m%d")
        table = f"battery_gas_events_{d}"
        async with self.pool.acquire() as conn:
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name=$1)", table)
            if not exists:
                return {"total": 0, "anomaly_count": 0}
            total = await conn.fetchval(f"SELECT COUNT(*) FROM {table}")
            anomaly = await conn.fetchval(
                f"SELECT COUNT(*) FROM {table} WHERE state='ANOMALY'")
            return {"total": total, "anomaly_count": anomaly, "normal_count": total - anomaly}
