"""
FastAPI 后端 — 事件接收、查询、Dashboard、静态文件

启动:
    uvicorn main:app --host 0.0.0.0 --port 8000
"""

import os, logging, json
from datetime import datetime
from pathlib import Path

from contextlib import asynccontextmanager
from fastapi import FastAPI, Query, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse

from database import Database

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

db: Database = None
DATA_DIR = Path(os.environ.get("DATA_DIR", "/app/data"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db
    pool = await Database.create_pool()
    db = Database(pool)
    await db.ensure_table()
    await db.ensure_gas_table()
    logger.info("DB ready")
    yield
    await pool.close()


app = FastAPI(title="Fatigue Monitor API", lifespan=lifespan)


# ---- Events ----
@app.post("/api/events", status_code=201)
async def receive_event(event: dict):
    try:
        await db.insert_event(event)
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/events")
async def list_events(date: str = Query(None), limit: int = 50, offset: int = 0):
    ds = date or datetime.utcnow().strftime("%Y%m%d")
    events, total = await db.query_events(ds, limit=limit, offset=offset)
    return {"date": ds, "total": total, "events": events}


@app.get("/api/events/latest")
async def latest_event():
    ev = await db.get_latest()
    if ev is None:
        return {"status": "no_data"}
    return ev


@app.get("/api/stats")
async def stats(date: str = Query(None)):
    ds = date or datetime.utcnow().strftime("%Y%m%d")
    return await db.get_stats(ds)


# ---- Detector status (proxy → detector:8080) ----
@app.get("/api/detector/status")
async def detector_status():
    import urllib.request
    try:
        resp = urllib.request.urlopen("http://fatigue-detector:8080/status", timeout=2)
        return json.loads(resp.read())
    except Exception:
        return {"state": "offline", "fps": 0, "conf": 0}


# ---- Static media ----
@app.get("/api/media/screenshots/{filename}")
async def serve_screenshot(filename: str):
    path = DATA_DIR / "screenshots" / filename
    if path.exists():
        return FileResponse(path, media_type="image/jpeg")
    raise HTTPException(status_code=404)


@app.get("/api/media/clips/{filename}")
async def serve_clip(filename: str):
    path = DATA_DIR / "clips" / filename
    if path.exists():
        return FileResponse(path, media_type="video/mp4")
    raise HTTPException(status_code=404)


# ---- Gas Events ----


@app.post("/api/gas/events", status_code=201)
async def receive_gas_event(event: dict):
    try:
        await db.insert_gas_event(event)
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/gas/events")
async def list_gas_events(date: str = Query(None), limit: int = 50, offset: int = 0):
    ds = date or datetime.utcnow().strftime("%Y%m%d")
    events, total = await db.query_gas_events(ds, limit=limit, offset=offset)
    return {"date": ds, "total": total, "events": events}


@app.get("/api/gas/stats")
async def gas_stats(date: str = Query(None)):
    ds = date or datetime.utcnow().strftime("%Y%m%d")
    return await db.get_gas_stats(ds)


@app.get("/api/gas/state")
async def gas_state():
    """直接读 gas_state 文件（高频 1.5s 轮询，不经过 DB）"""
    path = DATA_DIR / "gas_state"
    if path.exists():
        return JSONResponse(content=json.loads(path.read_text(encoding="utf-8")))
    return JSONResponse(content={"state": "offline"})


@app.get("/api/gas/status")
async def gas_monitor_status():
    """代理 gas-monitor:8081/status"""
    import urllib.request
    try:
        resp = urllib.request.urlopen("http://gas-monitor:8081/status", timeout=2)
        return json.loads(resp.read())
    except Exception:
        return {"state": "offline"}


@app.post("/api/gas/upload", status_code=201)
async def upload_gas_csv(file: UploadFile = File(...)):
    """上传 CSV 测试文件到 gas_uploads，gas-monitor 会自动开始回放测试。"""
    filename = Path(file.filename or "").name
    if not filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="只支持 .csv 文件")

    upload_dir = DATA_DIR / "gas_uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)

    dest = upload_dir / filename
    if dest.exists():
        base = dest.stem
        suffix = dest.suffix
        dest = upload_dir / f"{base}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{suffix}"

    content = await file.read()
    if not content or not content.strip():
        raise HTTPException(status_code=400, detail="上传的文件为空")

    dest.write_bytes(content)
    logger.info(f"gas upload saved: {dest}")
    return {
        "status": "ok",
        "filename": dest.name,
        "path": str(dest),
        "message": "已上传，gas-monitor 会自动开始测试",
    }


# ---- Dashboard ----
@app.get("/api/dashboard", response_class=HTMLResponse)
async def dashboard():
    tp = Path(__file__).parent / "templates" / "dashboard.html"
    if tp.exists():
        return tp.read_text(encoding="utf-8")
    return "<h1>Dashboard not found</h1>"


@app.get("/")
async def root():
    return {"service": "Fatigue Monitor API", "docs": "/docs"}
