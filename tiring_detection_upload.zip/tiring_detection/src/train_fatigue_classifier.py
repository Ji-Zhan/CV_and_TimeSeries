"""
训练疲劳分类器 (MLP/SVM) + 导出 ONNX

输入: 从视频数据集提取的特征文件 (.npz)
输出: sklearn 模型 + ONNX 模型文件 + 分类报告

特征: [EAR, MAR, pitch, yaw, roll]
标签: 0=Alert, 1=Drowsy, 2=Sleeping

用法:
    python src/train_fatigue_classifier.py \
        --features outputs/features/features.npz \
        --output outputs/
"""
import argparse
from pathlib import Path
import numpy as np
import pickle
import json
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


def load_and_split(features_path, test_size=0.2, random_state=42):
    """加载特征文件并划分 train/test"""
    data = np.load(features_path, allow_pickle=True)
    X = data['features']
    y = data['labels']

    # 过滤异常值 (EAR > 1 或 < 0 等明显错误)
    valid_mask = (
        (X[:, 0] > 0) & (X[:, 0] < 2.0) &   # EAR
        (X[:, 1] > 0) & (X[:, 1] < 3.0) &   # MAR
        (np.abs(X[:, 2]) < 90) &             # pitch
        (np.abs(X[:, 3]) < 90) &             # yaw
        (np.abs(X[:, 4]) < 90)               # roll
    )
    X = X[valid_mask]
    y = y[valid_mask.astype(bool)]

    print(f"加载特征: {X.shape[0]} 个样本")
    print(f"  有效样本: {len(y)} (过滤 {sum(~valid_mask)} 个异常)")

    # 检查标签分布
    unique, counts = np.unique(y, return_counts=True)
    print(f"  标签分布: {dict(zip(unique.astype(int), counts))}")

    # 标准化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return X_train, X_test, y_train, y_test, scaler


def train_mlp(X_train, y_train, X_test, y_test):
    """训练 MLP 分类器"""
    print("\n=== MLP 分类器 ===")

    # 搜索最佳隐藏层
    configs = [
        {'hidden_layer_sizes': (8,), 'name': 'Single-8'},
        {'hidden_layer_sizes': (16, 8), 'name': 'Double-16-8'},
        {'hidden_layer_sizes': (32, 16), 'name': 'Double-32-16'},
        {'hidden_layer_sizes': (32, 16, 8), 'name': 'Triple-32-16-8'},
    ]

    best_model = None
    best_score = 0

    for cfg in configs:
        mlp = MLPClassifier(
            hidden_layer_sizes=cfg['hidden_layer_sizes'],
            activation='relu',
            solver='adam',
            alpha=0.001,
            batch_size=128,
            learning_rate='adaptive',
            learning_rate_init=0.01,
            max_iter=2000,
            early_stopping=True,
            validation_fraction=0.1,
            n_iter_no_change=30,
            random_state=42,
        )
        mlp.fit(X_train, y_train)

        train_score = mlp.score(X_train, y_train)
        test_score = mlp.score(X_test, y_test)

        print(f"  {cfg['name']} (hidden={cfg['hidden_layer_sizes']}): "
              f"Train={train_score:.4f}, Test={test_score:.4f}")

        if test_score > best_score:
            best_score = test_score
            best_model = mlp

    print(f"\n最佳 MLP 测试准确率: {best_score:.4f}")
    return best_model


def train_svm(X_train, y_train, X_test, y_test):
    """训练 SVM 分类器 (对比)"""
    print("\n=== SVM 分类器 ===")
    svm = SVC(kernel='rbf', C=10, gamma='scale', probability=True, random_state=42)
    svm.fit(X_train, y_train)
    test_score = svm.score(X_test, y_test)
    print(f"  Test Acc: {test_score:.4f}")
    return svm


def evaluate(model, X_test, y_test, label_names):
    """打印评估报告"""
    y_pred = model.predict(X_test)
    print(f"\n=== 评估报告 ===")
    print(f"准确率: {accuracy_score(y_test, y_pred):.4f}")

    print("\n分类报告:")
    print(classification_report(y_test, y_pred, target_names=label_names, zero_division=0))

    cm = confusion_matrix(y_test, y_pred)
    print("混淆矩阵:")
    print(f"           {'  '.join(label_names)}")
    for i, name in enumerate(label_names):
        print(f"  {name:10s} {cm[i]}")


def save_artifacts(model, scaler, output_dir, model_name='fatigue_mlp'):
    """保存模型 + 标准化器 + 元数据"""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    # 保存 sklearn 模型
    with open(output / f'{model_name}.pkl', 'wb') as f:
        pickle.dump({'model': model, 'scaler': scaler}, f)

    # 保存配置元数据
    config = {
        'model_type': type(model).__name__,
        'feature_names': ['ear', 'mar', 'pitch', 'yaw', 'roll'],
        'n_features': 5,
        'n_classes': len(model.classes_) if hasattr(model, 'classes_') else 3,
        'classes': model.classes_.tolist() if hasattr(model, 'classes_') else [0, 1, 2],
        'class_labels': ['Alert', 'Drowsy', 'Sleeping'],
        'scaler_mean': scaler.mean_.tolist(),
        'scaler_scale': scaler.scale_.tolist(),
    }
    with open(output / f'{model_name}_config.json', 'w') as f:
        json.dump(config, f, indent=2)

    print(f"\n模型已保存: {output / f'{model_name}.pkl'}")
    print(f"配置已保存: {output / f'{model_name}_config.json'}")


def main():
    parser = argparse.ArgumentParser(description='训练疲劳分类器')
    parser.add_argument('--features', type=str, required=True,
                        help='特征文件 .npz 路径')
    parser.add_argument('--output', type=str, default='outputs/',
                        help='模型输出目录')
    parser.add_argument('--classifier', type=str, default='mlp',
                        choices=['mlp', 'svm', 'rf'], help='分类器类型')
    args = parser.parse_args()

    # 加载数据
    X_train, X_test, y_train, y_test, scaler = load_and_split(args.features)

    label_names = ['Alert', 'Drowsy', 'Sleeping']

    # 训练
    if args.classifier == 'mlp':
        model = train_mlp(X_train, y_train, X_test, y_test)
    elif args.classifier == 'svm':
        model = train_svm(X_train, y_train, X_test, y_test)
    elif args.classifier == 'rf':
        print("\n=== Random Forest ===")
        model = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42)
        model.fit(X_train, y_train)
        print(f"  Test Acc: {model.score(X_test, y_test):.4f}")

    # 评估
    evaluate(model, X_test, y_test, label_names)

    # 保存
    save_artifacts(model, scaler, args.output)


if __name__ == '__main__':
    main()
