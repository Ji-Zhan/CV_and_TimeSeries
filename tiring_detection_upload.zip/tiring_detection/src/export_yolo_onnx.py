"""
导出微调后的 YOLOv11n-pose 为 ONNX 格式

ONNX → Jetson 端转换为 TensorRT Engine

用法:
    python src/export_yolo_onnx.py \
        --model outputs/weights/best.pt \
        --output outputs/onnx/yolo11n_face_pose.onnx \
        --imgsz 320 --opset 12 --simplify
"""
import argparse
from pathlib import Path
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser(description='导出 YOLO 为 ONNX')
    parser.add_argument('--model', type=str, required=True,
                        help='YOLO .pt 模型路径')
    parser.add_argument('--output', type=str, default='outputs/onnx/yolo11n_face_pose.onnx',
                        help='输出 ONNX 路径')
    parser.add_argument('--imgsz', type=int, default=320,
                        help='输入分辨率')
    parser.add_argument('--opset', type=int, default=12,
                        help='ONNX opset 版本 (Jetson JetPack 6 支持 12-17)')
    parser.add_argument('--simplify', action='store_true', default=True,
                        help='使用 onnxsim 简化模型图')
    parser.add_argument('--half', action='store_true',
                        help='导出 FP16 权重 (减小模型体积)')
    parser.add_argument('--dynamic', action='store_true',
                        help='动态 batch size')
    args = parser.parse_args()

    model_path = Path(args.model)
    if not model_path.exists():
        print(f"[ERROR] 模型不存在: {args.model}")
        return

    print(f"加载模型: {args.model}")
    model = YOLO(str(model_path))

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Ultralytics 内置 export 方法
    export_kwargs = {
        'format': 'onnx',
        'imgsz': args.imgsz,
        'opset': args.opset,
        'simplify': args.simplify,
        'half': args.half,
        'workspace': 4.0,  # GB
    }

    if args.dynamic:
        export_kwargs['dynamic'] = True

    print(f"\n导出参数:")
    print(f"  输入分辨率: {args.imgsz}x{args.imgsz}")
    print(f"  Opset: {args.opset}")
    print(f"  Simplify: {args.simplify}")
    print(f"  FP16: {args.half}")
    print(f"  Dynamic batch: {args.dynamic}")

    # Ultralytics 导出到同目录
    result_path = model.export(**export_kwargs)

    # 移动到指定路径
    if result_path and Path(result_path) != output_path:
        import shutil
        shutil.move(str(result_path), str(output_path))
        print(f"\nONNX 模型已保存: {output_path}")
    else:
        print(f"\nONNX 模型已导出: {result_path}")

    # 验证 ONNX
    try:
        import onnx
        onnx_model = onnx.load(str(output_path))
        onnx.checker.check_model(onnx_model)
        print("ONNX 模型验证通过 ✓")

        # 打印输入输出信息
        print(f"\n模型信息:")
        for inp in onnx_model.graph.input:
            shape = [d.dim_value if d.dim_value else 'dynamic' for d in inp.type.tensor_type.shape.dim]
            print(f"  输入: {inp.name} — {shape}")
        for out in onnx_model.graph.output:
            shape = [d.dim_value if d.dim_value else 'dynamic' for d in out.type.tensor_type.shape.dim]
            print(f"  输出: {out.name} — {shape}")

        file_size = output_path.stat().st_size / (1024 * 1024)
        print(f"  模型大小: {file_size:.1f} MB")
    except Exception as e:
        print(f"[WARN] ONNX 验证失败: {e}")


if __name__ == '__main__':
    main()
