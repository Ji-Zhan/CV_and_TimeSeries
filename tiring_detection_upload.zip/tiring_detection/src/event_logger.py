"""
结构化事件生成器 — 每次状态变化时输出 JSON 并 HTTP POST 到 FastAPI。

用法:
    logger = EventLogger(device_id="jetson-orin-001", api_url="http://localhost:8000/api/events")
    logger.log_state_change(
        old_state="NORMAL", new_state="FATIGUE",
        metrics={"eye_closed_ratio": 0.85, "head_pitch_deg": -22.3, ...},
        screenshot_path="...", clip_path="..."
    )
"""

import json
import time
import logging
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from pathlib import Path

import requests

logger = logging.getLogger(__name__)


class EventLogger:
    """疲劳事件 JSON 生成 + HTTP 上报"""

    def __init__(self, device_id: str = "jetson-orin-001",
                 model_version: str = "yolo11n-pose-fp16",
                 api_url: str = "http://localhost:8000/api/events",
                 log_dir: str = "/workspace/data/events"):
        self.device_id = device_id
        self.model_version = model_version
        self.api_url = api_url
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        # 本地缓存 (网络不可用时暂存)
        self._cache: list = []
        self._lock = threading.Lock()

    def log_state_change(self,
                         old_state: str,
                         new_state: str,
                         metrics: Dict[str, Any],
                         screenshot_path: str = "",
                         clip_path: str = "") -> Optional[dict]:
        """
        记录一次状态变化事件。返回生成的 event dict，失败返回 None。
        """
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "device_id": self.device_id,
            "model_version": self.model_version,
            "old_state": old_state,
            "new_state": new_state,
            "duration_sec": round(metrics.get("state_duration_sec", 0), 2),
            "eye_closed_ratio": round(metrics.get("eye_closed_ratio", 0), 3),
            "head_pitch_deg": round(metrics.get("head_pitch_deg", 0), 1),
            "mar": round(metrics.get("mar", 0), 3),
            "nod_count": int(metrics.get("nod_count", 0)),
            "confidence": round(metrics.get("confidence", 0), 3),
            "fps": round(metrics.get("fps", 0), 1),
            "cause": metrics.get("cause", ""),
            "screenshot_path": screenshot_path,
            "clip_path": clip_path,
        }

        # 本地 JSON 落盘
        self._save_local(event)

        # HTTP 发送 (异步, 不阻塞推理)
        threading.Thread(target=self._send_event, args=(event,),
                         daemon=True).start()

        return event

    def _save_local(self, event: dict):
        """本地 JSON 持久化"""
        date_str = datetime.now().strftime("%Y%m%d")
        fname = self.log_dir / f"events_{date_str}.jsonl"
        try:
            with open(fname, "a") as f:
                f.write(json.dumps(event, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error(f"本地事件写入失败: {e}")

    def _send_event(self, event: dict):
        """HTTP POST 事件到后端, 失败则缓存"""
        try:
            resp = requests.post(self.api_url, json=event, timeout=5)
            if resp.status_code != 201:
                logger.warning(f"事件上传失败 HTTP {resp.status_code}: {resp.text}")
                self._cache_event(event)
        except requests.RequestException as e:
            logger.warning(f"事件上传网络异常: {e}")
            self._cache_event(event)

    def _cache_event(self, event: dict):
        """网络不可用时本地缓存, 后台补传"""
        with self._lock:
            self._cache.append(event)
        # 保持缓存不超过 1000 条
        if len(self._cache) > 1000:
            self._cache = self._cache[-500:]

    def flush_cache(self):
        """尝试补传所有缓存事件"""
        with self._lock:
            pending = list(self._cache)
            self._cache.clear()

        for event in pending:
            try:
                resp = requests.post(self.api_url, json=event, timeout=5)
                if resp.status_code != 201:
                    with self._lock:
                        self._cache.append(event)
                    break
            except requests.RequestException:
                with self._lock:
                    self._cache.extend(pending)
                break

    @property
    def cache_size(self) -> int:
        return len(self._cache)
