"""
司机疲劳检测 — YOLOv11n-pose + 几何特征（无需微调，零数据集依赖）

原理:
  1. YOLOv11n-pose → 人脸 bbox + 5 关键点 (预训练模型, 无需微调)
  2. 眼部像素暗度 → 判断睁眼/闭眼
  3. 嘴部纵横比(MAR) → 判断打哈欠
  4. 头部姿态(EPNP) → 判断点头/低头
  5. 任一疲劳信号持续 0.5 秒 → 立即告警

用法:
    python3 /workspace/tiring_detection/src/test_drowsy_hybrid.py \
        --source /workspace/data/raw_videos/test-video2.mp4

    python3 /workspace/tiring_detection/src/test_drowsy_hybrid.py \
        --source /workspace/data/raw_videos/test-video2.mp4 --no-display
"""
import argparse
import sys
import os
import time
from datetime import datetime
from pathlib import Path
from collections import deque, Counter

import cv2
import numpy as np
from ultralytics import YOLO

# ============================================================
# 参数（可调整）
# ============================================================
EYE_CLOSE_RATIO = 0.35     # 梯度降到基线 35% 以下 = 闭眼 (值越大越敏感)
MAR_THRESHOLD = 0.55       # 哈欠阈值
HEAD_NOD_DEVIATION = 15    # 偏离基线的角度阈值 (度)
ALARM_DELAY_SEC = 0.5      # 疲劳信号持续多久触发告警 (秒)
FACE_CONF = 0.5            # 人脸检测置信度

# 3D 人脸参考点 (EPNP)
FACE_3D = np.array([
    [-30., -30., -30.], [30., -30., -30.], [0., 0., 0.],
    [-25., 20., -20.], [25., 20., -20.]
], dtype=np.float64)

LABELS = {0: 'Awake', 1: 'DROWSY !!!'}


def eye_is_closed(roi):
    """
    瞳孔检测法: 在眼部 ROI 中寻找深色圆形区域 (瞳孔)。

    原理:
      - 睁眼: 瞳孔始终是眼部区域中最暗的圆形
      - 闭眼: 无瞳孔 → 没有集中深色圆形

    返回: True=闭眼, False=睁眼
    """
    if roi.size == 0 or roi.shape[0] < 8 or roi.shape[1] < 8:
        return False

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    # 自适应阈值找暗区
    block = max(7, min(gray.shape[0], gray.shape[1]) // 4 * 2 + 1)
    thresh = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, blockSize=block, C=8
    )

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    roi_area = roi.shape[0] * roi.shape[1]

    for cnt in contours:
        area = cv2.contourArea(cnt)
        area_ratio = area / roi_area

        # 瞳孔占 ROI 3%-30%
        if area_ratio < 0.03 or area_ratio > 0.30:
            continue

        perimeter = cv2.arcLength(cnt, True)
        if perimeter < 8:
            continue

        circularity = 4 * np.pi * area / (perimeter * perimeter)
        if circularity > 0.35:
            return False  # 找到瞳孔 = 睁眼

    return True  # 没找到瞳孔 = 闭眼


def compute_mar(kpts):
    """嘴部纵横比"""
    mouth_w = np.linalg.norm(kpts[3] - kpts[4]) + 1e-6
    mouth_h = abs(kpts[2][1] - (kpts[3][1] + kpts[4][1]) / 2)
    return mouth_h / mouth_w


def compute_head_pose(kpts, cam_matrix):
    """头部姿态 (EPNP, 支持 5 点)"""
    pts_2d = kpts.astype(np.float64).reshape(5, 2)
    _, rvec, _ = cv2.solvePnP(
        FACE_3D, pts_2d, cam_matrix, None,
        flags=cv2.SOLVEPNP_EPNP
    )
    rmat, _ = cv2.Rodrigues(rvec)
    sy = np.sqrt(rmat[0, 0]**2 + rmat[1, 0]**2)
    pitch = np.degrees(np.arctan2(-rmat[2, 0], sy))
    yaw = np.degrees(np.arctan2(rmat[1, 0], rmat[0, 0]))
    roll = np.degrees(np.arctan2(rmat[2, 1], rmat[2, 2]))
    return pitch, yaw, roll


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=str, required=True)
    parser.add_argument('--model', type=str, default='yolo11n-pose.pt')
    parser.add_argument('--conf', type=float, default=FACE_CONF)
    parser.add_argument('--no-display', action='store_true')
    parser.add_argument('--output', type=str, default='')
    parser.add_argument('--log_dir', type=str, default='/workspace/data/log')
    args = parser.parse_args()

    # 日志设置
    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_path = log_dir / f'run_{timestamp}.log'
    log_fp = open(log_path, 'w', buffering=1)

    def log(msg):
        print(msg)
        log_fp.write(msg + '\n')

    log(f'日志: {log_path}')
    log(f'模型: {args.model}')
    model = YOLO(args.model, verbose=False)

    # 视频
    cap = cv2.VideoCapture(0 if args.source.isdigit() else args.source)
    if not cap.isOpened():
        log(f'[ERROR] 无法打开: {args.source}')
        log_fp.close(); sys.exit(1)

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps_src = cap.get(cv2.CAP_PROP_FPS)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    log(f'视频: {w}x{h}, {total_frames} 帧, {fps_src:.1f} fps')

    # 相机内参
    cam = np.array([[w, 0, w/2], [0, w, h/2], [0, 0, 1]], dtype=np.float64)

    # 输出
    out_path = args.output or '/workspace/data/output_video/hybrid_output.mp4'
    os.makedirs(Path(out_path).parent, exist_ok=True)
    out = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*'mp4v'),
                          fps_src if fps_src > 0 else 30, (w, h))

    # 状态
    frame_times = deque(maxlen=30)
    current_state = 0         # 0=Awake, 1=Drowsy
    alarm_active = False      # 告警是否已触发
    fatigue_start_frame = -1  # 疲劳信号开始的帧号

    drowsy_frames = 0
    total_drowsy_sec = 0

    # Pitch 基线 (前 2 秒建立, 后面冻结)
    pitch_baseline = 0.0
    pitch_baseline_samples = deque(maxlen=60)  # 2秒@30fps
    pitch_established = False

    # 告警确认帧数 (0.5 秒)
    fps_real = fps_src if fps_src > 0 else 30
    alarm_delay_frames = int(ALARM_DELAY_SEC * fps_real)

    log(f'\n推理中... 按 q 退出\n')

    for frame_idx in range(total_frames if total_frames > 0 else 10**9):
        ret, frame = cap.read()
        if not ret:
            break

        t0 = time.perf_counter()
        results = model(frame, conf=args.conf, verbose=False)[0]

        feat_ok = False
        display = frame.copy()

        if (results.keypoints is not None and len(results.keypoints.xy) > 0
                and results.boxes is not None and len(results.boxes.conf) > 0):
            best = int(results.boxes.conf.argmax())
            kpts = results.keypoints.xy[best].cpu().numpy()[:5]
            bbox = results.boxes.xyxy[best].cpu().numpy()
            face_w = bbox[2] - bbox[0]
            conf = float(results.boxes.conf[best])

            if conf >= args.conf and face_w > 0:
                feat_ok = True

                # 双眼瞳孔检测 (缩小 ROI: face_w * 0.10)
                eye_size = int(face_w * 0.10)
                eye_r = max(eye_size // 2, 12)

                lx, ly = int(kpts[0][0]), int(kpts[0][1])
                left_roi = frame[max(0,ly-eye_r):min(h,ly+eye_r),
                                 max(0,lx-eye_r):min(w,lx+eye_r)]

                rx, ry = int(kpts[1][0]), int(kpts[1][1])
                right_roi = frame[max(0,ry-eye_r):min(h,ry+eye_r),
                                  max(0,rx-eye_r):min(w,rx+eye_r)]

                left_closed = eye_is_closed(left_roi)
                right_closed = eye_is_closed(right_roi)
                is_eye_closed = left_closed and right_closed  # 双眼都闭才算

                # 嘴部
                mar = compute_mar(kpts)

                # 头部姿态
                pitch, yaw, roll = compute_head_pose(kpts, cam)

                # 建立 Pitch 基线 (前 2 秒)
                if not pitch_established:
                    pitch_baseline_samples.append(pitch)
                    if len(pitch_baseline_samples) == pitch_baseline_samples.maxlen:
                        pitch_baseline = np.mean(pitch_baseline_samples)
                        pitch_established = True
                        log(f'  Pitch 基线已建立: {pitch_baseline:.0f} 度')
                else:
                    # 基线保持冻结, 不做 EMA 更新
                    # (司机的正常头姿在校准后不会改变, 更新反而会让基线漂移到疲劳状态)
                    pass

                pitch_deviation = abs(pitch - pitch_baseline) if pitch_established else 0

                # 疲劳判定 (任一信号触发即计为疲劳帧)
                is_yawning = mar > MAR_THRESHOLD
                is_nodding = pitch_deviation > HEAD_NOD_DEVIATION
                # is_eye_closed 已在上面通过自适应基线计算

                fatigue_signal = is_eye_closed or is_yawning or is_nodding
                frame_state = 1 if fatigue_signal else 0

        if not feat_ok:
            frame_state = 0
            ear = mar = pitch = yaw = roll = pitch_deviation = 0
            is_yawning = is_nodding = is_eye_closed = False
            fatigue_signal = False

        # 告警逻辑: 疲劳信号持续 >= 0.5 秒 → 告警
        if frame_state == 1:
            if fatigue_start_frame < 0:
                fatigue_start_frame = frame_idx
            fatigue_duration = frame_idx - fatigue_start_frame
            if fatigue_duration >= alarm_delay_frames:
                alarm_active = True
                current_state = 1
            else:
                current_state = 0
        else:
            fatigue_start_frame = -1
            alarm_active = False
            current_state = 0

        if current_state == 1:
            total_drowsy_sec += 1 / fps_real

        # ======== 可视化 ========
        bar_color = (0, 0, 255) if alarm_active else (0, 200, 0)
        cv2.rectangle(display, (0, 0), (w, 65), bar_color, -1)
        label = 'DROWSY !!!' if alarm_active else 'Awake'
        cv2.putText(display, label, (15, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.8, (0, 0, 0), 3)

        # 疲劳信号积累进度条
        if frame_state == 1 and not alarm_active:
            progress = (frame_idx - fatigue_start_frame) / alarm_delay_frames
            bar_w = int(w * min(progress, 1.0))
            cv2.rectangle(display, (0, 65), (bar_w, 70), (0, 165, 255), -1)

        if feat_ok:
            x1, y1, x2, y2 = map(int, bbox)
            cv2.rectangle(display, (x1, y1), (x2, y2), (255, 200, 0), 2)

            # 关键点 + 眼部 ROI 框
            eye_r = max(int(face_w * 0.12) // 2, 8)
            for i, (kp, name, color) in enumerate(zip(
                kpts, ['L-Eye', 'R-Eye', 'Nose', 'L-Mouth', 'R-Mouth'],
                [(255,0,0),(0,255,0),(0,0,255),(0,255,255),(255,0,255)]
            )):
                px, py = int(kp[0]), int(kp[1])
                cv2.circle(display, (px, py), 3, color, -1)
                if i < 2:  # 画眼部 ROI
                    cv2.rectangle(display,
                                  (max(0, px-eye_r), max(0, py-eye_r)),
                                  (min(w, px+eye_r), min(h, py+eye_r)),
                                  color, 1)

        # 信息面板
        y_pos = h - 90
        for line in [
            f"Eye: {'CLOSED' if (feat_ok and is_eye_closed) else 'open'}",
            f"Mouth: {'YAWN' if (feat_ok and is_yawning) else 'normal'} | MAR:{mar:.3f}",
            f"Head: {'NOD' if (feat_ok and is_nodding) else 'stable'} | Pitch:{pitch:-.0f} Dev:{pitch_deviation:.0f}",
        ]:
            cv2.putText(display, line, (10, y_pos),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
            y_pos += 16

        elapsed = time.perf_counter() - t0
        frame_times.append(elapsed)
        fps = len(frame_times)/sum(frame_times) if sum(frame_times) > 0 else 0
        cv2.putText(display, f'FPS:{fps:.0f}', (w-100, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1)

        out.write(display)
        if not args.no_display:
            cv2.imshow('Fatigue Detection (Hybrid)', display)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        if frame_idx % 50 == 0:
            signals = []
            if feat_ok and is_eye_closed: signals.append('EYE')
            if feat_ok and is_yawning: signals.append('YAWN')
            if feat_ok and is_nodding: signals.append('NOD')
            sig_str = ','.join(signals) if signals else '-'

            eye_info = ''
            if feat_ok:
                eye_info = f'L_cls={left_closed} R_cls={right_closed}'

            log(f'  帧{frame_idx:4d}: {sig_str:20s} {eye_info} '
                  f'MAR={mar:.3f} Pitch={pitch:.0f} Dev={pitch_deviation:.0f} → {LABELS[current_state]}')

    cap.release(); out.release()
    if not args.no_display:
        cv2.destroyAllWindows()

    total_sec = frame_idx / fps_real
    log(f'\n{"="*50}')
    log(f'  推理完成 — {frame_idx} 帧 / {total_sec:.0f} 秒')
    log(f'  疲劳告警: {total_drowsy_sec:.1f} 秒 ({total_drowsy_sec/total_sec*100:.1f}%)' if total_sec>0 else '')
    log(f'  输出:     {out_path}')
    log_fp.close()


if __name__ == '__main__':
    main()
