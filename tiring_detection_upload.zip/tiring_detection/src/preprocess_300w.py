"""
数据预处理: 将 300-W (68点) / WFLW (98点) 转换为 YOLOv11-pose 格式 (5点)

输入: 300-W 数据集 (ibug 格式的 .pts 文件 + 对应图像)
输出: YOLO 格式的标注文件 (.txt) 和图像软链接

YOLO pose 标注格式:
    class_idx cx cy w h kpt1x kpt1y kpt1v kpt2x kpt2y kpt2v ...
每行一张人脸, bbox 和关键点都归一化到 [0, 1]

68点 → 5点的映射:
    左眼中心 = mean(36..41)     # 左眼6个关键点
    右眼中心 = mean(42..47)     # 右眼6个关键点
    鼻尖 = 30                   # 鼻尖
    左嘴角 = 48                  # 左嘴角
    右嘴角 = 54                  # 右嘴角

用法:
    python src/preprocess_300w.py \
        --input_300w /path/to/300W \
        --output /workspace/data/datasets/face_landmarks \
        --val_ratio 0.15
"""
import os
import sys
import argparse
import shutil
from pathlib import Path
import numpy as np
import cv2


# 68点 → 5点索引映射
IDX_68_TO_5 = {
    # 左眼: 索引 36-41 → 取中心
    'left_eye': list(range(36, 42)),
    # 右眼: 索引 42-47 → 取中心
    'right_eye': list(range(42, 48)),
    # 鼻尖: 索引 30
    'nose': [30],
    # 左嘴角: 索引 48
    'left_mouth': [48],
    # 右嘴角: 索引 54
    'right_mouth': [54],
}


def parse_pts_file(pts_path):
    """解析 ibug .pts 文件, 返回 (68, 2) 关键点数组"""
    with open(pts_path, 'r') as f:
        lines = f.readlines()

    # 找到数据行开始位置（跳过 "version", "n_points", "{" 等头部）
    points = []
    in_data = False
    for line in lines:
        line = line.strip()
        if line == '{':
            in_data = True
            continue
        if line == '}':
            break
        if in_data:
            parts = line.split()
            if len(parts) >= 2:
                points.append([float(parts[0]), float(parts[1])])

    return np.array(points, dtype=np.float32)


def convert_68_to_5(pts_68):
    """68点 → 5点"""
    pts_5 = np.zeros((5, 2), dtype=np.float32)
    pts_5[0] = pts_68[IDX_68_TO_5['left_eye']].mean(axis=0)
    pts_5[1] = pts_68[IDX_68_TO_5['right_eye']].mean(axis=0)
    pts_5[2] = pts_68[IDX_68_TO_5['nose']].mean(axis=0)
    pts_5[3] = pts_68[IDX_68_TO_5['left_mouth']].mean(axis=0)
    pts_5[4] = pts_68[IDX_68_TO_5['right_mouth']].mean(axis=0)
    return pts_5


def pts_to_bbox(pts_5):
    """从5点关键点计算包围框"""
    x_min, y_min = pts_5.min(axis=0)
    x_max, y_max = pts_5.max(axis=0)
    # 扩展到正方形
    w, h = x_max - x_min, y_max - y_min
    side = max(w, h) * 1.2  # 留 20% 边距
    cx, cy = (x_min + x_max) / 2, (y_min + y_max) / 2
    x_min, y_min = cx - side / 2, cy - side / 2
    x_max, y_max = cx + side / 2, cy + side / 2
    return x_min, y_min, x_max, y_max


def format_yolo_annotation(pts_5, img_w, img_h):
    """生成 YOLO pose 格式的标注字符串"""
    x_min, y_min, x_max, y_max = pts_to_bbox(pts_5)

    # 归一化 bbox 到 [0, 1]
    cx = ((x_min + x_max) / 2) / img_w
    cy = ((y_min + y_max) / 2) / img_h
    w = (x_max - x_min) / img_w
    h = (y_max - y_min) / img_h

    # clamp
    cx, cy, w, h = max(0, cx), max(0, cy), min(1, w), min(1, h)

    # class_idx + bbox
    parts = [f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}"]

    # 5 个关键点 (x, y, visibility=2 表示可见且标注)
    for i in range(5):
        kx = pts_5[i][0] / img_w
        ky = pts_5[i][1] / img_h
        kx = max(0.0, min(1.0, kx))
        ky = max(0.0, min(1.0, ky))
        parts.append(f"{kx:.6f} {ky:.6f} 2")

    return " ".join(parts)


def process_300w(input_dir, output_dir, val_ratio=0.15):
    """
    处理 300-W 数据集

    期望的输入目录结构:
        input_dir/
          ├── 01_Indoor/
          │   ├── indoor_001.png
          │   ├── indoor_001.pts
          │   └── ...
          ├── 02_Outdoor/
          │   ├── outdoor_001.png
          │   ├── outdoor_001.pts
          │   └── ...
          ...

    输出目录结构 (YOLO 格式):
        output_dir/
          ├── train/
          │   ├── images/
          │   └── labels/
          └── val/
              ├── images/
              └── labels/
    """
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    # 创建输出目录
    for split in ['train', 'val']:
        (output_path / split / 'images').mkdir(parents=True, exist_ok=True)
        (output_path / split / 'labels').mkdir(parents=True, exist_ok=True)

    # 收集所有 (image_path, pts_path) 对
    pairs = []
    for subdir in sorted(input_path.iterdir()):
        if not subdir.is_dir():
            continue
        for pts_file in sorted(subdir.glob('*.pts')):
            # 查找对应图像 (.png, .jpg, .jpeg)
            img_file = None
            for ext in ['.png', '.jpg', '.jpeg', '.PNG', '.JPG']:
                candidate = pts_file.with_suffix(ext)
                if candidate.exists():
                    img_file = candidate
                    break
                # 有些数据集命名不一致，尝试 stem 匹配
                for f in subdir.iterdir():
                    if f.suffix.lower() in ['.png', '.jpg', '.jpeg'] and \
                       f.stem == pts_file.stem:
                        img_file = f
                        break

            if img_file:
                pairs.append((img_file, pts_file))

    if not pairs:
        print(f"[ERROR] 在 {input_dir} 下未找到 .pts + 图像配对文件。")
        print("期望结构: 子目录/xxx.pts + 子目录/xxx.png")
        return

    print(f"找到 {len(pairs)} 个图像-关键点配对")

    # 随机划分 train/val
    np.random.seed(42)
    indices = np.random.permutation(len(pairs))
    val_count = int(len(pairs) * val_ratio)
    val_indices = set(indices[:val_count])

    train_count, val_count = 0, 0
    skipped = 0

    for idx, (img_path, pts_path) in enumerate(pairs):
        split = 'val' if idx in val_indices else 'train'

        try:
            # 解析 68 点
            pts_68 = parse_pts_file(pts_path)
            if len(pts_68) < 68:
                skipped += 1
                continue

            # 读取图像获取尺寸
            img = cv2.imread(str(img_path))
            if img is None:
                skipped += 1
                continue
            h, w = img.shape[:2]

            # 转换 68 → 5
            pts_5 = convert_68_to_5(pts_68)

            # 生成 YOLO 标注
            label_line = format_yolo_annotation(pts_5, w, h)

            # 复制图像 + 写标注
            base_name = img_path.stem
            dst_img = output_path / split / 'images' / f"{base_name}{img_path.suffix}"

            # 避免重名
            counter = 0
            while dst_img.exists():
                counter += 1
                dst_img = output_path / split / 'images' / f"{base_name}_{counter}{img_path.suffix}"

            shutil.copy2(img_path, dst_img)

            label_file = output_path / split / 'labels' / f"{dst_img.stem}.txt"
            with open(label_file, 'w') as f:
                f.write(label_line + '\n')

            if split == 'train':
                train_count += 1
            else:
                val_count += 1

        except Exception as e:
            skipped += 1
            print(f"  跳过 {img_path.name}: {e}")

    print(f"\n完成:")
    print(f"  训练集: {train_count} 张")
    print(f"  验证集: {val_count} 张")
    print(f"  跳过: {skipped} 张")
    print(f"  输出: {output_path}")


def process_wflw(input_dir, output_dir, val_ratio=0.15):
    """
    处理 WFLW 数据集 (98点 → 5点)

    WFLW 98点中:
        左眼: 60-67 (8点) → 取中心
        右眼: 68-75 (8点) → 取中心
        鼻尖: 54
        左嘴角: 76
        右嘴角: 82

    WFLW 数据格式通常是 .txt 标注文件 + 图像在同一目录
    """
    WFLW_IDX_MAP = {
        'left_eye': list(range(60, 68)),
        'right_eye': list(range(68, 76)),
        'nose': [54],
        'left_mouth': [76],
        'right_mouth': [82],
    }

    input_path = Path(input_dir)
    output_path = Path(output_dir)

    for split_name, src_dir in [('train', 'WFLW_train'), ('val', 'WFLW_test')]:
        src = input_path / src_dir
        if not src.exists():
            continue

        dst_img_dir = output_path / split_name / 'images'
        dst_label_dir = output_path / split_name / 'labels'
        dst_img_dir.mkdir(parents=True, exist_ok=True)
        dst_label_dir.mkdir(parents=True, exist_ok=True)

        # WFLW 标注文件: list.txt 或 annotations.txt
        annot_files = list(src.glob('*list*.txt')) + list(src.glob('*annotation*.txt'))
        if not annot_files:
            print(f"[WARN] 在 {src} 中未找到标注文件")
            continue

        count = 0
        with open(annot_files[0], 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split()
                # 格式: image_name x1 y1 x2 y2 ... x98 y98 (可能还有额外属性)
                img_name = parts[0]
                coords = list(map(float, parts[1:]))

                if len(coords) < 196:  # 98点 * 2
                    continue

                pts_98 = np.array(coords[:196]).reshape(98, 2)

                # 98 → 5
                pts_5 = np.zeros((5, 2), dtype=np.float32)
                pts_5[0] = pts_98[WFLW_IDX_MAP['left_eye']].mean(axis=0)
                pts_5[1] = pts_98[WFLW_IDX_MAP['right_eye']].mean(axis=0)
                pts_5[2] = pts_98[WFLW_IDX_MAP['nose']].mean(axis=0)
                pts_5[3] = pts_98[WFLW_IDX_MAP['left_mouth']].mean(axis=0)
                pts_5[4] = pts_98[WFLW_IDX_MAP['right_mouth']].mean(axis=0)

                # 查找图像
                img_file = src / img_name
                if not img_file.exists():
                    # 尝试其他常见路径
                    for ext in ['.jpg', '.png', '.jpeg']:
                        alt = src / f"{img_name}{ext}"
                        if alt.exists():
                            img_file = alt
                            break

                if not img_file.exists():
                    continue

                img = cv2.imread(str(img_file))
                if img is None:
                    continue
                h, w = img.shape[:2]

                label_line = format_yolo_annotation(pts_5, w, h)

                dst_img = dst_img_dir / img_name
                if dst_img.exists():
                    dst_img = dst_img_dir / f"{img_file.stem}_wflw{img_file.suffix}"
                shutil.copy2(img_file, dst_img)

                label_file = dst_label_dir / f"{dst_img.stem}.txt"
                with open(label_file, 'w') as lf:
                    lf.write(label_line + '\n')
                count += 1

        print(f"  WFLW {split_name}: {count} 张")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='300-W/WFLW → YOLO 5点格式转换')
    parser.add_argument('--input_300w', type=str, default='',
                        help='300-W 数据集根目录')
    parser.add_argument('--input_wflw', type=str, default='',
                        help='WFLW 数据集根目录')
    parser.add_argument('--output', type=str, required=True,
                        help='YOLO 格式输出目录')
    parser.add_argument('--val_ratio', type=float, default=0.15,
                        help='验证集比例')
    args = parser.parse_args()

    if args.input_300w and Path(args.input_300w).exists():
        print("=== 处理 300-W 数据集 ===")
        process_300w(args.input_300w, args.output, args.val_ratio)

    if args.input_wflw and Path(args.input_wflw).exists():
        print("=== 处理 WFLW 数据集 ===")
        process_wflw(args.input_wflw, args.output, args.val_ratio)

    if not args.input_300w and not args.input_wflw:
        print("请至少指定 --input_300w 或 --input_wflw")
