"""
司机疲劳检测 — 微调模型推理测试

用法（容器内）:
    python3 /workspace/tiring_detection/src/test_drowsy.py \
        --source /workspace/data/raw_videos/test-video.mp4

    python3 /workspace/tiring_detection/src/test_drowsy.py \
        --source /workspace/data/raw_videos/test-video.mp4 \
        --no-display
"""
import argparse
import sys
import os
import time
from pathlib import Path
from collections import deque, Counter

import cv2
import numpy as np
from ultralytics import YOLO

MODEL_PATH = '/workspace/tiring_detection/outputs/drowsy_detect/weights/best.pt'
OUTPUT_DIR = '/workspace/data/output_video'
LABELS = {0: 'Awake', 1: 'Drowsy'}
TEMP_WINDOW = 30  # 时序平滑窗口（帧）


def main():
    parser = argparse.ArgumentParser(description='司机疲劳检测推理测试')
    parser.add_argument('--source', type=str, required=True,
                        help='视频文件路径或摄像头 ID (0)')
    parser.add_argument('--model', type=str, default=MODEL_PATH,
                        help='模型路径')
    parser.add_argument('--conf', type=float, default=0.4,
                        help='检测置信度阈值')
    parser.add_argument('--no-display', action='store_true',
                        help='不弹窗显示')
    parser.add_argument('--output', type=str, default='',
                        help='输出视频路径 (默认 data/output_video/test_output.mp4)')
    args = parser.parse_args()

    if not Path(args.model).exists():
        print(f'[ERROR] 模型不存在: {args.model}')
        sys.exit(1)

    print(f'模型: {args.model}')
    model = YOLO(args.model)

    # 打开视频源
    if args.source.isdigit():
        cap = cv2.VideoCapture(int(args.source))
    else:
        cap = cv2.VideoCapture(args.source)

    if not cap.isOpened():
        print(f'[ERROR] 无法打开: {args.source}')
        sys.exit(1)

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    src_fps = cap.get(cv2.CAP_PROP_FPS)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f'视频: {w}x{h}, {total_frames} 帧, {src_fps:.1f} fps')

    # 输出视频
    out_path = args.output or f'{OUTPUT_DIR}/test_output.mp4'
    os.makedirs(Path(out_path).parent, exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(out_path, fourcc, src_fps, (w, h))

    # 状态追踪
    state_hist = deque(maxlen=TEMP_WINDOW)
    frame_times = deque(maxlen=30)
    current_state = 0
    frame_count = 0
    drowsy_frames = 0

    print(f'\n推理中... 按 q 退出\n')

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        t0 = time.perf_counter()

        results = model(frame, conf=args.conf, verbose=False)[0]

        display = frame.copy()
        has_detection = False

        if results.boxes is not None and len(results.boxes) > 0:
            boxes = results.boxes.xyxy.cpu().numpy()
            classes = results.boxes.cls.cpu().numpy().astype(int)
            confs = results.boxes.conf.cpu().numpy()

            # 取置信度最高的检测
            best_idx = int(confs.argmax())
            x1, y1, x2, y2 = map(int, boxes[best_idx])
            cls = classes[best_idx]
            conf = confs[best_idx]

            state = cls  # 0=awake, 1=drowsy
            has_detection = True
        else:
            state = -1  # 未检测到人脸

        state_hist.append(state)
        # 时序平滑（过滤-1 = 无检测）
        valid_states = [s for s in state_hist if s >= 0]
        if len(valid_states) >= 10:
            current_state = Counter(valid_states[-10:]).most_common(1)[0][0]

        if current_state == 1:
            drowsy_frames += 1

        # --- 可视化 ---
        colors = [(0, 200, 0), (0, 0, 255)]  # awake=绿, drowsy=红

        # 状态栏
        bar_color = colors[current_state] if has_detection else (128, 128, 128)
        cv2.rectangle(display, (0, 0), (w, 70), bar_color, -1)

        status_text = LABELS.get(current_state, 'No Face')
        if current_state == 1:
            status_text += ' !!!'
        cv2.putText(display, status_text, (15, 52),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.8, (0, 0, 0), 3)

        # bbox + 标签
        if has_detection:
            box_color = colors[cls]
            cv2.rectangle(display, (x1, y1), (x2, y2), box_color, 2)
            label = f'{LABELS[cls]} {conf:.2f}'
            cv2.putText(display, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, box_color, 2)

        # FPS
        elapsed = time.perf_counter() - t0
        frame_times.append(elapsed)
        fps = len(frame_times) / sum(frame_times) if sum(frame_times) > 0 else 0
        cv2.putText(display, f'FPS:{fps:.0f}', (w - 100, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        # 进度
        if total_frames > 0:
            progress = (frame_count + 1) / total_frames * 100
            cv2.putText(display, f'{progress:.0f}%', (w - 80, h - 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

        out.write(display)

        if not args.no_display:
            cv2.imshow('Driver Fatigue Detection (Fine-tuned)', display)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        frame_count += 1
        if frame_count % 100 == 0:
            print(f'  帧 {frame_count}/{total_frames}  FPS:{fps:.1f}  状态:{status_text}')

    cap.release()
    out.release()
    if not args.no_display:
        cv2.destroyAllWindows()

    print(f'\n{"="*50}')
    print(f'  推理完成')
    print(f'{"="*50}')
    print(f'  总帧数:        {frame_count}')
    print(f'  检测到疲劳帧:   {drowsy_frames} ({drowsy_frames/frame_count*100:.1f}%)' if frame_count > 0 else '')
    print(f'  输出视频:      {out_path}')


if __name__ == '__main__':
    main()
