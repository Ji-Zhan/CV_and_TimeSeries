"""
疲劳状态机 — 带滞回的双阈值状态转换

        疲劳信号持续 T_enter 帧
NORMAL ───────────────────────────▶ FATIGUE
FATIGUE ──────────────────────────▶ NORMAL
        正常信号持续 T_exit 帧

对外只输出 NORMAL / FATIGUE 两种状态。
只在状态变化时触发事件回调。
"""

import time
from collections import deque
from enum import Enum


class FatigueState(Enum):
    NORMAL = "NORMAL"
    FATIGUE = "FATIGUE"


class FatigueStateMachine:
    """
    疲劳状态机。

    参数:
        t_enter: 疲劳信号需持续多少帧才进入 FATIGUE (默认 15 帧 ≈ 0.5s @30fps)
        t_exit:  正常信号需持续多少帧才退回 NORMAL  (默认 30 帧 ≈ 1.0s @30fps)
        on_state_change: 可选回调, 签名为 callback(old_state, new_state, timestamp)
    """

    def __init__(self, t_enter: int = 15, t_exit: int = 30,
                 on_state_change=None):
        self.t_enter = t_enter
        self.t_exit = t_exit
        self._on_state_change = on_state_change

        self._state = FatigueState.NORMAL
        self._fatigue_counter = 0   # 连续疲劳帧计数
        self._normal_counter = 0    # 连续正常帧计数
        self._last_change_time = time.time()
        self._state_start_time = time.time()

    # --- public API ---

    @property
    def state(self) -> FatigueState:
        return self._state

    @property
    def is_fatigue(self) -> bool:
        return self._state == FatigueState.FATIGUE

    @property
    def state_duration_sec(self) -> float:
        """当前状态已持续的秒数"""
        return time.time() - self._state_start_time

    def update(self, fatigue_signal: bool) -> FatigueState:
        """
        输入一帧的疲劳信号, 返回当前状态。

        参数:
            fatigue_signal: True = 本帧检测到疲劳特征
        """
        old_state = self._state

        if self._state == FatigueState.NORMAL:
            if fatigue_signal:
                self._fatigue_counter += 1
                self._normal_counter = 0
                if self._fatigue_counter >= self.t_enter:
                    self._state = FatigueState.FATIGUE
                    self._state_start_time = time.time()
                    self._fatigue_counter = 0
                    self._on_change(self._state, old_state)
            else:
                self._fatigue_counter = 0

        else:  # FATIGUE
            if not fatigue_signal:
                self._normal_counter += 1
                self._fatigue_counter = 0
                if self._normal_counter >= self.t_exit:
                    self._state = FatigueState.NORMAL
                    self._state_start_time = time.time()
                    self._normal_counter = 0
                    self._on_change(self._state, old_state)
            else:
                self._normal_counter = 0

        return self._state

    def reset(self):
        """重置状态机到 NORMAL"""
        old = self._state
        self._state = FatigueState.NORMAL
        self._fatigue_counter = 0
        self._normal_counter = 0
        self._state_start_time = time.time()
        if old != FatigueState.NORMAL:
            self._on_change(self._state, old)

    # --- internal ---

    def _on_change(self, new_state: FatigueState, old_state: FatigueState):
        self._last_change_time = time.time()
        if self._on_state_change:
            self._on_state_change(old_state, new_state, self._last_change_time)

    def __repr__(self):
        return (f"FatigueStateMachine(state={self._state.value}, "
                f"fatigue_cnt={self._fatigue_counter}/{self.t_enter}, "
                f"normal_cnt={self._normal_counter}/{self.t_exit})")
