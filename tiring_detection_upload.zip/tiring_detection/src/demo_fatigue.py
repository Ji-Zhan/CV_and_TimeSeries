"""
端到端演示: 用摄像头或视频演示完整的司机疲劳检测 pipeline

用法:
    # 使用摄像头（开发机）
    python src/demo_fatigue.py --source 0 --yolo yolo11n-pose.pt

    # 使用视频文件
    python src/demo_fatigue.py --source data/raw_videos/test_drive.mp4 --yolo yolo11n-pose.pt

    # 使用微调后的模型
    python src/demo_fatigue.py --source 0 --yolo outputs/weights/best.pt

    # 无显示器环境（保存输出视频）
    python src/demo_fatigue.py --source data/raw_videos/test.mp4 --output demo_output.mp4 --no-display
"""
import argparse
import sys
import time
import json
from pathlib import Path
from collections import deque, Counter
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from feature_extraction import FatigueFeatureExtractor
from ultralytics import YOLO


def load_mlp(model_path):
    """加载 MLP 模型（支持 .npz 和 .pkl 格式）"""
    mp = Path(model_path)
    suffix = mp.suffix

    if suffix == '.npz':
        data = np.load(model_path, allow_pickle=True)
        weights = [w.astype(np.float32) for w in data['weights']]
        biases = [b.astype(np.float32) for b in data['biases']]
        scaler_mean = data['scaler_mean'].astype(np.float32)
        scaler_scale = data['scaler_scale'].astype(np.float32)

        def predict(features):
            x = (features.astype(np.float32) - scaler_mean) / scaler_scale
            x = x.reshape(1, -1)
            for i in range(len(weights)):
                x = x @ weights[i] + biases[i]
                if i < len(weights) - 1:
                    x = np.maximum(x, 0)
            return int(np.argmax(x, axis=1)[0])

        return predict

    elif suffix == '.pkl':
        import pickle
        with open(model_path, 'rb') as f:
            bundle = pickle.load(f)
        model = bundle['model']
        scaler = bundle['scaler']

        def predict(features):
            x = scaler.transform(features.reshape(1, -1))
            return int(model.predict(x)[0])

        return predict

    else:
        raise ValueError(f"不支持的模型格式: {suffix}")


def run_demo(args):
    import cv2

    # 初始化
    print(f"加载 YOLO: {args.yolo}")
    yolo = YOLO(args.yolo)

    mlp = None
    if args.mlp and Path(args.mlp).exists():
        print(f"加载 MLP 分类器: {args.mlp}")
        mlp = load_mlp(args.mlp)
    else:
        print("[INFO] 未提供 MLP 模型，使用规则推断疲劳状态")

    extractor = FatigueFeatureExtractor(
        perclos_window=args.perclos_window,
        ear_threshold=args.ear_threshold,
    )

    # 打开视频源
    if args.source.isdigit():
        cap = cv2.VideoCapture(int(args.source))
    else:
        cap = cv2.VideoCapture(args.source)

    if not cap.isOpened():
        print(f"[ERROR] 无法打开视频源: {args.source}")
        return

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"视频: {width}x{height} @ {fps:.1f} fps")

    # 输出视频
    writer = None
    if args.output:
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        writer = cv2.VideoWriter(args.output, fourcc, fps, (width, height))

    # 状态追踪
    state_history = deque(maxlen=args.temporal_window)
    frame_times = deque(maxlen=30)
    current_state = 0
    LABELS = ['Alert', 'Drowsy', 'Sleeping']
    alert_count = 0  # 连续告警帧数

    print("\n运行中... 按 'q' 退出, 按 's' 截图\n")

    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        t0 = time.perf_counter()

        # Step 1: YOLO 检测
        results = yolo(frame, verbose=False)[0]

        feature_dict = None
        detection_ok = False

        if (results.keypoints is not None and len(results.keypoints.xy) > 0 and
                results.boxes is not None and len(results.boxes.conf) > 0):
            best_idx = int(results.boxes.conf.argmax())
            kpts = results.keypoints.xy[best_idx].cpu().numpy()
            bbox = results.boxes.xyxy[best_idx].cpu().numpy()
            conf = float(results.boxes.conf[best_idx])

            if len(kpts) >= 5 and conf > 0.5:
                detection_ok = True

                # Step 2: 特征提取
                feature_dict = extractor.extract(kpts[:5])

                # Step 3: 分类
                if mlp and feature_dict:
                    fv = feature_dict['feature_vector']
                    state = mlp(fv)
                else:
                    # 规则推断
                    state = rule_based_classify(feature_dict)

                state_history.append(state)

                # Step 4: 时序平滑
                if len(state_history) >= 10:
                    state = Counter(list(state_history)[-10:]).most_common(1)[0][0]

                current_state = state

                # 告警计数器
                if current_state >= 1:
                    alert_count += 1
                else:
                    alert_count = max(0, alert_count - 1)

        # FPS
        elapsed = time.perf_counter() - t0
        frame_times.append(elapsed)
        current_fps = len(frame_times) / sum(frame_times) if sum(frame_times) > 0 else 0

        # === 可视化 ===
        display = frame.copy()
        h, w = display.shape[:2]

        # 顶部状态条
        colors = [(0, 200, 0), (0, 220, 220), (0, 0, 255)]
        color = colors[current_state]
        cv2.rectangle(display, (0, 0), (w, 75), color, -1)
        cv2.rectangle(display, (0, 75), (w, 78), (0, 0, 0), -1)  # 分隔线

        status_text = LABELS[current_state]
        if alert_count > args.alert_delay:
            status_text += " !!!"
        cv2.putText(display, status_text, (15, 55),
                    cv2.FONT_HERSHEY_SIMPLEX, 2.0, (0, 0, 0), 3)

        # 右侧: FPS
        cv2.putText(display, f"FPS: {current_fps:.0f}", (w - 120, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        # 底部: 特征信息
        if feature_dict:
            y_pos = h - 110
            info_lines = [
                f"EAR: {feature_dict['ear']:.4f}  {'(CLOSED)' if feature_dict['is_eye_closed'] else '(open)'}",
                f"MAR: {feature_dict['mar']:.4f}  {'(YAWN)' if feature_dict['is_yawning'] else '(normal)'}",
                f"PERCLOS: {feature_dict['perclos']:.3f}",
                f"Pose: P={feature_dict['pitch']:.1f} Y={feature_dict['yaw']:.1f} R={feature_dict['roll']:.1f}",
            ]
            for line in info_lines:
                cv2.putText(display, line, (10, y_pos),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
                y_pos += 18

        # 人脸框 + 关键点
        if detection_ok and 'bbox' in dir():
            x1, y1, x2, y2 = map(int, bbox)
            cv2.rectangle(display, (x1, y1), (x2, y2), (255, 200, 0), 2)

            # 关键点
            kp_colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (0, 255, 255), (255, 0, 255)]
            kp_names = ['L-Eye', 'R-Eye', 'Nose', 'L-Mouth', 'R-Mouth']
            for i, kp in enumerate(kpts[:5]):
                px, py = int(kp[0]), int(kp[1])
                cv2.circle(display, (px, py), 4, kp_colors[i], -1)
                cv2.putText(display, kp_names[i], (px + 5, py),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, kp_colors[i], 1)

        # 显示/保存
        if not args.no_display:
            cv2.imshow('Driver Fatigue Detection (tiring_detection)', display)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                screenshot = f"screenshot_{frame_count:06d}.jpg"
                cv2.imwrite(screenshot, display)
                print(f"截图: {screenshot}")

        if writer:
            writer.write(display)

        frame_count += 1

        if frame_count % 100 == 0:
            print(f"  已处理 {frame_count} 帧... FPS: {current_fps:.1f}")

    # 清理
    cap.release()
    if writer:
        writer.release()
    if not args.no_display:
        cv2.destroyAllWindows()

    print(f"\n=== 演示完成 ===")
    print(f"总帧数: {frame_count}")
    print(f"平均 FPS: {current_fps:.1f}")

    if args.output:
        print(f"输出视频: {args.output}")


def rule_based_classify(feature_dict):
    """基于规则的疲劳分级（无 MLP 时使用）"""
    perclos = feature_dict['perclos']
    is_yawning = feature_dict['is_yawning']
    pitch = abs(feature_dict['pitch'])

    # 头部下垂角度 > 25度 → 重度疲劳
    if pitch > 25 or perclos > 0.4:
        return 2  # Sleeping

    # PERCLOS > 0.2 或 打哈欠 → 轻度疲劳
    if perclos > 0.15 or is_yawning:
        return 1  # Drowsy

    return 0  # Alert


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='司机疲劳检测端到端演示')
    parser.add_argument('--source', type=str, default='0',
                        help='摄像头 ID (默认 0) 或视频文件路径')
    parser.add_argument('--yolo', type=str, default='yolo11n-pose.pt',
                        help='YOLO 模型路径')
    parser.add_argument('--mlp', type=str, default='',
                        help='MLP 分类器路径 (.npz / .pkl)')
    parser.add_argument('--perclos_window', type=int, default=90,
                        help='PERCLOS 滑动窗口帧数')
    parser.add_argument('--ear_threshold', type=float, default=0.18,
                        help='EAR 闭眼阈值')
    parser.add_argument('--temporal_window', type=int, default=30,
                        help='疲劳状态时序平滑窗口')
    parser.add_argument('--alert_delay', type=int, default=15,
                        help='连续告警多少帧后触发强烈告警')
    parser.add_argument('--output', type=str, default='',
                        help='保存输出视频路径')
    parser.add_argument('--no_display', action='store_true',
                        help='无头模式 (不显示窗口，配合 --output 使用)')
    args = parser.parse_args()

    try:
        run_demo(args)
    except KeyboardInterrupt:
        print("\n已中断")
