"""
本地告警处理器 — 截图、录像片段保存。

用法:
    handler = AlertHandler(output_dir="/workspace/data")
    handler.save_screenshot(frame)
    clip_path = handler.save_clip(frame_buffer, fps=30)
"""

import os
import time
from datetime import datetime
from pathlib import Path
from collections import deque

import cv2
import numpy as np


class AlertHandler:
    """疲劳告警时的本地多媒体记录"""

    def __init__(self, output_dir: str = "/workspace/data",
                 clip_before_sec: float = 2.0,
                 clip_after_sec: float = 2.0):
        self.output_dir = Path(output_dir)
        self.screenshot_dir = self.output_dir / "screenshots"
        self.clip_dir = self.output_dir / "clips"
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self.clip_dir.mkdir(parents=True, exist_ok=True)

        self.clip_before_sec = clip_before_sec
        self.clip_after_sec = clip_after_sec

    def save_screenshot(self, frame: np.ndarray) -> str:
        """保存告警截图, 返回文件路径"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = str(self.screenshot_dir / f"alert_{ts}.jpg")
        cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        return path

    def save_clip(self, frame_buffer: deque, fps: float = 30.0) -> str:
        """
        从环形帧缓冲区保存前后 N 秒的视频片段, 返回文件路径。

        frame_buffer 中每项为 (timestamp, frame) 元组
        """
        if not frame_buffer:
            return ""

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = str(self.clip_dir / f"alert_{ts}.mp4")

        # 取最近 clip_before_sec + clip_after_sec 秒的帧
        total_frames = int((self.clip_before_sec + self.clip_after_sec) * fps)
        frames_to_write = list(frame_buffer)[-total_frames:]

        if not frames_to_write:
            return ""

        h, w = frames_to_write[0][1].shape[:2]
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        writer = cv2.VideoWriter(path, fourcc, fps, (w, h))

        for _, frm in frames_to_write:
            writer.write(frm)
        writer.release()

        return path
