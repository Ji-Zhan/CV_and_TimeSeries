"""
从视频数据集批量提取疲劳特征 (EAR, MAR, Head Pose)

输入: NTHU-DDD / YawDD 视频 + 微调后的 YOLO 模型
输出: 每帧的特征向量 + 标签, 保存为 .npy 文件供 MLP 训练

用法:
    python src/extract_dataset_features.py \
        --model outputs/weights/best.pt \
        --dataset data/datasets/NTHU-DDD \
        --output outputs/features/nthu_features.npz
"""
import argparse
from pathlib import Path
import numpy as np
import cv2
import sys
from collections import deque

sys.path.insert(0, str(Path(__file__).parent))
from feature_extraction import FatigueFeatureExtractor, eye_aspect_ratio, mouth_aspect_ratio, compute_head_pose
from ultralytics import YOLO


def extract_from_video(video_path, model, extractor, max_frames=None, stride=1):
    """
    从单个视频提取特征的生成器

    Args:
        video_path: 视频文件路径
        model: YOLO 模型
        extractor: FatigueFeatureExtractor
        max_frames: 最多处理帧数
        stride: 帧间隔 (stride=3 表示每3帧处理1帧)

    Yields:
        (frame_idx, feature_vector, keypoints_dict)
    """
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"  [WARN] 无法打开视频: {video_path}")
        return

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    frame_idx = 0
    processed = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_idx % stride != 0:
            frame_idx += 1
            continue

        results = model(frame, verbose=False)[0]

        if results.keypoints is not None and len(results.keypoints.xy) > 0:
            # 取置信度最高的人脸
            if results.boxes is not None and len(results.boxes.conf) > 0:
                best_idx = int(results.boxes.conf.argmax())
                kpts = results.keypoints.xy[best_idx].cpu().numpy()
            else:
                kpts = results.keypoints.xy[0].cpu().numpy()

            if len(kpts) >= 5:
                feat = extractor.extract(kpts[:5])
                yield frame_idx, feat, {
                    'keypoints': kpts[:5],
                    'ear': feat['ear'],
                    'mar': feat['mar'],
                    'pitch': feat['pitch'],
                    'yaw': feat['yaw'],
                    'roll': feat['roll'],
                }
                processed += 1

        frame_idx += 1
        if max_frames and processed >= max_frames:
            break

    cap.release()
    print(f"  提取: {processed}/{frame_idx} 帧有效 (总 {total_frames} 帧 @ {fps:.1f} FPS)")


def extract_nthu_ddd(dataset_root, model, output_path):
    """
    处理 NTHU-DDD 数据集

    NTHU-DDD 目录结构:
        dataset_root/
          Training Dataset/
            evaluation/
              1_1_1_1.avi  (subject_scenario_glasses_illumination)
            ground_truth/
              1_1_1_1.txt   (每帧标注: 0=non-drowsy, 1=drowsy, 2=unknown)
          Testing Dataset/
            ...

    场景命名规则 (5 种场景):
        1: normal (正常)      2: talking (说话)
        3: yawning (哈欠)    4: slow blink (慢眨眼)
        5: nodding (点头)

    光照/眼镜:
        glasses: 0=none, 1=with glasses
        illumination: 0=day, 1=night
    """
    root = Path(dataset_root)
    extractor = FatigueFeatureExtractor()

    all_features = []
    all_labels = []
    metadata = []  # (video_name, frame_idx)

    # 查找所有训练视频
    video_dirs = [
        root / 'Training Dataset' / 'evaluation',
        root / 'Training Dataset',
    ]

    # NTHU-DDD 有基于场景和条件的目录结构。先尝试找到所有 .avi 文件。
    avi_files = []
    for d in video_dirs:
        if d.exists():
            avi_files.extend(d.rglob('*.avi'))
            avi_files.extend(d.rglob('*.mp4'))

    if not avi_files:
        # 备选: 直接扫描整个目录
        avi_files = list(root.rglob('*.avi')) + list(root.rglob('*.mp4'))

    print(f"找到 {len(avi_files)} 个视频文件")

    for video_path in sorted(avi_files):
        print(f"\n处理: {video_path.name}")

        # 查找对应的 ground truth 文件
        gt_candidates = [
            root / 'Training Dataset' / 'ground_truth' / f"{video_path.stem}.txt",
            root / 'Training Dataset' / 'groundtruth' / f"{video_path.stem}.txt",
            root / 'Training Dataset' / 'label' / f"{video_path.stem}.txt",
        ]
        gt_file = None
        for c in gt_candidates:
            if c.exists():
                gt_file = c
                break

        # 确定标签 — 从文件名推断场景
        # 格式: subject_scenario_glasses_illumination
        parts = video_path.stem.split('_')
        scenario = int(parts[1]) if len(parts) >= 2 else 0

        # NTHU-DDD 场景映射为疲劳等级
        # 1=baseline, 3=yawning, 4=slow_blink, 5=nodding → drowsy signals
        if scenario in [3, 4, 5]:
            default_label = 2  # Drowsy/Sleeping
        elif scenario == 1:
            default_label = 0  # Alert
        else:
            default_label = 1  # Low vigilant

        # 如果没有标注文件，使用场景标签
        has_frame_labels = False
        frame_labels = {}
        if gt_file:
            try:
                with open(gt_file) as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            p = line.split(',')
                            if len(p) >= 1:
                                frame_labels[int(p[0])] = int(p[0]) if len(p) == 1 else int(p[1])
                has_frame_labels = True
            except Exception:
                pass

        for frame_idx, feat, kp_data in extract_from_video(video_path, model, extractor):
            fv = feat['feature_vector']  # [ear, mar, pitch, yaw, roll]

            if has_frame_labels and frame_idx in frame_labels:
                label = frame_labels[frame_idx]
                # NTHU 标注: 0=still, 1=drowsy → 映射
                label = 0 if label == 0 else 2
            else:
                label = default_label

            all_features.append(fv)
            all_labels.append(label)
            metadata.append((video_path.name, frame_idx))

    features_arr = np.array(all_features, dtype=np.float32)
    labels_arr = np.array(all_labels, dtype=np.int32)

    print(f"\n总计提取: {len(all_features)} 帧有效特征")

    # 保存
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        output_path,
        features=features_arr,
        labels=labels_arr,
        metadata=metadata,
        feature_names=['ear', 'mar', 'pitch', 'yaw', 'roll'],
        label_names=['alert', 'drowsy', 'sleeping'],
    )
    print(f"特征已保存: {output_path}")

    # 统计
    unique, counts = np.unique(labels_arr, return_counts=True)
    print("标签分布:")
    names = ['Alert', 'Drowsy', 'Sleeping']
    for u, c in zip(unique, counts):
        print(f"  {names[u]}: {c} 帧 ({c/len(labels_arr)*100:.1f}%)")


def extract_yawdd(dataset_root, model, output_path):
    """
    处理 YawDD 数据集

    YawDD 包含两组视频:
        Dataset/Female/  — 女性驾驶员打哈欠视频
        Dataset/Male/    — 男性驾驶员打哈欠视频

    视频命名: <id>-<state>.avi
        state: 0=normal, 1=talking, 2=yawning
    """
    root = Path(dataset_root)
    extractor = FatigueFeatureExtractor()

    all_features = []
    all_labels = []
    metadata = []

    avi_files = list(root.rglob('*.avi')) + list(root.rglob('*.mp4')) + list(root.rglob('*.mov'))

    # 有些版本 YawDD 视频直接放在根目录
    if not avi_files:
        for subdir in root.iterdir():
            if subdir.is_dir():
                avi_files.extend(subdir.rglob('*.avi'))
                avi_files.extend(subdir.rglob('*.mp4'))

    print(f"找到 {len(avi_files)} 个视频")

    for video_path in sorted(avi_files):
        print(f"\n处理: {video_path.name}")

        # 从文件名推断状态
        stem = video_path.stem
        if 'yawn' in stem.lower() or 'YawDD' in stem:
            default_label = 2  # Drowsy — 哈欠 = 疲劳信号
        elif 'talk' in stem.lower():
            default_label = 0  # Alert — 说话不算疲劳
        else:
            default_label = 0  # 默认正常

        for frame_idx, feat, kp_data in extract_from_video(video_path, model, extractor, stride=3):
            all_features.append(feat['feature_vector'])
            all_labels.append(default_label)
            metadata.append((video_path.name, frame_idx))

    features_arr = np.array(all_features, dtype=np.float32)
    labels_arr = np.array(all_labels, dtype=np.int32)

    print(f"\n总计提取: {len(all_features)} 帧")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        output_path,
        features=features_arr,
        labels=labels_arr,
        metadata=metadata,
        feature_names=['ear', 'mar', 'pitch', 'yaw', 'roll'],
    )
    print(f"特征已保存: {output_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='从视频数据集提取疲劳特征')
    parser.add_argument('--model', type=str, required=True,
                        help='微调后的 YOLO 模型路径')
    parser.add_argument('--dataset', type=str, required=True,
                        help='数据集根目录 (NTHU-DDD 或 YawDD)')
    parser.add_argument('--dataset_type', type=str, default='nthu',
                        choices=['nthu', 'yawdd'],
                        help='数据集类型')
    parser.add_argument('--output', type=str, default='outputs/features/features.npz',
                        help='输出特征文件路径')
    args = parser.parse_args()

    print(f"加载模型: {args.model}")
    model = YOLO(args.model)

    if args.dataset_type == 'nthu':
        extract_nthu_ddd(args.dataset, model, args.output)
    else:
        extract_yawdd(args.dataset, model, args.output)
