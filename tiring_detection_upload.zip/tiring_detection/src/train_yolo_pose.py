"""
YOLOv11n-pose 微调脚本 — 人脸关键点检测

在 300-W/WFLW 上微调，让 YOLO 在驾驶员近距人脸场景精准定位五官。

用法:
    # 容器内运行
    python src/train_yolo_pose.py --data configs/face_5pts.yaml --epochs 50

    # 或直接用 yolo 命令
    yolo pose train data=configs/face_5pts.yaml model=yolo11n-pose.pt epochs=50 imgsz=320
"""
import argparse
from pathlib import Path
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser(description='微调 YOLOv11n-pose 人脸关键点检测')
    parser.add_argument('--model', type=str, default='yolo11n-pose.pt',
                        help='预训练模型 (yolo11n-pose.pt / yolo11s-pose.pt)')
    parser.add_argument('--data', type=str, default='configs/face_5pts.yaml',
                        help='数据集配置文件')
    parser.add_argument('--epochs', type=int, default=50, help='训练轮数')
    parser.add_argument('--imgsz', type=int, default=320,
                        help='输入分辨率 (驾驶员人脸近距，320 足够)')
    parser.add_argument('--batch', type=int, default=64, help='批量大小')
    parser.add_argument('--lr0', type=float, default=0.001, help='初始学习率')
    parser.add_argument('--lrf', type=float, default=0.01, help='最终学习率因子')
    parser.add_argument('--freeze', type=int, default=6,
                        help='冻结 backbone 前 N 层 (0=全量训练)')
    parser.add_argument('--device', type=str, default='0', help='GPU 设备')
    parser.add_argument('--output', type=str, default='outputs/weights',
                        help='输出目录')
    parser.add_argument('--no_augment', action='store_true',
                        help='关闭数据增强 (调试用)')
    args = parser.parse_args()

    # 检查数据集是否存在
    data_yaml = Path(args.data)
    if not data_yaml.exists():
        print(f"[ERROR] 数据集配置文件不存在: {args.data}")
        print("请先运行: python src/preprocess_300w.py --input_300w <path> --output <path>")
        return

    # 加载预训练模型
    print(f"加载预训练模型: {args.model}")
    model = YOLO(args.model)

    # 训练配置
    train_args = {
        'data': str(data_yaml.absolute()),
        'epochs': args.epochs,
        'imgsz': args.imgsz,
        'batch': args.batch,
        'lr0': args.lr0,
        'lrf': args.lrf,
        'freeze': args.freeze,
        'device': args.device,
        'project': str(Path(args.output).parent),
        'name': Path(args.output).name,
        'exist_ok': True,
        'pretrained': True,
        'verbose': True,
    }

    if not args.no_augment:
        # 针对 DMS 驾驶场景的数据增强
        train_args.update({
            'hsv_h': 0.0,       # 关闭色调增强 (IR 摄像头无色相)
            'hsv_s': 0.05,      # 极小饱和度变化
            'hsv_v': 0.35,      # 亮度变化 (模拟过曝/欠曝/夜视)
            'degrees': 10.0,    # 小角度旋转 (司机头部偏转范围有限)
            'translate': 0.1,   # 小幅度平移
            'scale': 0.3,       # 缩放
            'shear': 2.0,       # 剪切
            'perspective': 0.0,
            'flipud': 0.0,
            'fliplr': 0.5,      # 水平翻转
            'mosaic': 0.5,
            'mixup': 0.0,
            'copy_paste': 0.0,
        })

    print(f"\n开始训练:")
    print(f"  数据集: {args.data}")
    print(f"  Epochs: {args.epochs}")
    print(f"  分辨率: {args.imgsz}")
    print(f"  Batch: {args.batch}")
    print(f"  冻结前 {args.freeze} 层")
    print(f"  学习率: {args.lr0} → {args.lr0 * args.lrf:.6f}")

    results = model.train(**train_args)

    print(f"\n训练完成!")
    print(f"  最佳模型: {results.save_dir}/weights/best.pt")

    # 验证
    print("\n运行验证...")
    metrics = model.val()
    print(f"  mAP@50: {metrics.box.map50:.4f}")
    print(f"  mAP@50-95: {metrics.box.map:.4f}")


if __name__ == '__main__':
    main()
