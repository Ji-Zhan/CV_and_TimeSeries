"""
将 sklearn 训练的疲劳分类器导出为 ONNX

MLP/SVM → ONNX → 可用于 Jetson TensorRT 推理

用法:
    python src/export_classifier_onnx.py \
        --model outputs/fatigue_mlp.pkl \
        --output outputs/onnx/fatigue_mlp.onnx
"""
import argparse
from pathlib import Path
import pickle
import numpy as np

try:
    from skl2onnx import convert_sklearn
    from skl2onnx.common.data_types import FloatTensorType
    HAS_SKL2ONNX = True
except ImportError:
    HAS_SKL2ONNX = False
    print("[WARN] skl2onnx 未安装。将使用纯 NumPy 替代方案。")


def export_skl2onnx(model, scaler, output_path, n_features=5):
    """使用 skl2onnx 导出 sklearn MLP 为 ONNX"""
    from onnx import save

    # 先导出分类器
    initial_type = [('features', FloatTensorType([None, n_features]))]
    onnx_model = convert_sklearn(model, 'fatigue_classifier', initial_type)

    save(onnx_model, output_path)
    print(f"ONNX 模型已保存: {output_path}")
    print(f"  输入: features (float32, shape=[N, {n_features}])")
    print(f"  输出: 见模型内部")

    return output_path


def export_numpy_fallback(model, scaler, output_path, n_features=5):
    """
    简洁回退方案: 将 MLP 权重/偏置导出为 npz。
    在 Jetson 端直接用手写前向传播 (几个矩阵乘法 + ReLU + softmax)，
    推理速度一样快且无需 ONNX Runtime 依赖。
    """
    weights = []
    biases = []

    if hasattr(model, 'coefs_'):
        # sklearn MLP: coefs_ + intercepts_
        for i, (w, b) in enumerate(zip(model.coefs_, model.intercepts_)):
            weights.append(w.astype(np.float32))
            biases.append(b.astype(np.float32))
    elif hasattr(model, 'support_vectors_'):
        # SVM — 太复杂，建议安装 skl2onnx
        print("[ERROR] SVM 导出需要 skl2onnx。请: pip install skl2onnx")
        return None

    np.savez(
        output_path,
        weights=weights,
        biases=biases,
        scaler_mean=scaler.mean_.astype(np.float32),
        scaler_scale=scaler.scale_.astype(np.float32),
        classes=model.classes_.astype(np.int32) if hasattr(model, 'classes_') else np.array([0, 1, 2]),
    )
    print(f"模型权重已导出 (NumPy 方案): {output_path}")
    print(f"  层数: {len(weights)}")
    print(f"  各层形状: {[w.shape for w in weights]}")

    # 同时生成推理代码
    generate_inference_code(weights, biases, output_path)
    return output_path


def generate_inference_code(weights, biases, output_path):
    """为 NumPy 方案生成纯 Python 推理函数"""
    code_path = Path(output_path).with_suffix('.py')
    n_layers = len(weights)

    lines = [
        '"""自动生成的 MLP 推理代码 — 可在 Jetson 上直接使用"""',
        'import numpy as np',
        '',
        '# 模型权重 (从训练时冻结)',
    ]

    for i, w in enumerate(weights):
        lines.append(f'W{i} = np.array({w.tolist()}, dtype=np.float32)')
    for i, b in enumerate(biases):
        lines.append(f'B{i} = np.array({b.tolist()}, dtype=np.float32)')

    lines.append('')
    lines.append('')
    lines.append('def predict(features):')
    lines.append('    """')
    lines.append('    Args:')
    lines.append('        features: np.array shape (5,) — [ear, mar, pitch, yaw, roll]')
    lines.append('    Returns:')
    lines.append('        int — 0=Alert, 1=Drowsy, 2=Sleeping')
    lines.append('    """')
    lines.append('    x = features.astype(np.float32).reshape(1, -1)')

    for i in range(n_layers):
        lines.append(f'    x = x @ W{i} + B{i}')
        if i < n_layers - 1:
            lines.append(f'    x = np.maximum(x, 0)  # ReLU')

    lines.append('    return int(np.argmax(x, axis=1)[0])')
    lines.append('')
    lines.append('')
    lines.append('LABELS = ["Alert", "Drowsy", "Sleeping"]')

    with open(code_path, 'w') as f:
        f.write('\n'.join(lines))
    print(f"推理代码已生成: {code_path}")


def main():
    parser = argparse.ArgumentParser(description='导出疲劳分类器为 ONNX')
    parser.add_argument('--model', type=str, required=True,
                        help='sklearn 模型 .pkl 路径')
    parser.add_argument('--output', type=str, default='outputs/onnx/fatigue_mlp.onnx',
                        help='输出 ONNX 路径')
    parser.add_argument('--n_features', type=int, default=5,
                        help='输入特征数')
    args = parser.parse_args()

    # 加载模型
    with open(args.model, 'rb') as f:
        data = pickle.load(f)
        model = data['model']
        scaler = data['scaler']

    print(f"模型类型: {type(model).__name__}")
    print(f"特征数: {args.n_features}")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # 尝试 skl2onnx
    if HAS_SKL2ONNX:
        export_skl2onnx(model, scaler, str(output_path), args.n_features)
    else:
        # 回退到 NumPy
        npz_path = output_path.with_suffix('.npz')
        export_numpy_fallback(model, scaler, str(npz_path), args.n_features)

    # 总是也导出 NumPy 版本（轻量，方便 Jetson 端使用）
    npz_path = output_path.with_suffix('.npz')
    print(f"\n附带导出 NumPy 权重: {npz_path}")
    export_numpy_fallback(model, scaler, str(npz_path), args.n_features)


if __name__ == '__main__':
    main()
