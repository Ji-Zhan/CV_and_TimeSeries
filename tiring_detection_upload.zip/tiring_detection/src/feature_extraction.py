"""
司机疲劳检测 — 几何特征提取模块
EAR (眼睛纵横比) / MAR (嘴巴纵横比) / Head Pose (头部姿态) / PERCLOS
纯数值计算，无模型依赖，可在 Jetson CPU 上直接运行
"""
import numpy as np
from collections import deque

# 5点关键点索引: 0=左眼, 1=右眼, 2=鼻尖, 3=左嘴角, 4=右嘴角

# 3D 人脸参考点（标准人脸模型，用于 SolvePnP）
FACE_3D_POINTS = np.array([
    [-30.0, -30.0, -30.0],   # 左眼
    [ 30.0, -30.0, -30.0],   # 右眼
    [  0.0,   0.0,   0.0],   # 鼻尖
    [-25.0,  20.0, -20.0],   # 左嘴角
    [ 25.0,  20.0, -20.0],   # 右嘴角
], dtype=np.float64)


def eye_aspect_ratio(landmarks):
    """
    EAR = (|p1-p5| + |p2-p4|) / (2 * |p0-p3|)
    对于 5 点关键点，用双眼关键点 + 鼻尖 + 嘴角来近似:
    左右眼各算一个简化的 EAR，取均值

    landmarks: (5, 2)  — [左眼, 右眼, 鼻尖, 左嘴角, 右嘴角]

    由于我们只有 5 个点(每眼仅1个中心点)，无法精确计算眼睑距离。
    此处通过 YOLO 输出的 bbox 来辅助判断: 如果检测到人脸但关键点置信度低 = 可能闭眼。
    更实用的做法: 依赖 YOLO 对人脸区域的检测 + 眼部区域裁剪后做分类。

    简化版 EAR:
    用左眼点相对于鼻尖和嘴角构成的"面部十字"来估算眼睛开合度。
    更好的方式: 从人脸 bbox 中裁剪眼部区域，用像素统计判断。
    """
    pts = np.array(landmarks, dtype=np.float64)
    left_eye = pts[0]
    right_eye = pts[1]
    nose = pts[2]
    left_mouth = pts[3]
    right_mouth = pts[4]

    # 眼睛到鼻尖的垂直距离（归一化）
    eye_mid = (left_eye + right_eye) / 2.0
    mouth_mid = (left_mouth + right_mouth) / 2.0
    face_height = np.linalg.norm(eye_mid - mouth_mid) + 1e-6

    left_eye_to_nose = np.linalg.norm(left_eye - nose)
    right_eye_to_nose = np.linalg.norm(right_eye - nose)

    # 归一化后的眼睛-鼻子距离，眼睛闭合时该值会变化
    ear = (left_eye_to_nose + right_eye_to_nose) / (2.0 * face_height)
    return float(ear)


def eye_aspect_ratio_from_6points(p1, p2, p3, p4, p5, p6):
    """
    标准 EAR 计算 (需要每只眼 6 个关键点 — 上下眼睑)
    p1-p6: 左眼周围的 6 个点 (从眼角开始顺时针)
    EAR = (‖p2-p6‖ + ‖p3-p5‖) / (2 * ‖p1-p4‖)
    """
    def _ear(p):
        vertical_1 = np.linalg.norm(p[1] - p[5])
        vertical_2 = np.linalg.norm(p[2] - p[4])
        horizontal = np.linalg.norm(p[0] - p[3])
        return (vertical_1 + vertical_2) / (2.0 * horizontal + 1e-6)
    return _ear


def mouth_aspect_ratio(landmarks):
    """
    MAR = 嘴高 / 嘴宽
    使用 5 点中的左右嘴角 + 鼻尖(近似上唇)来估计
    """
    pts = np.array(landmarks, dtype=np.float64)
    left_mouth = pts[3]
    right_mouth = pts[4]
    nose = pts[2]

    mouth_width = np.linalg.norm(left_mouth - right_mouth) + 1e-6
    # 鼻尖到嘴角连线中点的距离作为嘴高的近似
    mouth_mid = (left_mouth + right_mouth) / 2.0
    mouth_height = np.linalg.norm(nose - mouth_mid)

    mar = mouth_height / mouth_width
    return float(mar)


def compute_head_pose(landmarks, camera_matrix=None, dist_coeffs=None):
    """
    使用 5 点 2D 关键点 + 3D 人脸参考模型，通过 SolvePnP 估计头部姿态。

    返回: (pitch, yaw, roll) — 单位: 度
    pitch: 上下点头 (>0 抬头, <0 低头)
    yaw: 左右转头 (>0 向右, <0 向左)
    roll: 左右歪头 (>0 向右歪, <0 向左歪)
    """
    if camera_matrix is None:
        # 默认相机内参 (640x480 摄像头)
        camera_matrix = np.array([
            [640, 0, 320],
            [0, 640, 240],
            [0, 0, 1]
        ], dtype=np.float64)

    if dist_coeffs is None:
        dist_coeffs = np.zeros((4, 1), dtype=np.float64)

    pts_2d = np.array(landmarks, dtype=np.float64).reshape(5, 2)

    success, rvec, tvec = cv2.solvePnP(
        FACE_3D_POINTS, pts_2d, camera_matrix, dist_coeffs,
        flags=cv2.SOLVEPNP_EPNP
    )

    if not success:
        return 0.0, 0.0, 0.0

    rmat, _ = cv2.Rodrigues(rvec)

    # 从旋转矩阵提取欧拉角
    sy = np.sqrt(rmat[0, 0] ** 2 + rmat[1, 0] ** 2)
    singular = sy < 1e-6

    if not singular:
        pitch = np.arctan2(-rmat[2, 0], sy)
        yaw = np.arctan2(rmat[1, 0], rmat[0, 0])
        roll = np.arctan2(rmat[2, 1], rmat[2, 2])
    else:
        pitch = np.arctan2(-rmat[2, 0], sy)
        yaw = np.arctan2(-rmat[0, 1], rmat[1, 1])
        roll = 0.0

    return np.degrees(pitch), np.degrees(yaw), np.degrees(roll)


# 需要 cv2 所以延迟 import
import cv2


class PERCLOS:
    """PERCLOS (Percentage of Eye Closure) 滑动窗口计算器"""

    def __init__(self, window_size=90, ear_threshold=0.18):
        """
        window_size: 滑动窗口帧数 (90帧 @30fps = 3秒)
        ear_threshold: EAR 低于此值判定为闭眼
        """
        self.window = deque(maxlen=window_size)
        self.threshold = ear_threshold

    def update(self, ear_value):
        closed = 1.0 if ear_value < self.threshold else 0.0
        self.window.append(closed)

    @property
    def value(self):
        """返回当前 PERCLOS 值 (0.0 ~ 1.0)"""
        if len(self.window) == 0:
            return 0.0
        return sum(self.window) / len(self.window)

    @property
    def is_closed(self):
        """当前帧是否闭眼"""
        if len(self.window) == 0:
            return False
        return self.window[-1] == 1.0


class FatigueFeatureExtractor:
    """
    一站式疲劳特征提取器

    用法:
        extractor = FatigueFeatureExtractor()
        features = extractor.extract(keypoints_5pts)
        # features: {ear, mar, pitch, yaw, roll, perclos, is_eye_closed}
    """

    def __init__(self, perclos_window=90, ear_threshold=0.18, mar_threshold=0.55,
                 camera_matrix=None):
        self.perclos = PERCLOS(perclos_window, ear_threshold)
        self.ear_threshold = ear_threshold
        self.mar_threshold = mar_threshold
        self.camera_matrix = camera_matrix
        self._frame_count = 0

    def extract(self, keypoints):
        """
        keypoints: (5, 2) array — [左眼, 右眼, 鼻尖, 左嘴角, 右嘴角]

        返回 dict:
            ear: 眼睛纵横比
            mar: 嘴巴纵横比
            pitch, yaw, roll: 头部欧拉角(度)
            perclos: PERCLOS 值
            is_eye_closed: 当前帧是否闭眼
            is_yawning: 当前帧是否哈欠
            feature_vector: [ear, mar, pitch, yaw, roll] 用于 MLP
        """
        kpts = np.array(keypoints, dtype=np.float64)

        ear = eye_aspect_ratio(kpts)
        mar = mouth_aspect_ratio(kpts)
        pitch, yaw, roll = compute_head_pose(kpts, self.camera_matrix)

        self.perclos.update(ear)

        self._frame_count += 1

        return {
            'ear': round(ear, 4),
            'mar': round(mar, 4),
            'pitch': round(pitch, 2),
            'yaw': round(yaw, 2),
            'roll': round(roll, 2),
            'perclos': round(self.perclos.value, 4),
            'is_eye_closed': ear < self.ear_threshold,
            'is_yawning': mar > self.mar_threshold,
            'feature_vector': np.array([ear, mar, pitch, yaw, roll], dtype=np.float32),
        }

    def reset(self):
        self.perclos = PERCLOS(self.perclos.window.maxlen, self.ear_threshold)
        self._frame_count = 0


def calibrate_ear_threshold(model, eye_dataset_path, num_samples=500):
    """
    在眼部数据集上校准 EAR 阈值。
    返回最优阈值，使睁眼/闭眼分类准确率最高。
    """
    import os
    from pathlib import Path

    open_ears = []
    closed_ears = []

    open_dir = Path(eye_dataset_path) / 'open'
    closed_dir = Path(eye_dataset_path) / 'closed'

    for label, ear_list, img_dir in [
        ('open', open_ears, open_dir),
        ('closed', closed_ears, closed_dir)
    ]:
        if not img_dir.exists():
            continue
        images = list(img_dir.glob('*.jpg')) + list(img_dir.glob('*.png'))
        for img_path in images[:num_samples]:
            frame = cv2.imread(str(img_path))
            if frame is None:
                continue
            results = model(frame, verbose=False)[0]
            if results.keypoints is not None and len(results.keypoints.xy) > 0:
                kpts = results.keypoints.xy[0].cpu().numpy()
                if len(kpts) >= 5:
                    ear = eye_aspect_ratio(kpts[:5])
                    ear_list.append(ear)

    if not open_ears or not closed_ears:
        return 0.18  # 返回默认值

    # 网格搜索最优阈值
    best_thresh = 0.18
    best_acc = 0
    for thresh in np.arange(0.08, 0.35, 0.005):
        tp = sum(1 for e in closed_ears if e < thresh)
        tn = sum(1 for e in open_ears if e >= thresh)
        acc = (tp + tn) / (len(open_ears) + len(closed_ears))
        if acc > best_acc:
            best_acc = acc
            best_thresh = thresh

    return round(best_thresh, 3)
