"""
NTHU-DDD 司机疲劳检测 — YOLOv11n 微调训练脚本

用法（容器内）:
    python3 /workspace/tiring_detection/src/train_drowsy_detect.py

自定义参数:
    python3 /workspace/tiring_detection/src/train_drowsy_detect.py \
        --epochs 50 --batch 128 --imgsz 640

GPU 监控（另开终端）:
    watch -n 1 nvidia-smi
"""
import argparse
import sys
from pathlib import Path
from ultralytics import YOLO

# 固定路径
DATA_YAML = '/workspace/data/driver-yolo11/data.yaml'
PROJECT = '/workspace/tiring_detection/outputs'
NAME = 'drowsy_detect'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='yolo11n.pt')
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--batch', type=int, default=64)
    parser.add_argument('--workers', type=int, default=8)
    parser.add_argument('--lr0', type=float, default=0.002)
    parser.add_argument('--lrf', type=float, default=0.01)
    parser.add_argument('--freeze', type=int, default=0)
    parser.add_argument('--device', default='0')
    args = parser.parse_args()

    if not Path(DATA_YAML).exists():
        print(f'[ERROR] 数据集不存在: {DATA_YAML}')
        sys.exit(1)

    print(f'{"="*50}')
    print(f'  司机疲劳检测 — YOLOv11n 微调')
    print(f'{"="*50}')
    print(f'  数据集:    {DATA_YAML}')
    print(f'  模型:      {args.model}')
    print(f'  Epochs:    {args.epochs}')
    print(f'  分辨率:     {args.imgsz}')
    print(f'  Batch:     {args.batch}')
    print(f'  Workers:   {args.workers}')
    print(f'  学习率:     {args.lr0} → {args.lr0*args.lrf:.5f}')
    print(f'  冻结层:     {args.freeze}')
    print(f'  GPU:       {args.device}')
    print(f'  AMP:       True')
    print(f'{"="*50}\n')

    model = YOLO(args.model)

    results = model.train(
        data=DATA_YAML,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        workers=args.workers,
        lr0=args.lr0,
        lrf=args.lrf,
        freeze=args.freeze,
        amp=True,
        device=args.device,
        project=PROJECT,
        name=NAME,
        exist_ok=True,
        pretrained=True,
        verbose=True,
    )

    print(f'\n最佳模型: {results.save_dir}/weights/best.pt')
    print(f'最后模型: {results.save_dir}/weights/last.pt')

    # 验证
    print('\n--- 验证 ---')
    metrics = model.val(data=DATA_YAML, split='test')
    print(f'mAP@50:     {metrics.box.map50:.4f}')
    print(f'mAP@50-95:  {metrics.box.map:.4f}')
    print(f'P:          {metrics.box.mp:.4f}')
    print(f'R:          {metrics.box.mr:.4f}')


if __name__ == '__main__':
    main()
