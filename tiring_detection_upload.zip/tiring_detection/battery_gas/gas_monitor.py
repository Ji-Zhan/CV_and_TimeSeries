#!/usr/bin/env python3
"""电池气体异常监测 — CSV 回放 + LSTM-AE 推理服务（Jetson Orin Nano 容器内运行）

⚠️ 本服务不修改疲劳检测系统的任何文件/逻辑，仅新增 gas_state 文件 + /status HTTP 端点

用法（常驻服务）:
    python3 gas_monitor.py --watch-dir data/gas_uploads --speed 10
    python3 gas_monitor.py --csv data/time/32A.csv --speed 10

常驻模式下会一直运行；把 CSV 文件放进 --watch-dir 目录就会自动开始测试。
也可以从 Web Dashboard 上传 CSV 到 data/gas_uploads/ 触发测试。

输出:
    data/gas_state           ← JSON，蜂鸣器 + Dashboard 轮询
    data/gas_events_*.jsonl  ← 状态切换事件（本地备份）
    POST /api/gas/events     ← 上报后端（失败缓存）

模型加载:
    data/gas_model/best_model.pt   ← state_dict
    data/gas_model/norm_mean.npy   ← 缩放器均值 [H2, COD, ΔT]
    data/gas_model/norm_std.npy    ← 缩放器标准差
    data/gas_model/threshold.npy   ← 异常阈值（单值）

架构（与训练端一致）:
    BiLSTM(3,64,2,bidirectional) → Mean Pool(时间轴) → Linear(128→16)+Tanh
    → Linear(16→64) → Repeat×60 → LSTM(64,64,2) → Linear(64→3)
    Dropout=0.2 (eval 模式禁用)
"""
import argparse
import json
import os
import sys
import time
import threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

# ──────────────────────────── 常量 ────────────────────────────

FEATURE_NAMES = ["h2_ppm", "co_ppm", "delta_t"]   # 顺序 = 缩放器顺序
WINDOW = 60                                         # 滑窗长度（秒/行）
ANOMALY_CONSEC = 5                                  # 连续超阈值秒数 → ANOMALY
STATE_POLL_SEC = 0.05                               # 状态文件更新间隔

# 列名统一（与 train_lstm_ae.py 一致）
COLUMN_MAP = {
    "H2(PPM)": "h2_raw",
    "COD(PPM)": "co_raw",
    "cod(ppm)": "co_raw",          # 16A 小写
}

# ──────────────────────────── 模型定义（必须与训练端完全一致） ────────────────────────────


class BiLSTMAutoencoder(nn.Module):
    """BiLSTM Encoder → Mean Pool → Latent → LSTM Decoder（Dropout 0.2）"""

    def __init__(self, input_dim=3, hidden_dim=64, latent_dim=16, num_layers=2, dropout=0.2):
        super().__init__()
        self.encoder_lstm = nn.LSTM(
            input_dim, hidden_dim, num_layers,
            batch_first=True, bidirectional=True, dropout=dropout,
        )
        self.latent_fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, latent_dim),
            nn.Tanh(),
        )
        self.decoder_fc = nn.Linear(latent_dim, hidden_dim)
        self.decoder_lstm = nn.LSTM(
            hidden_dim, hidden_dim, num_layers,
            batch_first=True, dropout=dropout,
        )
        self.output_fc = nn.Linear(hidden_dim, input_dim)

    def forward(self, x):
        # Encoder
        enc_out, _ = self.encoder_lstm(x)            # (B, W, hidden*2)
        pooled = enc_out.mean(dim=1)                  # (B, hidden*2)
        z = self.latent_fc(pooled)                    # (B, latent)
        # Decoder
        dec_in = self.decoder_fc(z).unsqueeze(1).expand(-1, x.shape[1], -1)
        dec_out, _ = self.decoder_lstm(dec_in)        # (B, W, hidden)
        return self.output_fc(dec_out)                # (B, W, input_dim)


# ──────────────────────────── 数据加载（与训练端一致） ────────────────────────────


def load_csv_unified(path: str) -> tuple:
    """读取 CSV，统一列名，返回 (timestamps, h2, co, avg_temp) 四个 Series"""
    df = pd.read_csv(path, encoding="utf-8-sig")
    df.columns = [str(c).strip() for c in df.columns]

    h2_col = next((c for c in df.columns if "H2" in c.upper()), None)
    co_col = next((c for c in df.columns if c.upper().startswith("COD") or c == "cod(ppm)"), None)
    t_cols = [c for c in df.columns if "温度" in c]
    t_avg_col = next((c for c in t_cols if "平均" in c or "均值" in c), None)

    h2 = pd.to_numeric(df[h2_col], errors="coerce") if h2_col else pd.Series(dtype=float)
    co = pd.to_numeric(df[co_col], errors="coerce") if co_col else pd.Series(dtype=float)

    if t_avg_col:
        t_avg = pd.to_numeric(df[t_avg_col], errors="coerce")
    elif len(t_cols) >= 2:
        t_avg = (pd.to_numeric(df[t_cols[0]], errors="coerce") +
                 pd.to_numeric(df[t_cols[1]], errors="coerce")) / 2
    else:
        raise ValueError(f"{path}: 找不到温度列，现有列: {list(df.columns)}")

    h2 = h2.ffill().fillna(0)
    co = co.ffill().fillna(0)
    t_avg = t_avg.ffill().bfill().fillna(0)

    return h2.to_numpy(dtype=np.float32), co.to_numpy(dtype=np.float32), t_avg.to_numpy(dtype=np.float32)


# ──────────────────────────── 推理引擎 ────────────────────────────


class GasInferenceEngine:
    """加载模型 + 缩放器，提供逐行推理接口"""

    def __init__(self, model_dir: str, device: str = "cpu"):
        model_dir = Path(model_dir)
        # 阈值
        self.threshold = float(np.load(str(model_dir / "threshold.npy")))
        # 缩放器
        self.mean = np.load(str(model_dir / "norm_mean.npy")).astype(np.float32)   # (3,)
        self.std = np.load(str(model_dir / "norm_std.npy")).astype(np.float32)
        self.std = np.where(self.std < 1e-8, 1.0, self.std)
        # 模型
        self.model = BiLSTMAutoencoder(input_dim=3, hidden_dim=64, latent_dim=16, num_layers=2, dropout=0.2)
        sd = torch.load(str(model_dir / "best_model.pt"), map_location="cpu", weights_only=True)
        self.model.load_state_dict(sd)
        self.model.to(device).eval()
        self.device = device

    @torch.no_grad()
    def score(self, window_60x3: np.ndarray) -> float:
        """输入 (60, 3) 原始值 → 输出 anomaly score（归一化空间 MSE）"""
        x = (window_60x3 - self.mean) / self.std
        xb = torch.from_numpy(x).float().unsqueeze(0).to(self.device)   # (1, 60, 3)
        recon = self.model(xb)
        return float(((recon - xb) ** 2).mean().cpu().item())


# ──────────────────────────── HTTP 状态端点 ────────────────────────────


class StatusHandler(BaseHTTPRequestHandler):
    """GET /status → JSON (gas_state 文件内容)"""

    state_file: str = ""

    def log_message(self, format, *args):
        pass   # 静默

    def do_GET(self):
        if self.path == "/status":
            try:
                with open(self.state_file, "r") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(body.encode())
            except FileNotFoundError:
                self.send_response(503)
                self.end_headers()
                self.wfile.write(b'{"state":"STARTING"}')
        else:
            self.send_response(404)
            self.end_headers()


def _start_http(port: int, state_file: str):
    StatusHandler.state_file = state_file
    srv = ThreadingHTTPServer(("0.0.0.0", port), StatusHandler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


# ──────────────────────────── 原子写 ────────────────────────────


def atomic_write(path: str, text: str):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


# ──────────────────────────── 信号处理 ────────────────────────────

SHUTDOWN_STATE_FILE = None   # 由 main() 设置


def _write_finished(signum=None, frame=None):
    """被 SIGTERM/SIGINT 中断时写 FINISHED，防止 gas_state 卡在 ANOMALY"""
    if SHUTDOWN_STATE_FILE:
        atomic_write(SHUTDOWN_STATE_FILE, json.dumps({
            "state": "FINISHED",
            "anomaly_score": 0, "h2_ppm": 0, "co_ppm": 0, "delta_t": 0,
            "row": 0, "total_rows": 0, "csv_file": "",
        }, ensure_ascii=False))
        print("[SIG] FINISHED state written, exiting", flush=True)
    sys.exit(0)


# ──────────────────────────── 主循环 ────────────────────────────


def replay_csv(args, engine, state_file, events_dir, post_event, csv_path, speed):
    """回放一个 CSV 文件，并在结束后把状态写成 FINISHED。"""
    csv_path = Path(csv_path)
    csv_name = csv_path.name
    print(f"[JOB] start {csv_name}  speed={speed}x", flush=True)

    h2_arr, co_arr, t_arr = load_csv_unified(str(csv_path))
    total = len(h2_arr)
    # 温度增量 = 当前温度 - 该文件前 60 秒平均温度（与训练端一致）
    n_base = min(len(t_arr), WINDOW)
    temp_base = float(t_arr[:n_base].mean()) if n_base > 0 else 0.0
    delta_t = t_arr - temp_base
    print(f"[DATA] {total} rows  H2 range=[{h2_arr.min():.0f}, {h2_arr.max():.0f}]  "
          f"CO range=[{co_arr.min():.0f}, {co_arr.max():.0f}]  ΔT range=[{delta_t.min():.0f}, {delta_t.max():.0f}]", flush=True)

    state = "NORMAL"
    cons_count = 0
    events_log_path = os.path.join(events_dir, f"gas_events_{time.strftime('%Y%m%d')}.jsonl")

    for row in range(total):
        t0 = time.monotonic()

        # 需要满 60 行才开始推理
        if row < WINDOW - 1:
            score = 0.0
            is_anomaly = False
        else:
            start = row - WINDOW + 1
            window = np.column_stack([
                h2_arr[start:row + 1],
                co_arr[start:row + 1],
                delta_t[start:row + 1],
            ])  # (60, 3)
            score = engine.score(window)
            is_anomaly = score > engine.threshold

        # 连续 N 秒判定
        if is_anomaly:
            cons_count += 1
            new_state = "ANOMALY" if cons_count >= ANOMALY_CONSEC else state
        else:
            cons_count = 0
            new_state = "NORMAL"

        # 状态切换事件
        if new_state != state:
            state = new_state
            event = {
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.") + f"{int(time.time()*1000)%1000:03d}",
                "device_id": args.device_id,
                "state": state,
                "anomaly_score": round(score, 6),
                "h2_ppm": round(float(h2_arr[row]), 2),
                "co_ppm": round(float(co_arr[row]), 2),
                "delta_t": round(float(delta_t[row]), 2),
                "row": int(row),
                "total_rows": int(total),
                "csv_file": csv_name,
            }
            # 本地 JSONL
            with open(events_log_path, "a") as f:
                f.write(json.dumps(event, ensure_ascii=False) + "\n")
            # POST 到后端
            threading.Thread(target=post_event, args=(event,), daemon=True).start()
            print(f"[EVENT] {event['timestamp']}  {state}  score={score:.4f}", flush=True)

        # 写状态文件（高频，蜂鸣器/Dashboard 轮询）
        state_json = json.dumps({
            "state": state,
            "anomaly_score": round(score, 6),
            "h2_ppm": round(float(h2_arr[row]), 2),
            "co_ppm": round(float(co_arr[row]), 2),
            "delta_t": round(float(delta_t[row]), 2),
            "row": int(row),
            "total_rows": int(total),
            "csv_file": csv_name,
            "timestamp": time.time(),
        }, ensure_ascii=False)
        atomic_write(state_file, state_json)

        # 回放速度控制
        elapsed = time.monotonic() - t0
        sleep_for = max(0, 1.0 / speed - elapsed)
        time.sleep(sleep_for)

    # 回放结束
    state_json = json.dumps({
        "state": "FINISHED",
        "anomaly_score": 0, "h2_ppm": 0, "co_ppm": 0, "delta_t": 0,
        "row": total, "total_rows": total, "csv_file": csv_name,
    }, ensure_ascii=False)
    atomic_write(state_file, state_json)
    print(f"[DONE] {csv_name} replay finished  {total} rows", flush=True)


def write_waiting(state_file: str):
    atomic_write(state_file, json.dumps({
        "state": "WAITING",
        "anomaly_score": 0, "h2_ppm": 0, "co_ppm": 0, "delta_t": 0,
        "row": 0, "total_rows": 0, "csv_file": "",
        "message": "等待上传 CSV 测试文件",
        "timestamp": time.time(),
    }, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser(description="电池气体异常监测 — 常驻 CSV 回放 + LSTM-AE 推理服务")
    ap.add_argument("--csv", required=False, default=None,
                    help="可选的初始 CSV 文件路径（如 data/time/32A.csv）。不填则只监听上传目录。")
    ap.add_argument("--speed", type=float, default=10.0, help="回放倍速（默认 10）")
    ap.add_argument("--model-dir", default="data/gas_model", help="模型 + 缩放器目录")
    ap.add_argument("--state-file", default="data/gas_state", help="状态文件输出路径")
    ap.add_argument("--events-dir", default="data", help="事件 JSONL 输出目录")
    ap.add_argument("--watch-dir", default="data/gas_uploads", help="监听目录：放入 *.csv 自动开始测试")
    ap.add_argument("--port", type=int, default=8081, help="HTTP /status 端口")
    ap.add_argument("--api-url", default="http://fatigue-api:8000/api/gas/events", help="事件上报地址")
    ap.add_argument("--device", default="cpu", help="推理设备 (cpu/cuda)")
    ap.add_argument("--device-id", default="jetson-orin-001", help="设备标识")
    args = ap.parse_args()

    # 路径统一解析为绝对路径
    args.model_dir = str(Path(args.model_dir).resolve())
    state_file = str(Path(args.state_file).resolve())
    events_dir = str(Path(args.events_dir).resolve())
    os.makedirs(events_dir, exist_ok=True)

    watch_dir = None
    if args.watch_dir:
        watch_dir = Path(args.watch_dir).resolve()
        watch_dir.mkdir(parents=True, exist_ok=True)

    if args.csv:
        args.csv = str(Path(args.csv).resolve())
        print(f"[INIT] initial csv={Path(args.csv).name}  speed={args.speed}x  device={args.device}", flush=True)
    else:
        print(f"[INIT] daemon mode  speed={args.speed}x  device={args.device}", flush=True)

    # 信号处理: 被 kill 时写 FINISHED，防 gas_state 卡在 ANOMALY
    global SHUTDOWN_STATE_FILE
    SHUTDOWN_STATE_FILE = state_file
    import signal
    signal.signal(signal.SIGTERM, _write_finished)
    signal.signal(signal.SIGINT, _write_finished)

    # 加载
    engine = GasInferenceEngine(args.model_dir, args.device)
    print(f"[MODEL] threshold={engine.threshold:.4f}  mean={engine.mean.tolist()}  std={engine.std.tolist()}", flush=True)

    # HTTP
    srv = _start_http(args.port, state_file)
    print(f"[HTTP] 0.0.0.0:{args.port}/status", flush=True)

    # 事件缓存
    event_cache = []
    event_cache_path = os.path.join(events_dir, "gas_events_cache.json")

    def post_event(event: dict):
        """POST 到后端，失败则缓存"""
        nonlocal event_cache
        import urllib.request

        data = json.dumps(event).encode()
        try:
            req = urllib.request.Request(args.api_url, data=data,
                                         headers={"Content-Type": "application/json"}, method="POST")
            resp = urllib.request.urlopen(req, timeout=5)
            if resp.status == 201:
                return True
        except Exception:
            pass
        # 缓存（上限 1000）
        event_cache.append(event)
        if len(event_cache) > 1000:
            event_cache = event_cache[-500:]
        with open(event_cache_path, "w") as f:
            json.dump(event_cache, f, ensure_ascii=False)
        return False

    # 加载旧缓存
    if os.path.exists(event_cache_path):
        try:
            with open(event_cache_path) as f:
                event_cache = json.load(f)
        except Exception:
            pass

    # 如果传了 --csv，先跑一次（仍保持常驻，之后继续监听上传目录）
    if args.csv:
        replay_csv(args, engine, state_file, events_dir, post_event, Path(args.csv), args.speed)

    if watch_dir is None:
        # 兼容旧的一次性用法：跑完退出
        time.sleep(2)
        srv.shutdown()
        return

    # 常驻监听：把 CSV 放进 watch_dir 即自动开始测试
    print(f"[WATCH] watching {watch_dir} for *.csv ...", flush=True)
    write_waiting(state_file)
    while True:
        try:
            candidates = sorted(watch_dir.glob("*.csv"))
            if not candidates:
                write_waiting(state_file)
                time.sleep(1)
                continue

            for path in candidates:
                if path.name.startswith('.'):
                    continue
                try:
                    replay_csv(args, engine, state_file, events_dir, post_event, path, args.speed)
                    path.rename(path.with_suffix(path.suffix + '.done'))
                except Exception as e:
                    print(f"[ERROR] {path.name}: {e}", flush=True)
                    try:
                        path.rename(path.with_suffix(path.suffix + '.failed'))
                    except Exception:
                        pass
            time.sleep(1)
        except KeyboardInterrupt:
            break

    srv.shutdown()


if __name__ == "__main__":
    main()
