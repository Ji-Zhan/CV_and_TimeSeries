#!/usr/bin/env python3
"""电池气体异常监测 — BiLSTM-AE 训练脚本（当前 best_model.pt 的实际训练配方）

⚠️ 本脚本在 RTX 4070 Super 主机上运行（Jetson 不做训练）。
⚠️ 本脚本与 jetson 端 gas_monitor.py 中的 BiLSTMAutoencoder 结构完全一致。

训练配方（reference）:
    第1步 数据加载与特征选择
        5 个 CSV（16A~48A，每秒 1 行）→ 3 个特征:
          H2   = H2(PPM) 原值
          COD  = cod(ppm)/COD(PPM) 原值
          温度 = 平均温度 - 该文件前 60 秒平均温度（消除不同实验起始温度差异）
    第2步 正常窗口筛选
        滑窗 60 秒, 步长 15 秒
        正常条件:
          H2 max  <= 50 PPM
          COD max <= 50 PPM
          原始温度标准差 <= 3.0°C
    第3步 归一化 + 划分
        全部正常窗口做 z-score（均值/方差存 norm_mean.npy / norm_std.npy）
        80/20 随机训练/验证划分
        WeightedRandomSampler: 每个实验权重 = 1/该实验窗口数
    第4步 模型与训练
        输入 [batch, 60, 3]
        Encoder: 2层 BiLSTM(64) → 时间平均 → FC(128→16)+Tanh
        Decoder: FC(16→64) → 复制60次 → 2层 LSTM(64) → FC(64→3)
        Loss = MSE(重构, 原始)
        Adam lr=1e-3, 200 epochs, early stopping patience=30
    第5步 异常判定
        训练集重构误差 → Q1/Q3/IQR → threshold = Q3 + 3*IQR
        推理时逐秒滑窗, 窗口 MSE > threshold → 异常分
          → EMA 平滑 → 连续 5 秒超阈值 → 判定热失控前兆

输出:
    best_model.pt / norm_mean.npy / norm_std.npy / threshold.npy
    model_config.json / training_report.json

用法:
    python train_lstm_ae.py --data-dir time --output-dir gas_model \
        --window 60 --stride 15 --epochs 200 --lr 1e-3
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

# ──────────────────────────── 常量 ────────────────────────────

WINDOW_DEFAULT = 60
STRIDE_DEFAULT = 15
FEATURE_NAMES = ["h2_ppm", "co_ppm", "temp_delta"]   # 顺序与 gas_monitor.py 保持一致

# 正常窗口筛选阈值（reference 第2步）
H2_MAX_NORMAL = 50.0
CO_MAX_NORMAL = 50.0
TEMP_STD_NORMAL = 3.0

FILES = ["16A.csv", "24A.csv", "32A.csv", "40A.csv", "48A.csv"]


def reconfigure_stdout():
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def load_csv_3feat(path: Path) -> tuple:
    """读取单个 CSV，返回 (h2, co, temp_delta, temp_raw)。

    - h2:        H2(PPM) 原值
    - co:        cod(ppm) / COD(PPM) 原值
    - temp_delta: 平均温度 - 该文件前 60 秒平均温度
    - temp_raw:  平均温度原值（用于正常窗口筛选）
    """
    df = pd.read_csv(path, encoding="utf-8-sig")
    df.columns = [str(c).strip() for c in df.columns]

    h2_col = next((c for c in df.columns if "H2" in c.upper()), None)
    co_col = next((c for c in df.columns if c.upper().startswith("COD") or c == "cod(ppm)"), None)
    temp_col = next((c for c in df.columns if c in ("平均温度", "温度平均值")), None)
    if temp_col is None:
        temp_col = next((c for c in df.columns if "平均" in c or "均值" in c), None)

    if h2_col is None:
        raise ValueError(f"{path.name}: 找不到 H2 列，实际列: {list(df.columns)}")
    if co_col is None:
        raise ValueError(f"{path.name}: 找不到 COD 列，实际列: {list(df.columns)}")
    if temp_col is None:
        raise ValueError(f"{path.name}: 找不到平均温度列，实际列: {list(df.columns)}")

    h2 = pd.to_numeric(df[h2_col], errors="coerce").to_numpy(np.float32)
    co = pd.to_numeric(df[co_col], errors="coerce").to_numpy(np.float32)
    temp_raw = pd.to_numeric(df[temp_col], errors="coerce").to_numpy(np.float32)

    # 少量 NaN 前向填充，仍有 NaN 的尾部填 0（与推理端一致）
    h2 = np.nan_to_num(pd.Series(h2).ffill().bfill().fillna(0).to_numpy(np.float32), nan=0.0)
    co = np.nan_to_num(pd.Series(co).ffill().bfill().fillna(0).to_numpy(np.float32), nan=0.0)
    temp_raw = np.nan_to_num(pd.Series(temp_raw).ffill().bfill().fillna(0).to_numpy(np.float32), nan=0.0)

    # 温度增量：减去该文件前 60 秒均值（与 gas_monitor.py 推理端保持一致）
    n_base = min(len(temp_raw), WINDOW_DEFAULT)
    temp_base = float(temp_raw[:n_base].mean()) if n_base > 0 else 0.0
    temp_delta = temp_raw - temp_base

    return h2, co, temp_delta, temp_raw


def build_normal_windows(data_dir: Path, files, window: int, stride: int):
    """滑窗切分 + 正常窗口筛选。

    Returns:
        X:        (N, window, 3) float32
        file_ids: (N,) 每个窗口来自哪个文件（用于 WeightedRandomSampler）
    """
    all_windows = []
    all_file_ids = []
    for file_idx, name in enumerate(files):
        path = data_dir / name
        if not path.exists():
            print(f"[WARN] 跳过不存在的文件: {path}", flush=True)
            continue
        h2, co, temp_delta, temp_raw = load_csv_3feat(path)
        n = len(h2)
        if n < window:
            print(f"[WARN] {name}: 长度 {n} < window {window}，跳过", flush=True)
            continue

        count = 0
        total_windows = (n - window) // stride + 1
        for start in range(0, n - window + 1, stride):
            end = start + window
            h2_w = h2[start:end]
            co_w = co[start:end]
            temp_raw_w = temp_raw[start:end]
            temp_delta_w = temp_delta[start:end]

            # 正常窗口条件
            if (h2_w.max() <= H2_MAX_NORMAL and
                    co_w.max() <= CO_MAX_NORMAL and
                    float(temp_raw_w.std(ddof=0)) <= TEMP_STD_NORMAL):
                all_windows.append(np.stack([h2_w, co_w, temp_delta_w], axis=1))
                all_file_ids.append(file_idx)
                count += 1

        print(f"[DATA] {name}: {count}/{total_windows} 个正常窗口", flush=True)

    if not all_windows:
        raise ValueError("没有筛选到任何正常窗口，请检查数据文件或阈值")

    X = np.stack(all_windows).astype(np.float32)
    file_ids = np.asarray(all_file_ids, dtype=np.int64)
    return X, file_ids


def make_model(input_dim=3, hidden_dim=64, latent_dim=16, num_layers=2, dropout=0.2):
    """与 gas_monitor.py 中 BiLSTMAutoencoder 完全一致。改这里必须同步改推理端。"""
    return BiLSTMAutoencoder(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        latent_dim=latent_dim,
        num_layers=num_layers,
        dropout=dropout,
    )


class BiLSTMAutoencoder(nn.Module):
    """BiLSTM Encoder → Mean Pool → Latent → LSTM Decoder（dropout=0.2）"""

    def __init__(self, input_dim=3, hidden_dim=64, latent_dim=16, num_layers=2, dropout=0.2):
        super().__init__()
        self.encoder_lstm = nn.LSTM(
            input_dim, hidden_dim, num_layers,
            batch_first=True, bidirectional=True, dropout=dropout,
        )
        self.latent_fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, latent_dim),
            nn.Tanh(),
        )
        self.decoder_fc = nn.Linear(latent_dim, hidden_dim)
        self.decoder_lstm = nn.LSTM(
            hidden_dim, hidden_dim, num_layers,
            batch_first=True, dropout=dropout,
        )
        self.output_fc = nn.Linear(hidden_dim, input_dim)

    def forward(self, x):
        enc_out, _ = self.encoder_lstm(x)
        pooled = enc_out.mean(dim=1)
        z = self.latent_fc(pooled)
        dec_in = self.decoder_fc(z).unsqueeze(1).expand(-1, x.shape[1], -1)
        dec_out, _ = self.decoder_lstm(dec_in)
        return self.output_fc(dec_out)


@torch.no_grad()
def score_windows(model, X_norm, device, batch_size=256):
    """逐窗口重建误差（归一化空间 MSE）"""
    model.eval()
    scores = []
    for i in range(0, len(X_norm), batch_size):
        xb = torch.from_numpy(X_norm[i:i + batch_size]).float().to(device)
        recon = model(xb)
        mse = ((recon - xb) ** 2).mean(dim=(1, 2))
        scores.extend(mse.cpu().tolist())
    return np.asarray(scores, dtype=np.float64)


def train_model(model, X_train_norm, X_val_norm, train_weights, args, device):
    """训练 BiLSTM-AE，返回最佳模型和训练历史。"""
    crit = nn.MSELoss()
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)

    dataset = TensorDataset(torch.from_numpy(X_train_norm).float())
    sampler = WeightedRandomSampler(
        weights=train_weights,
        num_samples=len(train_weights),
        replacement=True,
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, sampler=sampler)

    best_val = float("inf")
    best_state = None
    patience = 0
    history = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        total_samples = 0
        for (xb,) in loader:
            xb = xb.to(device)
            loss = crit(model(xb), xb)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total_loss += loss.item() * xb.shape[0]
            total_samples += xb.shape[0]
        train_loss = total_loss / max(total_samples, 1)

        val_scores = score_windows(model, X_val_norm, device)
        val_loss = float(val_scores.mean())

        history.append({"epoch": epoch, "train_loss": round(train_loss, 6), "val_loss": round(val_loss, 6)})
        if epoch == 1 or epoch % 25 == 0 or epoch == args.epochs:
            print(f"  epoch {epoch:>3}/{args.epochs}  train_loss={train_loss:.6f}  val_loss={val_loss:.6f}  patience={patience}/{args.patience}", flush=True)

        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= args.patience:
                print(f"  early stop @ epoch {epoch}  best val_loss={best_val:.6f}", flush=True)
                break

    if best_state is None:
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    return model, history, best_val


def main():
    reconfigure_stdout()

    ap = argparse.ArgumentParser(description="电池气体异常监测 — BiLSTM-AE 训练（当前 best_model.pt 配方）")
    ap.add_argument("--data-dir", required=True, help="time/*.csv 所在目录")
    ap.add_argument("--output-dir", required=True, help="输出目录（自动创建）")
    ap.add_argument("--window", type=int, default=WINDOW_DEFAULT)
    ap.add_argument("--stride", type=int, default=STRIDE_DEFAULT)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--patience", type=int, default=30)
    ap.add_argument("--hidden-dim", type=int, default=64)
    ap.add_argument("--latent-dim", type=int, default=16)
    ap.add_argument("--num-layers", type=int, default=2)
    ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val-split", type=float, default=0.2)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    out_dir = Path(args.output_dir)
    if not data_dir.is_dir():
        sys.exit(f"[ERR] --data-dir 不存在: {data_dir}")

    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if device.startswith("cuda"):
        torch.cuda.manual_seed_all(args.seed)
    print(f"[ENV] device={device}  torch={torch.__version__}  seed={args.seed}", flush=True)

    # 1. 正常窗口筛选
    print(f"[STEP 1] 数据加载 + 正常窗口筛选 (H2<={H2_MAX_NORMAL}, COD<={CO_MAX_NORMAL}, temp_std<={TEMP_STD_NORMAL})", flush=True)
    X, file_ids = build_normal_windows(data_dir, FILES, args.window, args.stride)
    print(f"[DATA] 正常窗口总数: {len(X)}  shape={X.shape}", flush=True)

    # 2. 归一化：全部正常窗口 flatten 后求 mean/std
    flat = X.reshape(-1, X.shape[2])
    mean = flat.mean(axis=0).astype(np.float32)
    std = flat.std(axis=0).astype(np.float32)
    std = np.where(std < 1e-8, 1.0, std)
    X_norm = ((X - mean) / std).astype(np.float32)
    print(f"[STEP 2] z-score  mean={np.round(mean, 6).tolist()}  std={np.round(std, 6).tolist()}", flush=True)

    # 3. 80/20 随机划分
    rng = np.random.RandomState(args.seed)
    n = len(X_norm)
    idx = rng.permutation(n)
    n_val = max(1, int(n * args.val_split))
    val_idx = idx[:n_val]
    train_idx = idx[n_val:]
    X_train = X_norm[train_idx]
    X_val = X_norm[val_idx]
    print(f"[STEP 3] train={len(X_train)}  val={len(X_val)}", flush=True)

    # WeightedRandomSampler：每个实验权重 = 1/该实验窗口数
    train_files = file_ids[train_idx]
    unique, counts = np.unique(train_files, return_counts=True)
    file_weight = {}
    for u, c in zip(unique, counts):
        file_weight[u] = 1.0 / float(c)
    train_weights = np.asarray([file_weight[f] for f in train_files], dtype=np.float64)
    train_weights = train_weights / train_weights.sum()
    for u in unique:
        name = FILES[u] if u < len(FILES) else str(u)
        print(f"    {name}: {dict(zip(unique, counts))[u]} 窗口, weight={file_weight[u]:.5f}", flush=True)

    # 4. 模型
    model = make_model(
        input_dim=X.shape[2],
        hidden_dim=args.hidden_dim,
        latent_dim=args.latent_dim,
        num_layers=args.num_layers,
        dropout=args.dropout,
    ).to(device)
    print(f"[STEP 4] BiLSTM-AE  input_dim={X.shape[2]} hidden={args.hidden_dim} latent={args.latent_dim} "
          f"layers={args.num_layers} dropout={args.dropout}", flush=True)
    print(f"[TRAIN] epochs={args.epochs}  lr={args.lr}  batch={args.batch_size}  patience={args.patience}", flush=True)

    model, history, best_val = train_model(model, X_train, X_val, train_weights, args, device)

    # 5. 阈值：训练集重构误差的 Q3 + 3*IQR
    train_scores = score_windows(model, X_train, device)
    q1, q3 = np.percentile(train_scores, [25, 75])
    iqr = q3 - q1
    threshold = float(q3 + 3.0 * iqr)
    print(f"[STEP 5] train score  q1={q1:.6f} q3={q3:.6f} iqr={iqr:.6f}  threshold={threshold:.6f}", flush=True)

    # 6. 保存
    out_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), out_dir / "best_model.pt")
    np.save(out_dir / "norm_mean.npy", mean)
    np.save(out_dir / "norm_std.npy", std)
    np.save(out_dir / "threshold.npy", np.asarray(threshold, dtype=np.float64))
    config = {
        "model": "BiLSTMAutoencoder",
        "input_dim": int(X.shape[2]),
        "hidden_dim": args.hidden_dim,
        "latent_dim": args.latent_dim,
        "num_layers": args.num_layers,
        "dropout": args.dropout,
        "window": args.window,
        "feature_names": FEATURE_NAMES,
    }
    (out_dir / "model_config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    report = {
        "config": config,
        "files": FILES,
        "normal_window_thresholds": {
            "h2_max": H2_MAX_NORMAL,
            "co_max": CO_MAX_NORMAL,
            "temp_std": TEMP_STD_NORMAL,
        },
        "n_normal_windows": n,
        "n_train_windows": len(train_idx),
        "n_val_windows": len(val_idx),
        "scaler_mean": mean.tolist(),
        "scaler_std": std.tolist(),
        "best_val_loss": round(best_val, 6),
        "threshold": threshold,
        "threshold_method": "Q3 + 3*IQR",
        "q1": q1,
        "q3": q3,
        "iqr": iqr,
        "history": history,
    }
    (out_dir / "training_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[SAVE] {out_dir}: best_model.pt / norm_mean.npy / norm_std.npy / threshold.npy / model_config.json / training_report.json", flush=True)


if __name__ == "__main__":
    main()
