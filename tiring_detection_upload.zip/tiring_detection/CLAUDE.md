# 司机疲劳检测 (Driver Fatigue Detection)

## 项目概览

基于 YOLOv11n-pose + 几何特征的实时司机疲劳检测系统，部署目标为 NVIDIA Jetson Orin Nano Super (8GB)。

## 架构

```
摄像头 → YOLOv11n-pose (人脸+5关键点)
       → 瞳孔检测 (眼部ROI → 深色圆形搜索 → 睁/闭眼)
       → 嘴部纵横比 MAR (打哈欠)
       → 头部姿态 Pitch 偏离基线 (点头)
       → 任一信号持续0.5秒 → DROWSY告警
```

## 关键设计决策

- **不做微调**: YOLOv11n-pose 预训练模型直接用，检测人脸 5 点关键点（双眼、鼻尖、双嘴角）
- **瞳孔检测法**: 在眼部 ROI 中找深色圆形轮廓，找不到=闭眼。比暗像素法/梯度方差法更通用，不依赖光线和肤色
- **Pitch 基线冻结**: 前 2 秒建立基线后永不再更新，防止疲劳姿态被 EMA 学成"正常"
- **0.5 秒确认**: 疲劳信号持续 0.5 秒才告警，兼顾灵敏度和抗误报

## 文件结构

```
/home/nnnneeeeoooo/tiring_detection/
├── src/
│   ├── test_drowsy_hybrid.py   ← 主推理脚本 (使用这个)
│   ├── train_drowsy_detect.py  ← YOLO detection 微调 (废弃, 泛化差)
│   ├── train_yolo_pose.py      ← YOLO pose 微调 (未使用)
│   ├── test_drowsy.py          ← detection 模型推理 (废弃)
│   ├── feature_extraction.py   ← 特征提取库 (EAR/MAR/HeadPose)
│   ├── preprocess_300w.py      ← 68→5点转换
│   ├── extract_dataset_features.py
│   ├── train_fatigue_classifier.py
│   ├── export_classifier_onnx.py
│   ├── export_yolo_onnx.py
│   └── demo_fatigue.py
├── jetson_deploy/
│   ├── trt_inference.py
│   ├── fatigue_detector.py
│   └── convert_models.sh
├── configs/
├── data/                       ← 数据集 + 测试视频 + 日志 + 输出视频
│   ├── raw_videos/             ← 测试视频
│   ├── output_video/           ← 标注后的输出视频
│   ├── log/                    ← 运行日志
│   └── datasets/               ← 训练数据集
├── outputs/                    ← 训练产出
└── notebooks/                  ← Jupyter notebooks
```

## 运行方式

```bash
# 容器已运行: ultralytics-yolo11 (端口 8890 Jupyter, 8890→8888)
# GPU: RTX 4070 SUPER, 共享内存: 4GB

# 推理
docker exec -it ultralytics-yolo11 python3 /workspace/tiring_detection/src/test_drowsy_hybrid.py \
  --source /workspace/data/raw_videos/test-video6.mp4

# 进容器
docker exec -it ultralytics-yolo11 bash

# Jupyter
http://localhost:8890 (无token)
```

## 可调参数 (test_drowsy_hybrid.py 顶部)

| 参数 | 默认 | 含义 |
|---|---|---|
| EYE_CLOSE_RATIO | 0.35 | 瞳孔圆形度阈值 |
| MAR_THRESHOLD | 0.55 | 哈欠阈值 |
| HEAD_NOD_DEVIATION | 15 | Pitch偏离基线>此值=点头 |
| ALARM_DELAY_SEC | 0.5 | 疲劳信号持续多久告警 |

## 训练数据集

- NTHU-DDD (Roboflow YOLO格式): `/workspace/data/driver-yolo11/`
- NTHU-DDD (COCO格式): `/workspace/data/driver-coco/`

## 已知问题 & 注意事项

1. Docker 共享内存必须 >= 2GB, 否则 GPU 利用率 2%
2. WSL2 无摄像头, 用视频文件测试
3. detection 微调模型泛化差 (学的是特定人的疲劳脸), pose+几何特征方案泛化好
4. solvePnP 用 SOLVEPNP_EPNP (5点), 不能用 SOLVEPNP_ITERATIVE (需要≥6点)
