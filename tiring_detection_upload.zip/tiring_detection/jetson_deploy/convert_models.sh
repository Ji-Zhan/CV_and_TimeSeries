#!/bin/bash
# Jetson Orin Nano — ONNX → TensorRT Engine 转换脚本
#
# 用法 (在 Jetson 上执行):
#   bash convert_models.sh
#
# 前提:
#   1. 将训练好的 .onnx 文件从开发机复制到 Jetson 的 outputs/onnx/ 目录
#   2. JetPack 已安装 (自带 TensorRT + trtexec)
#
# TensorRT 版本对应 JetPack:
#   JetPack 6.x → TensorRT 10.x
#   JetPack 5.x → TensorRT 8.x

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
ONNX_DIR="$PROJECT_DIR/outputs/onnx"
ENGINE_DIR="$PROJECT_DIR/outputs/engines"

mkdir -p "$ENGINE_DIR"

echo "=========================================="
echo "  ONNX → TensorRT Engine 转换"
echo "  Jetson Orin Nano Super (8GB)"
echo "=========================================="
echo ""

# 检查 trtexec 是否可用
if ! command -v trtexec &>/dev/null; then
    echo "[ERROR] trtexec 未找到。请确认 JetPack 已正确安装。"
    echo "尝试: /usr/src/tensorrt/bin/trtexec"
    exit 1
fi

# ==========================================
# 1. YOLOv11n-pose Face Detector
# ==========================================
YOLO_ONNX="$ONNX_DIR/yolo11n_face_pose.onnx"
YOLO_ENGINE="$ENGINE_DIR/yolo_face_fp16.engine"

if [ -f "$YOLO_ONNX" ]; then
    echo "--- YOLOv11n-pose → TensorRT (FP16) ---"
    trtexec \
        --onnx="$YOLO_ONNX" \
        --saveEngine="$YOLO_ENGINE" \
        --fp16 \
        --minShapes=images:1x3x320x320 \
        --optShapes=images:1x3x320x320 \
        --maxShapes=images:1x3x320x320 \
        --memPoolSize=workspace:2000 \
        --verbose 2>&1 | tail -20

    if [ -f "$YOLO_ENGINE" ]; then
        echo "  ✓ YOLO Engine: $YOLO_ENGINE"

        # 快速性能测试
        echo "  性能测试 (1000 iterations)..."
        trtexec --loadEngine="$YOLO_ENGINE" --iterations=1000 2>&1 | grep "mean"
    else
        echo "  ✗ YOLO Engine 构建失败"
    fi
else
    echo "[SKIP] YOLO ONNX 未找到: $YOLO_ONNX"
    echo "  请先从开发机导出: yolo export model=best.pt format=onnx imgsz=320"
fi

echo ""

# ==========================================
# 2. MLP Fatigue Classifier
# ==========================================
MLP_ONNX="$ONNX_DIR/fatigue_mlp.onnx"
MLP_ENGINE="$ENGINE_DIR/fatigue_mlp.engine"

if [ -f "$MLP_ONNX" ]; then
    echo "--- MLP 分类器 → TensorRT ---"

    # 对于极小模型，有时纯 NumPy 比 TensorRT 更快（kernel launch overhead）
    # 这里提供两个选项
    trtexec \
        --onnx="$MLP_ONNX" \
        --saveEngine="$MLP_ENGINE" \
        --fp16 \
        --minShapes=features:1x5 \
        --optShapes=features:1x5 \
        --maxShapes=features:1x5 \
        --memPoolSize=workspace:100 \
        --verbose 2>&1 | tail -10

    if [ -f "$MLP_ENGINE" ]; then
        echo "  ✓ MLP Engine: $MLP_ENGINE"
        trtexec --loadEngine="$MLP_ENGINE" --iterations=10000 2>&1 | grep "mean"
    fi
else
    echo "[SKIP] MLP ONNX 未找到: $MLP_ONNX"
    echo "  注意: MLP 可以用 .npz (NumPy) 方案，比 TensorRT 更适合极轻量模型"
fi

echo ""
echo "=========================================="
echo "  转换完成"
echo "=========================================="
ls -lh "$ENGINE_DIR" 2>/dev/null || echo "  (无 Engine 文件)"

echo ""
echo "下一步:"
echo "  python jetson_deploy/fatigue_detector.py \\"
echo "    --yolo_engine $YOLO_ENGINE \\"
echo "    --mlp_model outputs/onnx/fatigue_mlp.npz \\"
echo "    --camera 0"
