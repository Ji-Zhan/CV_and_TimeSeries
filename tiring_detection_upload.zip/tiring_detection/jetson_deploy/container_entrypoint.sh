#!/bin/bash
# 安装依赖 (已安装则秒过)
pip install opencv-python jupyterlab -q 2>/dev/null

# 启动 Jupyter Lab
exec jupyter lab --ip=0.0.0.0 --port=8888 --no-browser --allow-root \
  --NotebookApp.token='' --notebook-dir=/workspace
