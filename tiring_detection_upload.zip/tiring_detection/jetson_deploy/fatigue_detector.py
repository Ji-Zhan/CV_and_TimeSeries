"""
Jetson Orin Nano 端 — 司机疲劳检测器

完整 Pipeline:
    Camera → YOLOv11n-pose (TensorRT) → 关键点
         → EAR/MAR/HeadPose (CPU)
         → MLP Fatigue Classifier (NumPy/TensorRT)
         → Temporal Smoothing → 告警输出

用法:
    python fatigue_detector.py \
        --yolo_engine outputs/engines/yolo_face_fp16.engine \
        --mlp_model outputs/onnx/fatigue_mlp.npz \
        --camera 0
"""
import argparse
import time
from pathlib import Path
from collections import deque
import numpy as np

# 特征提取模块 (无外部依赖)
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from feature_extraction import (
    FatigueFeatureExtractor, eye_aspect_ratio,
    mouth_aspect_ratio, compute_head_pose
)

# Jetson 推理后端
from trt_inference import TRTEngine, MlpNumpyInference, HAS_TRT


class DriverFatigueDetector:
    """
    驾驶员疲劳检测器

    在 Jetson Orin Nano 上的基准性能 (预期):
      YOLO TensorRT FP16: ~3-5ms
      特征提取 (CPU):     <1ms
      MLP NumPy 推理:     <0.1ms
      时序平滑:            <0.1ms
      ──────────────────────────
      总计 per frame:     ~5-7ms → >140 FPS

    留出大量余量给其他任务 (车道检测, CAN 通信等)
    """

    def __init__(self, yolo_engine_path, mlp_model_path,
                 perclos_window=90, ear_threshold=0.18,
                 mar_threshold=0.55, temporal_window=30):
        """
        Args:
            yolo_engine_path: TensorRT engine 路径 (YOLO)
            mlp_model_path: MLP 模型路径 (.npz 或 .onnx)
            perclos_window: PERCLOS 滑动窗口 (帧, 90帧@30fps=3秒)
            ear_threshold: EAR 闭眼阈值
            mar_threshold: MAR 哈欠阈值
            temporal_window: 疲劳状态平滑窗口 (帧)
        """
        # 加载 YOLO TensorRT Engine
        self.yolo = TRTEngine(yolo_engine_path)
        print(f"YOLO Engine 已加载: {yolo_engine_path}")

        # 加载 MLP
        mlp_path = Path(mlp_model_path)
        if mlp_path.suffix == '.npz':
            self.mlp = MlpNumpyInference(mlp_model_path)
        else:
            from trt_inference import OnnxInference
            self.mlp = OnnxInference(mlp_model_path)
        print(f"MLP 已加载: {mlp_model_path}")

        # 特征提取器
        self.extractor = FatigueFeatureExtractor(
            perclos_window=perclos_window,
            ear_threshold=ear_threshold,
            mar_threshold=mar_threshold,
        )

        # 状态管理
        self.temporal_window = temporal_window
        self.state_history = deque(maxlen=temporal_window)
        self.alert_history = deque(maxlen=perclos_window)
        self.current_state = 0  # Alert
        self.fps = 0
        self._frame_times = deque(maxlen=30)

        self.LABELS = ['Alert', 'Drowsy', 'Sleeping']
        self.ALERT_LEVELS = {
            0: {'color': (0, 255, 0), 'text': 'AWAKE', 'alarm': False},
            1: {'color': (0, 255, 255), 'text': 'DROWSY', 'alarm': True},
            2: {'color': (0, 0, 255), 'text': 'SLEEPING!', 'alarm': True},
        }

    def _yolo_preprocess(self, frame):
        """YOLO 预处理: resize + normalize"""
        # YOLOv11 输入: [1, 3, 320, 320], BGR (0-255) → RGB → /255
        import cv2
        img = cv2.resize(frame, (320, 320))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img.astype(np.float32) / 255.0
        img = img.transpose(2, 0, 1)  # HWC → CHW
        return np.expand_dims(img, axis=0)

    def process_frame(self, frame):
        """
        处理单帧

        Args:
            frame: BGR 图像 (H, W, 3)

        Returns:
            dict: {
                'state': int (0-2),
                'state_label': str,
                'confidence': float,
                'features': dict,
                'alarm': bool,
                'fps': float,
            }
        """
        t_start = time.perf_counter()

        # Step 1: YOLO 推理
        input_data = self._yolo_preprocess(frame)

        # 获取 YOLO 输出 — TensorRT engine 的输出名称取决于导出方式
        # ultralytics 导出的 ONNX 通常输出 'output0' (shape: [1, 56, 6300])
        yolo_output = self.yolo.infer({'images': input_data})
        output = yolo_output['output0']

        # 后处理 — 解析 YOLO 输出, 提取关键点
        bboxes, keypoints, scores = self._yolo_postprocess(output[0], frame.shape)

        if len(keypoints) == 0 or scores[0] < 0.5:
            # 未检测到人脸（置信度太低）
            self._frame_times.append(time.perf_counter() - t_start)
            return {
                'state': self.current_state,
                'state_label': f'{self.LABELS[self.current_state]} (no face)',
                'confidence': 0.0,
                'features': None,
                'alarm': False,
                'fps': self.fps,
            }

        # Step 2: 特征提取
        kpts = keypoints[0]  # 取置信度最高的人脸
        feat = self.extractor.extract(kpts)

        # Step 3: MLP 分类
        fv = feat['feature_vector']  # [ear, mar, pitch, yaw, roll]

        if hasattr(self.mlp, 'predict_proba'):
            proba = self.mlp.predict_proba(fv)
            state = int(np.argmax(proba))
            confidence = float(proba[state])
        else:
            state = self.mlp.predict(fv)
            confidence = 1.0

        # Step 4: 时序平滑
        self.state_history.append(state)
        if len(self.state_history) >= 10:
            # 10 帧多数投票
            from collections import Counter
            recent = list(self.state_history)[-10:]
            state = Counter(recent).most_common(1)[0][0]

        self.current_state = state

        # FPS 计算
        elapsed = time.perf_counter() - t_start
        self._frame_times.append(elapsed)
        self.fps = len(self._frame_times) / sum(self._frame_times) if sum(self._frame_times) > 0 else 0

        return {
            'state': state,
            'state_label': self.LABELS[state],
            'confidence': round(confidence, 4),
            'features': feat,
            'alarm': self.ALERT_LEVELS[state]['alarm'],
            'fps': round(self.fps, 1),
        }

    def _yolo_postprocess(self, output, frame_shape):
        """
        YOLO 输出后处理:
            output: (56, 6300) → ultralytics 导出格式
            frame_shape: (H, W, C) 原始帧尺寸

        Returns:
            bboxes: list of (x1, y1, x2, y2) in original coords
            keypoints: list of (5, 2) arrays in original coords
            scores: list of float
        """
        # Ultralytics YOLOv11 pose 导出 ONNX 输出格式:
        # output[0]: (1, 56, 8400) for imgsz=320
        #   56 = 4 (bbox) + 1 (conf) + 1 (class) + 5*3*2 (keypoints*xy+visibility)
        # 实际上 YOLOv11 transposed output:
        #   (8400, 56) at imgsz=320: 56 = 4+1+n_classes+5*3
        #   For 1 class + 5 kpts: 4+1+1+15 = 21? No...
        #   Actually: 4 (bbox) + 1 (obj conf) + nc (class scores) + nkpt*3
        #   = 4 + 1 + 1 + 5*3 = 4+1+1+15 = 21

        # 实际处理需要根据 ultralytics 版本调整。此处使用 ultralytics 自身做后处理。

        # 简化的后处理: 直接在 frame 上跑 ultralytics YOLO 做后处理
        # (在真实部署中，TensorRT engine 的 pre/post 都需要手写)
        bboxes = []
        keypoints = []
        scores = []

        # TODO: 实现完整的 YOLO TensorRT 后处理
        # 目前先返回空, 实际使用时需要对接 ultralytics 的 NMS 或手写

        return bboxes, keypoints, scores

    def reset(self):
        """重置状态（摄像头重连时调用）"""
        self.extractor.reset()
        self.state_history.clear()
        self.alert_history.clear()
        self.current_state = 0
        self._frame_times.clear()


class UltrlyticsYoloWrapper:
    """
    开发阶段的 YOLO 封装 — 使用 ultralytics Python API
    部署时替换为 TRTEngine
    """
    def __init__(self, model_path):
        from ultralytics import YOLO
        self.model = YOLO(model_path)

    def __call__(self, frame):
        results = self.model(frame, verbose=False)[0]
        if results.keypoints is None or len(results.keypoints.xy) == 0:
            return [], [], []

        bboxes = results.boxes.xyxy.cpu().numpy() if results.boxes is not None else []
        keypoints = results.keypoints.xy.cpu().numpy()
        scores = results.boxes.conf.cpu().numpy() if results.boxes is not None else [1.0]

        return bboxes, keypoints, scores


def run_demo(args):
    """端到端演示"""
    import cv2

    # 选择 YOLO 后端
    if args.yolo_model:
        yolo = UltrlyticsYoloWrapper(args.yolo_model)
        print(f"使用 ultralytics YOLO: {args.yolo_model}")
    else:
        yolo = TRTEngine(args.yolo_engine)
        print(f"使用 TensorRT Engine: {args.yolo_engine}")

    # 加载 MLP
    mlp = MlpNumpyInference(args.mlp_model)

    extractor = FatigueFeatureExtractor(
        perclos_window=args.perclos_window,
        ear_threshold=args.ear_threshold,
    )

    # 打开摄像头或视频文件
    if args.source.isdigit():
        cap = cv2.VideoCapture(int(args.source))
    else:
        cap = cv2.VideoCapture(args.source)

    if not cap.isOpened():
        print(f"[ERROR] 无法打开: {args.source}")
        return

    state_history = deque(maxlen=args.temporal_window)
    frame_times = deque(maxlen=30)
    current_state = 0
    LABELS = ['Alert', 'Drowsy', 'Sleeping']

    print("\n运行中... (按 'q' 退出)")
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        t0 = time.perf_counter()

        # YOLO 检测
        bboxes, kpts_list, scores = yolo(frame)

        if len(kpts_list) > 0 and scores[0] > 0.5:
            # 取最好的检测
            best_idx = int(np.argmax(scores))
            kpts = kpts_list[best_idx][:5]

            feat = extractor.extract(kpts)
            fv = feat['feature_vector']

            # MLP 推理
            state = mlp.predict(fv)
            state_history.append(state)

            # 时序平滑
            from collections import Counter
            if len(state_history) >= 10:
                state = Counter(list(state_history)[-10:]).most_common(1)[0][0]

            current_state = state
        else:
            state_history.append(current_state)
            feat = None

        # FPS
        frame_times.append(time.perf_counter() - t0)
        fps = len(frame_times) / sum(frame_times) if sum(frame_times) > 0 else 0

        # 可视化
        display = frame.copy()
        h, w = display.shape[:2]

        # 画状态
        colors = [(0, 255, 0), (0, 255, 255), (0, 0, 255)]
        cv2.rectangle(display, (0, 0), (w, 80), colors[current_state], -1)
        cv2.putText(display, LABELS[current_state], (20, 55),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.8, (0, 0, 0), 3)

        if feat:
            cv2.putText(display, f"EAR: {feat['ear']:.3f}", (20, 100),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(display, f"MAR: {feat['mar']:.3f}", (20, 120),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(display, f"PERCLOS: {feat['perclos']:.3f}", (20, 140),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        cv2.putText(display, f"FPS: {fps:.1f}", (w - 100, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # 在人脸上画关键点
        if feat and 'kpts' in dir():
            for kp in kpts:
                cv2.circle(display, (int(kp[0]), int(kp[1])), 3, (0, 255, 255), -1)

        cv2.imshow('Driver Fatigue Detection', display)

        frame_count += 1
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"\n处理完成: {frame_count} 帧")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='司机疲劳检测器')
    parser.add_argument('--source', type=str, default='0',
                        help='摄像头 ID 或视频文件路径')
    parser.add_argument('--yolo_model', type=str, default='yolo11n-pose.pt',
                        help='YOLO 模型路径 (.pt, 开发阶段)')
    parser.add_argument('--yolo_engine', type=str, default='',
                        help='YOLO TensorRT Engine 路径 (Jetson 部署)')
    parser.add_argument('--mlp_model', type=str, default='outputs/features/fatigue_mlp.npz',
                        help='MLP 模型路径 (.npz)')
    parser.add_argument('--perclos_window', type=int, default=90,
                        help='PERCLOS 窗口帧数')
    parser.add_argument('--ear_threshold', type=float, default=0.18,
                        help='EAR 闭眼阈值')
    parser.add_argument('--temporal_window', type=int, default=30,
                        help='疲劳状态时序平滑窗口')
    parser.add_argument('--output', type=str, default='',
                        help='保存输出视频路径 (可选)')
    args = parser.parse_args()

    try:
        run_demo(args)
    except KeyboardInterrupt:
        print("\n已中断")
