#!/usr/bin/env python3
"""
TensorRT FP16 实时摄像头疲劳检测

用法:
    python3 jetson_deploy/test_trt_camera.py \
        --engine outputs/engines/yolo11n-pose-fp16.engine

    python3 jetson_deploy/test_trt_camera.py \
        --engine outputs/engines/yolo11n-pose-fp16.engine --no-display
"""

import argparse
import sys
import time
import os
from datetime import datetime
from pathlib import Path
from collections import deque

import cv2
import numpy as np

# 添加 src 目录到路径以复用疲劳检测函数
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'src'))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'jetson_deploy'))

from trt_inference import TRTEngine
from fatigue_state_machine import FatigueStateMachine
from alert_handler import AlertHandler
from event_logger import EventLogger

from test_drowsy_hybrid import (
    eye_is_closed, compute_mar, compute_head_pose,
    FACE_3D, EYE_CLOSE_RATIO, MAR_THRESHOLD, HEAD_NOD_DEVIATION
)

# ============================================================
INPUT_SIZE = 320
FACE_CONF = 0.4
CLIP_BUFFER_SEC = 5
# ============================================================


def preprocess(frame: np.ndarray) -> np.ndarray:
    """BGR -> RGB, resize 320, normalize, CHW, add batch -> (1,3,320,320)"""
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (INPUT_SIZE, INPUT_SIZE))
    img = img.astype(np.float32) / 255.0
    img = img.transpose(2, 0, 1)
    return np.expand_dims(img, axis=0)


def postprocess(output: np.ndarray, frame_shape: tuple,
                conf_thres: float = 0.4):
    """
    手动解码 YOLO TensorRT 输出。

    output: (1, 56, 2100)
    56 channels = 4(cx,cy,w,h) + 1(obj) + 51(17 kpts * 3)

    Returns: (boxes_xyxy, kpts_xy, score)
    """
    h, w = frame_shape[:2]
    data = output[0]  # (56, 2100)

    # 取 objectness 最高的 grid cell
    obj_scores = data[4, :]
    best_idx = int(np.argmax(obj_scores))
    best_score = float(obj_scores[best_idx])

    if best_score < conf_thres:
        return None, None, 0.0

    # 解码 bbox (cx, cy, w, h) -> (x1, y1, x2, y2)
    cx, cy = data[0, best_idx], data[1, best_idx]
    bw, bh = data[2, best_idx], data[3, best_idx]
    boxes = np.array([
        (cx - bw / 2) * w / INPUT_SIZE,
        (cy - bh / 2) * h / INPUT_SIZE,
        (cx + bw / 2) * w / INPUT_SIZE,
        (cy + bh / 2) * h / INPUT_SIZE,
    ])

    # 解码关键点 (channels 5-55 -> 51 values = 17 * 3)
    kpt_data = data[5:56, best_idx]
    kpts = kpt_data.reshape(17, 3).copy()
    kpts[:, 0] *= w / INPUT_SIZE
    kpts[:, 1] *= h / INPUT_SIZE

    return boxes, kpts, best_score


def main():
    parser = argparse.ArgumentParser(description='TensorRT FP16 实时疲劳检测')
    parser.add_argument('--engine', required=True)
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--no-display', action='store_true')
    parser.add_argument('--api-url', default='http://fatigue-api:8000/api/events')
    parser.add_argument('--output-dir', default='/workspace/tiring_detection/data')
    args = parser.parse_args()

    print(f'加载引擎: {args.engine}')
    engine = TRTEngine(args.engine)
    print('引擎加载完成')

    sm = FatigueStateMachine(t_enter=15, t_exit=30)
    alert = AlertHandler(output_dir=args.output_dir)
    event_logger = EventLogger(api_url=args.api_url, log_dir=os.path.join(args.output_dir, 'events'))

    cap = cv2.VideoCapture(args.camera)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    if not cap.isOpened():
        print(f'[ERROR] 无法打开摄像头 {args.camera}')
        return

    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps_src = cap.get(cv2.CAP_PROP_FPS) or 30
    print(f'摄像头: {w}x{h} @ {fps_src:.0f} fps')

    cam_matrix = np.array([[w, 0, w/2], [0, w, h/2], [0, 0, 1]], dtype=np.float64)

    pitch_baseline = 0.0
    pitch_baseline_samples = deque(maxlen=60)
    pitch_established = False
    clip_buffer = deque(maxlen=int(CLIP_BUFFER_SEC * fps_src))
    frame_times = deque(maxlen=30)
    total_frames = 0
    fatigue_metrics = {}
    pitch_dev = 0.0
    is_eye_closed = is_yawning = is_nodding = False

    print('推理中... 按 q 退出\n')

    while True:
        ret, frame = cap.read()
        if not ret:
            print('[WARN] 摄像头断线, 重连中...')
            time.sleep(1)
            cap = cv2.VideoCapture(args.camera)
            continue

        t0 = time.perf_counter()
        total_frames += 1
        clip_buffer.append((time.time(), frame.copy()))

        # --- YOLO TensorRT ---
        raw = engine.infer({'images': preprocess(frame)})
        output = raw['output0']

        # --- 后处理 ---
        boxes, kpts, score = postprocess(output, frame.shape)

        display = frame.copy()
        fatigue_signal = False

        if boxes is not None and kpts is not None:
            face_w = boxes[2] - boxes[0]
            kpts5 = kpts[:5]                # (5, 3) -> x, y, conf
            kpts5_xy = kpts5[:, :2]         # (5, 2) -> only x, y

            eye_size = int(face_w * 0.10)
            eye_r = max(eye_size // 2, 12)

            lx, ly = int(kpts5_xy[1][0]), int(kpts5_xy[1][1])
            rx, ry = int(kpts5_xy[2][0]), int(kpts5_xy[2][1])

            left_roi = frame[max(0,ly-eye_r):min(h,ly+eye_r), max(0,lx-eye_r):min(w,lx+eye_r)]
            right_roi = frame[max(0,ry-eye_r):min(h,ry+eye_r), max(0,rx-eye_r):min(w,rx+eye_r)]

            left_closed = eye_is_closed(left_roi)
            right_closed = eye_is_closed(right_roi)
            is_eye_closed = left_closed and right_closed

            mar = compute_mar(kpts5_xy)
            pitch, yaw, roll = compute_head_pose(kpts5_xy, cam_matrix)

            if not pitch_established:
                pitch_baseline_samples.append(pitch)
                if len(pitch_baseline_samples) == pitch_baseline_samples.maxlen:
                    pitch_baseline = np.mean(pitch_baseline_samples)
                    pitch_established = True
                    print(f'  Pitch 基线建立: {pitch_baseline:.0f}°')

            pitch_dev = abs(pitch - pitch_baseline) if pitch_established else 0
            is_yawning = mar > MAR_THRESHOLD
            is_nodding = pitch_dev > HEAD_NOD_DEVIATION
            fatigue_signal = is_eye_closed or is_yawning or is_nodding

            fatigue_metrics = {
                'eye_closed_ratio': float(is_eye_closed),
                'head_pitch_deg': float(pitch),
                'mar': float(mar),
                'nod_count': int(is_nodding),
                'confidence': float(score),
                'fps': 0.0,
            }

            # 可视化
            x1, y1, x2, y2 = map(int, boxes)
            color = (0, 0, 255) if fatigue_signal else (0, 255, 0)
            cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
            for i, (kp, c) in enumerate(zip(kpts5, [(255,0,0),(0,255,0),(0,0,255),(0,255,255),(255,0,255)])):
                cv2.circle(display, (int(kp[0]), int(kp[1])), 3, c, -1)

        # 状态机
        prev_state = sm.state.value
        new_state = sm.update(fatigue_signal)

        if prev_state != new_state.value:
            fatigue_metrics['state_duration_sec'] = sm.state_duration_sec
            fps_val = len(frame_times)/sum(frame_times) if sum(frame_times)>0 else 0
            fatigue_metrics['fps'] = fps_val
            screenshot_path = clip_path = ""
            if new_state.value == "FATIGUE":
                screenshot_path = alert.save_screenshot(frame)
                clip_path = alert.save_clip(clip_buffer, fps=fps_src)
                print(f'[ALERT] 疲劳告警!')
            event_logger.log_state_change(prev_state, new_state.value,
                                          fatigue_metrics, screenshot_path, clip_path)

        # FPS
        dt = time.perf_counter() - t0
        frame_times.append(dt)
        fps = len(frame_times)/sum(frame_times) if sum(frame_times)>0 else 0

        # 状态栏
        bar_color = (0, 0, 255) if sm.is_fatigue else (0, 140, 0)
        cv2.rectangle(display, (0, 0), (w, 50), bar_color, -1)
        cv2.putText(display, f'{"DROWSY!!!" if sm.is_fatigue else "AWAKE"} | FPS:{fps:.0f}',
                    (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255, 255, 255), 2)

        # 底部信息
        yt = h - 55
        for line in [
            f"Eye:{'CLOSED' if (boxes is not None and is_eye_closed) else 'open'} Mouth:{'YAWN' if (boxes is not None and is_yawning) else 'normal'}",
            f"Head:{'NOD' if (boxes is not None and is_nodding) else 'stable'} Pitch:{pitch if boxes is not None else 0:.0f}",
            f"Conf:{score if boxes is not None else 0:.2f} State:{new_state.value}({sm.state_duration_sec:.1f}s)",
        ]:
            cv2.putText(display, line, (10, yt), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200,200,200), 1)
            yt += 13

        if not args.no_display:
            cv2.imshow('TRT Fatigue Detection', display)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    if not args.no_display:
        cv2.destroyAllWindows()
    print(f'\n推理结束 — {total_frames} 帧')


if __name__ == '__main__':
    main()
