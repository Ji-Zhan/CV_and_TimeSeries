"""
Jetson Orin Nano TensorRT 推理封装

支持:
  - YOLOv11 pose ONNX → TensorRT Engine
  - MLP 分类器 ONNX → TensorRT Engine
  - FP16/INT8 量化
  - 异步推理 (CUDA Stream)

注意: 此文件在 Jetson 上运行, 需要:
  pip install cuda-python pycuda onnxruntime-gpu
  (JetPack 自带 TensorRT + CUDA)
"""
import numpy as np
import os
from pathlib import Path

# TensorRT / CUDA 可能不在开发机上，使用延迟导入
try:
    import tensorrt as trt
    HAS_TRT = True
except ImportError:
    HAS_TRT = False

try:
    import pycuda.driver as cuda
    import pycuda.autoinit
    HAS_CUDA = True
except ImportError:
    HAS_CUDA = False

try:
    import onnxruntime as ort
    HAS_ORT = True
except ImportError:
    HAS_ORT = False


class TRTEngine:
    """TensorRT Engine 封装"""

    def __init__(self, engine_path):
        if not HAS_TRT:
            raise ImportError("tensorrt 未安装 (仅在 Jetson 上可用)")

        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)

        with open(engine_path, 'rb') as f:
            self.engine = self.runtime.deserialize_cuda_engine(f.read())

        self.context = self.engine.create_execution_context()
        self.stream = cuda.Stream()

        # 分配输入/输出 buffer
        self.inputs = []
        self.outputs = []
        self.bindings = []

        for i in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(i)
            shape = self.engine.get_tensor_shape(name)
            dtype = trt.nptype(self.engine.get_tensor_dtype(name))
            size = trt.volume(shape)

            # 分配 CPU + GPU 内存
            h_mem = cuda.pagelocked_empty(size, dtype)
            d_mem = cuda.mem_alloc(h_mem.nbytes)

            self.bindings.append(int(d_mem))

            if self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT:
                self.inputs.append({'name': name, 'shape': shape, 'dtype': dtype,
                                    'host': h_mem, 'device': d_mem, 'size': size})
            else:
                self.outputs.append({'name': name, 'shape': shape, 'dtype': dtype,
                                     'host': h_mem, 'device': d_mem, 'size': size})

    def infer(self, input_dict):
        """
        同步推理

        Args:
            input_dict: {name: numpy_array}

        Returns:
            {name: numpy_array}
        """
        # 1. 拷贝输入到 GPU
        for inp in self.inputs:
            data = input_dict[inp['name']]
            np.copyto(inp['host'], data.ravel())
            cuda.memcpy_htod_async(inp['device'], inp['host'], self.stream)

            self.context.set_tensor_address(inp['name'], int(inp['device']))

        for out in self.outputs:
            self.context.set_tensor_address(out['name'], int(out['device']))

        # 2. 执行推理
        self.context.execute_async_v3(self.stream.handle)

        # 3. 拷贝输出回 CPU
        for out in self.outputs:
            cuda.memcpy_dtoh_async(out['host'], out['device'], self.stream)

        self.stream.synchronize()

        # 4. 重组输出
        result = {}
        for out in self.outputs:
            result[out['name']] = out['host'].copy().reshape(out['shape'])

        return result

    @staticmethod
    def build_from_onnx(onnx_path, engine_path, fp16=True, int8=False,
                        workspace=1 << 30):
        """
        从 ONNX 构建 TensorRT Engine

        Args:
            onnx_path: ONNX 模型路径
            engine_path: 输出 Engine 路径
            fp16: 是否启用 FP16
            int8: 是否启用 INT8 (需要校准数据)
            workspace: 最大工作空间 (默认 1GB)
        """
        logger = trt.Logger(trt.Logger.WARNING)
        builder = trt.Builder(logger)

        network_flags = 1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
        network = builder.create_network(network_flags)

        parser = trt.OnnxParser(network, logger)
        with open(onnx_path, 'rb') as f:
            if not parser.parse(f.read()):
                for i in range(parser.num_errors):
                    print(f"  [ONNX Parse Error] {parser.get_error(i)}")
                raise RuntimeError("ONNX 解析失败")

        config = builder.create_builder_config()
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, workspace)

        if fp16:
            config.set_flag(trt.BuilderFlag.FP16)
        if int8:
            config.set_flag(trt.BuilderFlag.INT8)

        # 序列化
        serialized = builder.build_serialized_network(network, config)
        if serialized is None:
            raise RuntimeError("TensorRT Engine 构建失败")

        with open(engine_path, 'wb') as f:
            f.write(serialized)

        print(f"TensorRT Engine 已构建: {engine_path}")
        print(f"  FP16: {fp16}, INT8: {int8}")


class MlpNumpyInference:
    """
    MLP NumPy 纯推理 (不依赖 ONNX Runtime / TensorRT)

    适用于极轻量 MLP (<10KB), 手写前向传播比启动 ONNX Runtime 更快。
    从 export_classifier_onnx.py 导出的 .npz 文件加载权重。
    """

    def __init__(self, model_path):
        data = np.load(model_path, allow_pickle=True)
        self.weights = [w.astype(np.float32) for w in data['weights']]
        self.biases = [b.astype(np.float32) for b in data['biases']]
        self.scaler_mean = data['scaler_mean'].astype(np.float32)
        self.scaler_scale = data['scaler_scale'].astype(np.float32)
        self.classes = data['classes'].astype(np.int32)
        self.n_layers = len(self.weights)

    def predict(self, features):
        """
        features: np.array shape (5,) — [ear, mar, pitch, yaw, roll]
        Returns: int class label
        """
        # 标准化
        x = (features.astype(np.float32) - self.scaler_mean) / self.scaler_scale
        x = x.reshape(1, -1)

        # 前向传播
        for i in range(self.n_layers):
            x = x @ self.weights[i] + self.biases[i]
            if i < self.n_layers - 1:
                x = np.maximum(x, 0)  # ReLU

        return int(np.argmax(x, axis=1)[0])

    def predict_proba(self, features):
        """返回各类别概率"""
        x = (features.astype(np.float32) - self.scaler_mean) / self.scaler_scale
        x = x.reshape(1, -1)

        for i in range(self.n_layers):
            x = x @ self.weights[i] + self.biases[i]
            if i < self.n_layers - 1:
                x = np.maximum(x, 0)

        # Softmax
        exp_x = np.exp(x - x.max())
        return (exp_x / exp_x.sum()).ravel()


class OnnxInference:
    """ONNX Runtime 推理 (备选)"""

    def __init__(self, model_path):
        if not HAS_ORT:
            raise ImportError("onnxruntime 未安装")
        self.session = ort.InferenceSession(
            model_path,
            providers=['CUDAExecutionProvider', 'CPUExecutionProvider']
        )
        self.input_name = self.session.get_inputs()[0].name

    def predict(self, features):
        result = self.session.run(None, {self.input_name: features.reshape(1, -1).astype(np.float32)})
        return int(np.argmax(result[0], axis=1)[0])
