#!/usr/bin/env python3
"""
疲劳检测 + MJPEG 推流 — PyTorch YOLO GPU 版

眼/嘴检测: eye_mouth_detect/best.pt (YOLOv11n, GPU FP16)
头部姿态: yolo11n-pose.pt (GPU FP16, 每10帧)
判定逻辑:
  1. 单独闭眼或歪头 > 1.5s → FATIGUE
  2. 闭眼+歪头 > 1s → FATIGUE
  3. 闭眼+张嘴 > 0.5s = 打哈欠, 1分钟内2次 → FATIGUE
"""

import argparse, sys, os, time, json, threading, math
from datetime import datetime
from pathlib import Path
from collections import deque
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

import cv2, numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'src'))
from ultralytics import YOLO
from fatigue_state_machine import FatigueStateMachine
from alert_handler import AlertHandler
from event_logger import EventLogger

CONF_THRES = 0.25
POSE_CONF = 0.3
POSE_INTERVAL = 5
HEAD_NOD_DEVIATION = 20
MAR_THRESHOLD = 0.55
CLIP_BUFFER_SEC = 5
YAWN_WINDOW_SEC = 60
SINGLE_SIGNAL_SEC = 1.5
COMBO_SIGNAL_SEC = 1.0
YAWN_HOLD_SEC = 0.5

FACE_3D = np.array([
    [-30., -30., -30.], [30., -30., -30.], [0., 0., 0.],
    [-50., 20., -20.], [50., 20., -20.]
], dtype=np.float64)

_latest_frame: np.ndarray = None
_frame_lock = threading.Lock()
_state_info = {"state": "NO_FACE", "fps": 0.0, "conf": 0.0}
_state_lock = threading.Lock()


class MJPEGHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/stream': self._stream()
        elif self.path == '/snapshot': self._snapshot()
        elif self.path == '/status': self._status()
        else: self.send_response(404); self.end_headers()

    def _stream(self):
        self.send_response(200)
        self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=frame')
        self.send_header('Access-Control-Allow-Origin', '*'); self.end_headers()
        while True:
            with _frame_lock:
                if _latest_frame is None: time.sleep(0.02); continue
                _, jpeg = cv2.imencode('.jpg', _latest_frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            self.wfile.write(b'--frame\r\nContent-Type: image/jpeg\r\n\r\n')
            self.wfile.write(jpeg.tobytes()); self.wfile.write(b'\r\n')
            time.sleep(0.03)

    def _snapshot(self):
        with _frame_lock:
            if _latest_frame is None: self.send_response(204); self.end_headers(); return
            _, jpeg = cv2.imencode('.jpg', _latest_frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        self.send_response(200)
        self.send_header('Content-Type', 'image/jpeg')
        self.send_header('Access-Control-Allow-Origin', '*'); self.end_headers()
        self.wfile.write(jpeg.tobytes())

    def _status(self):
        with _state_lock: data = dict(_state_info)
        body = json.dumps(data).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*'); self.end_headers()
        self.wfile.write(body)

    def log_message(self, f, *a): pass


def compute_head_pose(kpts, cam):
    pts = kpts.astype(np.float64).reshape(5, 2)
    _, rvec, _ = cv2.solvePnP(FACE_3D, pts, cam, None, flags=cv2.SOLVEPNP_EPNP)
    rmat, _ = cv2.Rodrigues(rvec)
    sy = math.sqrt(rmat[0,0]**2 + rmat[1,0]**2)
    return math.degrees(math.atan2(-rmat[2,0], sy))


def compute_mar(kpts):
    """嘴部纵横比：嘴高 / 嘴宽（用鼻尖近似上唇中点）"""
    mouth_w = np.linalg.norm(kpts[3] - kpts[4]) + 1e-6
    mouth_h = abs(kpts[2][1] - (kpts[3][1] + kpts[4][1]) / 2.0)
    return float(mouth_h / mouth_w)


def eye_is_closed(roi):
    """瞳孔检测法：在眼部 ROI 中寻找深色圆形区域。

    找到瞳孔 = 睁眼；找不到 = 闭眼。
    这个方法是 eye_mouth_detect 模型漏检眼睛时（如戴眼镜/侧脸）的备用方案。
    """
    if roi is None or roi.size == 0 or roi.shape[0] < 8 or roi.shape[1] < 8:
        return False

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    block = max(7, min(gray.shape[0], gray.shape[1]) // 4 * 2 + 1)
    thresh = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, blockSize=block, C=8
    )
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    roi_area = roi.shape[0] * roi.shape[1]

    for cnt in contours:
        area = cv2.contourArea(cnt)
        area_ratio = area / roi_area
        if area_ratio < 0.03 or area_ratio > 0.30:
            continue
        perimeter = cv2.arcLength(cnt, True)
        if perimeter < 8:
            continue
        circularity = 4 * np.pi * area / (perimeter * perimeter)
        if circularity > 0.35:
            return False  # 找到瞳孔 = 睁眼

    return True  # 没找到瞳孔 = 闭眼


def pose_eye_closed(frame, kpts, cam_w, cam_h):
    """用 pose 关键点裁剪双眼 ROI，返回是否双眼都闭。"""
    left_eye = kpts[0]
    right_eye = kpts[1]
    eye_dist = float(np.linalg.norm(left_eye - right_eye))
    eye_r = max(int(eye_dist * 0.35), 12)

    lx, ly = int(left_eye[0]), int(left_eye[1])
    rx, ry = int(right_eye[0]), int(right_eye[1])

    left_roi = frame[max(0, ly - eye_r):min(cam_h, ly + eye_r),
                     max(0, lx - eye_r):min(cam_w, lx + eye_r)]
    right_roi = frame[max(0, ry - eye_r):min(cam_h, ry + eye_r),
                      max(0, rx - eye_r):min(cam_w, rx + eye_r)]

    left_closed = eye_is_closed(left_roi)
    right_closed = eye_is_closed(right_roi)
    return left_closed and right_closed


def main():
    global _latest_frame, _state_info

    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='/workspace/models/eye_mouth_detect/weights/best.pt')
    parser.add_argument('--pose-model', default='/workspace/models/yolo11n-pose.pt')
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--api-url', default='http://fatigue-api:8000/api/events')
    parser.add_argument('--http-port', type=int, default=8080)
    parser.add_argument('--output-dir', default='/workspace/tiring_detection/data')
    args = parser.parse_args()

    httpd = ThreadingHTTPServer(('0.0.0.0', args.http_port), MJPEGHandler)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    print(f'MJPEG: http://0.0.0.0:{args.http_port}/stream')

    print(f'Eye/Mouth: {args.model}')
    em_model = YOLO(args.model, verbose=False)
    print(f'Pose: {args.pose_model}')
    pose_model = YOLO(args.pose_model, verbose=False)

    sm = FatigueStateMachine(t_enter=60, t_exit=30)
    alert = AlertHandler(output_dir=args.output_dir)
    elog = EventLogger(api_url=args.api_url, log_dir=os.path.join(args.output_dir, 'events'))

    cap = cv2.VideoCapture(args.camera)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    if not cap.isOpened():
        print(f'[FATAL] Camera {args.camera} failed'); return
    w, h = int(cap.get(3)), int(cap.get(4))
    fps_s = cap.get(cv2.CAP_PROP_FPS)
    if not fps_s or fps_s <= 0: fps_s = 30.0
    print(f'Camera: {w}x{h} @ {fps_s:.0f}fps')

    frame_interval = 1.0 / 24.0
    single_th = int(SINGLE_SIGNAL_SEC * fps_s)
    combo_th = int(COMBO_SIGNAL_SEC * fps_s)
    yawn_th  = int(YAWN_HOLD_SEC   * fps_s)
    yawn_win = int(YAWN_WINDOW_SEC  * fps_s)

    cam = np.array([[w,0,w/2],[0,w,h/2],[0,0,1]], dtype=np.float64)
    pitch_samples = deque(maxlen=60)
    pitch_bl = 0.0; pitch_ok = False
    pitch = 0.0

    eye_closed_cnt = 0; head_tilt_cnt = 0; combo_cnt = 0; yawn_cnt = 0
    yawn_history = deque()
    clip_buf = deque(maxlen=int(CLIP_BUFFER_SEC * fps_s))
    ft = deque(maxlen=30)
    frame_n = 0; score = 0.0
    head_tilt = False
    last_pose_kpts = None
    pose_has_face = False

    print(f'Logic: single>{SINGLE_SIGNAL_SEC}s combo>{COMBO_SIGNAL_SEC}s yawn>{YAWN_HOLD_SEC}s')
    print(f'Frame cap: 24fps')
    print('Loop started')

    while True:
        ret, frame = cap.read()
        if not ret: time.sleep(1); cap = cv2.VideoCapture(args.camera); continue

        t0 = time.perf_counter()
        frame_n += 1
        clip_buf.append((time.time(), frame.copy()))

        # ---- 眼/嘴检测 (PyTorch GPU) ----
        em_results = em_model(frame, conf=CONF_THRES, verbose=False, device='cuda', half=True)[0]
        em_has_face = (em_results.boxes is not None and len(em_results.boxes) > 0)

        eye_cl = mouth_open = False
        em_eye_seen = em_mouth_seen = False
        score = 0.0
        if em_has_face:
            for i in range(len(em_results.boxes)):
                cls_id = int(em_results.boxes.cls[i])
                conf = float(em_results.boxes.conf[i])
                score = max(score, conf)
                if cls_id == 0: eye_cl = True; em_eye_seen = True       # closed_eye
                elif cls_id == 2: em_eye_seen = True                    # open_eye
                elif cls_id == 1: em_mouth_seen = True                  # closed_mouth
                elif cls_id == 3: mouth_open = True; em_mouth_seen = True  # open_mouth

        # ---- 头部姿态 / 人脸关键点 (每 POSE_INTERVAL 帧，不依赖眼嘴模型) ----
        if frame_n % POSE_INTERVAL == 0:
            pose_has_face = False
            pose_results = pose_model(frame, conf=POSE_CONF, verbose=False, device='cuda', half=True)[0]
            if (pose_results.keypoints is not None and len(pose_results.keypoints.xy) > 0
                    and pose_results.boxes is not None and len(pose_results.boxes.conf) > 0):
                best = int(pose_results.boxes.conf.argmax())
                kpts_raw = pose_results.keypoints.xy[best].cpu().numpy()
                if len(kpts_raw) >= 5:
                    # 统一为 [左眼, 右眼, 鼻尖, 左嘴角, 右嘴角]
                    hp_kpts = np.array([kpts_raw[1], kpts_raw[2], kpts_raw[0],
                                        kpts_raw[3], kpts_raw[4]])
                    last_pose_kpts = hp_kpts
                    pose_has_face = True
                    score = max(score, float(pose_results.boxes.conf[best]))
                    pitch = compute_head_pose(hp_kpts, cam)
                    if not pitch_ok:
                        pitch_samples.append(pitch)
                        if len(pitch_samples) == pitch_samples.maxlen:
                            pitch_bl = np.mean(pitch_samples); pitch_ok = True
                            print(f'Pitch baseline: {pitch_bl:.0f}°')
                    pd = abs(pitch - pitch_bl) if pitch_ok else 0
                    head_tilt = pd > HEAD_NOD_DEVIATION

        face_visible = em_has_face or pose_has_face

        # ---- 眼嘴模型漏检时的备用方案：用 pose 关键点裁剪眼部/嘴部 ----
        if face_visible and not em_eye_seen and last_pose_kpts is not None:
            eye_cl = pose_eye_closed(frame, last_pose_kpts, w, h)
        if face_visible and not em_mouth_seen and last_pose_kpts is not None:
            mar = compute_mar(last_pose_kpts)
            mouth_open = mar > MAR_THRESHOLD

        # 完全看不到人脸时，不要保留旧的检测信号，避免误报
        if not face_visible:
            eye_cl = mouth_open = False
            head_tilt = False

        # ---- 计数器 ----
        if eye_cl:
            eye_closed_cnt += 1
        else:
            eye_closed_cnt = max(0, eye_closed_cnt - 1)

        if head_tilt:
            head_tilt_cnt += 1
        else:
            head_tilt_cnt = max(0, head_tilt_cnt - 1)

        if eye_cl and head_tilt:
            combo_cnt += 1
        else:
            combo_cnt = max(0, combo_cnt - 1)

        if eye_cl and mouth_open:
            yawn_cnt += 1
        else:
            if yawn_cnt >= yawn_th:
                yawn_history.append(frame_n)
            yawn_cnt = 0
        while yawn_history and frame_n - yawn_history[0] > yawn_win:
            yawn_history.popleft()

        # ---- 判定 ----
        single_fatigue = (eye_closed_cnt >= single_th or head_tilt_cnt >= single_th)
        combo_fatigue = (combo_cnt >= combo_th)
        yawn_fatigue = (len(yawn_history) >= 2)
        fatigue_signal = single_fatigue or combo_fatigue or yawn_fatigue

        causes = []
        if eye_closed_cnt >= single_th: causes.append('Eyes Closed')
        if head_tilt_cnt >= single_th: causes.append('Head Tilt')
        if combo_cnt >= combo_th: causes.append('Eyes+Head')
        if yawn_fatigue: causes.append(f'Yawn(x{len(yawn_history)})')
        fatigue_cause = '+'.join(causes) if causes else ''

        # ---- 可视化 ----
        display = frame.copy()
        if em_has_face:
            for i in range(len(em_results.boxes)):
                x1, y1, x2, y2 = map(int, em_results.boxes.xyxy[i])
                cls_id = int(em_results.boxes.cls[i])
                name = em_results.names.get(cls_id, str(cls_id))
                c = (0, 255, 0)
                if cls_id == 0: c = (0, 0, 255)
                elif cls_id == 3: c = (0, 255, 255)
                elif cls_id == 2: c = (0, 180, 0)
                cv2.rectangle(display, (x1, y1), (x2, y2), c, 2)
                cv2.putText(display, name, (x1, y1-5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, c, 1)
        elif pose_has_face and last_pose_kpts is not None:
            for (x, y) in last_pose_kpts:
                cv2.circle(display, (int(x), int(y)), 2, (0, 255, 255), -1)
            cv2.putText(display, 'POSE FACE', (10, h - 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 1)
        else:
            cv2.putText(display, 'NO FACE', (w//2-60, h//2),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (100,100,255), 2)

        # ---- 状态机 ----
        prev = sm.state.value
        cur = sm.update(fatigue_signal).value

        if prev != cur and cur == "FATIGUE":
            fps_now = len(ft)/sum(ft) if sum(ft)>0 else 0
            m = {'eye_closed_ratio': float(eye_cl), 'head_pitch_deg': float(pitch),
                 'mar': float(mouth_open), 'nod_count': int(head_tilt),
                 'confidence': float(score), 'state_duration_sec': sm.state_duration_sec,
                 'fps': fps_now, 'cause': fatigue_cause}
            ss = alert.save_screenshot(frame)
            cl = alert.save_clip(clip_buf, fps=fps_s)
            print(f'[ALERT] {datetime.now().strftime("%H:%M:%S")} cause:{fatigue_cause}')
            elog.log_state_change(prev, cur, m, ss, cl)

        # ---- FPS ----
        dt = time.perf_counter() - t0
        ft.append(dt)
        fps = len(ft)/sum(ft) if sum(ft)>0 else 0

        # ---- 诊断 ----
        if frame_n % 30 == 0:
            ec_s = f'CLS({eye_closed_cnt})' if eye_cl else 'opn'
            ht_s = f'TILT({head_tilt_cnt})' if head_tilt else 'ok'
            print(f'  [{frame_n}] eye:{ec_s} head:{ht_s} → {"FAT" if fatigue_signal else "ok"} | {fatigue_cause} state:{sm.state.value}')

        # ---- 状态栏 ----
        if not face_visible:
            state_label = 'NO FACE'; bar_c = (100, 100, 100)
        elif sm.is_fatigue:
            state_label = f'DROWSY ({fatigue_cause})' if fatigue_cause else 'DROWSY'
            bar_c = (0, 0, 255)
        else:
            state_label = 'AWAKE'; bar_c = (0, 140, 0)
        cv2.rectangle(display, (0,0), (w,46), bar_c, -1)
        cv2.putText(display, f'{state_label} | FPS:{fps:.0f}', (10,33),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255,255,255), 2)

        yt = h - 30
        cv2.putText(display,
                    f"Eye:{'CLS' if eye_cl else 'opn'} Head:{'TILT' if head_tilt else 'ok'}"
                    f" Mouth:{'OPEN' if mouth_open else 'shut'}",
                    (10, yt), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200,200,200), 1)

        with _frame_lock: _latest_frame = display.copy()
        with _state_lock:
            _state_info = {"state": state_label, "fps": round(fps, 1),
                           "conf": round(float(score or 0), 3)}
        try:
            with open('/workspace/tiring_detection/data/buzzer_state', 'w') as f:
                f.write('1' if sm.is_fatigue else '0')
        except: pass
        elapsed = time.perf_counter() - t0
        remain = frame_interval - elapsed
        if remain > 0:
            time.sleep(remain)


if __name__ == '__main__':
    main()
